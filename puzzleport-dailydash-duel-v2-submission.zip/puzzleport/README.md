# PuzzlePort: DailyDash Duel

A playable full-stack puzzle parlour: React + TypeScript + Vite on the front, Node + Express + TypeScript on the back, and a real SQLite database for accounts, runs, stats, and leaderboards. Every daily puzzle is seeded from the Asia/Kolkata date, so all players see the same layouts.

Built for the emergency sprint. No Supabase, Prisma, PostgreSQL, Docker, Socket.IO, Redis, or monorepo tooling.

## Stack

| Layer | Choice |
|-------|--------|
| Client | React 19, TypeScript, Vite 8, React Router |
| Styling | Hand-written CSS glassmorphism (pastel pink / mint / sky / peach / cream), responsive layouts, reduced-motion support |
| Server | Node.js, Express 5, TypeScript |
| Database | SQLite via better-sqlite3, WAL mode, prepared statements, constraints, indexes |
| Auth | bcryptjs (cost 12) + signed JWTs (secret stays on the server) |
| Validation | Zod |
| Tests | Vitest + Supertest |

## Requirements

- Node.js 24+ (the `engines` field requires it)
- npm
- A local C++ toolchain only if a prebuilt `better-sqlite3` binary is unavailable for your platform

## Quick start

From the project directory:

```bash
npm install
cp .env.example .env
```

Generate two real secrets and put them in `.env`:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

Run that twice, once for `JWT_SECRET` and once for `DAILY_SEED_SECRET`. Both must be at least 32 characters. `DATABASE_PATH` defaults to `./server/data/puzzleport.db`.

```bash
npm run db:init      # optional: create the schema up front; the server also does this on start
npm run dev          # API + Vite client together
```

Development URLs:

- Web app: http://localhost:5173
- API: http://localhost:4000
- Health: http://localhost:4000/api/v1/health

The Vite dev server proxies `/api` to `http://localhost:4000`.

### Production build

```bash
npm run build
npm start
```

`npm start` serves the API and the built SPA from **http://localhost:4000** (with SPA fallback for client routes).

### Useful scripts

| Command | Purpose |
|---------|---------|
| `npm run dev` | Run API and Vite dev server together |
| `npm run dev:server` | API only (`tsx watch`) |
| `npm run dev:web` | Vite client only |
| `npm run build` | Compile server and build client |
| `npm start` | Run the compiled production server |
| `npm run typecheck` | Typecheck server and client |
| `npm test` | Run the Vitest suite |
| `npm run db:init` | Create tables/indexes without starting the server |

## Environment variables

| Variable | Required | Default | Notes |
|----------|----------|---------|-------|
| `PORT` | No | `4000` | API / production web port |
| `NODE_ENV` | No | `development` | `development`, `test`, or `production` |
| `JWT_SECRET` | Yes | — | At least 32 chars; signs auth tokens |
| `DAILY_SEED_SECRET` | Yes | — | At least 32 chars; HMAC key for daily seeds |
| `DATABASE_PATH` | No | `./server/data/puzzleport.db` | SQLite file path |

`.env` is gitignored and must never be committed.

## Database

The SQLite file lives at `./server/data/puzzleport.db` and persists across restarts.

Tables:

- `users` — unique username/email, bcrypt password hash, avatar, XP, level
- `game_sessions` — server-issued run sessions (ownership, mode, seed, daily date, status)
- `scores` — one saved result per session; game, mode, score, moves, duration, date
- `user_stats` — per-user/per-game aggregates (games, bests, totals)
- `daily_challenges` — materialized daily metadata and seeds

Foreign keys are enabled, the database uses WAL mode, and indexes cover leaderboard, history, and daily lookups.

To reset local data, stop the server and delete the database file plus `-wal`/`-shm` siblings, then run `npm run db:init`.

## API

All responses are JSON. Errors follow:

```json
{ "error": { "code": "VALIDATION_ERROR", "message": "…", "details": {} } }
```

| Method & path | Auth | Purpose |
|---------------|------|---------|
| `POST /api/v1/auth/register` | Public | Create account (`displayName`, `username`, `email`, `password`, `avatar`) |
| `POST /api/v1/auth/login` | Public | Sign in with email or username + password |
| `GET /api/v1/auth/me` | Bearer JWT | Current user incl. email, XP, level |
| `PATCH /api/v1/auth/me` | Bearer JWT | Update display name / avatar |
| `POST /api/v1/auth/logout` | Bearer JWT | Stateless logout (204); client clears the token |
| `GET /api/v1/health` | Public | Liveness |
| `GET /api/v1/ready` | Public | Readiness (database check) |
| `GET /api/v1/daily` | Optional JWT | Today's IST challenge, seeds, and this user's best/completion |
| `POST /api/v1/sessions` | Bearer JWT | Start a game session; returns session ID and seed |
| `POST /api/v1/scores` | Bearer JWT | Save a session result; updates XP, stats, daily completion |
| `GET /api/v1/leaderboards?game=memory\|2048&period=daily\|all&limit=25` | Optional JWT | Ranked board, best run per player, plus current user's place |
| `GET /api/v1/stats/me` | Bearer JWT | Totals, personal bests, recent runs |
| `GET /api/v1/history?limit=10` | Bearer JWT | Recent saved runs |

Identity for writes always comes from the verified JWT, never from a submitted user ID. API routes send `Cache-Control: no-store`.

### Auth notes

- Passwords are hashed with bcrypt (cost 12) and never returned or stored in plaintext.
- Tokens are signed with `JWT_SECRET`, expire after 7 days, issuer/audience `puzzleport`.
- Duplicate usernames and emails are rejected with unique constraints and clean 409 errors.
- Auth endpoints and write endpoints have in-memory rate limiting (per IP + path).
- Email verification, password reset, and account deletion are **not implemented**; email verification is not simulated.

## Games & daily rules

### Daily challenges

- Date period is **Asia/Kolkata**; the seed changes at midnight IST.
- A deterministic HMAC-SHA256 seed is derived per game/day from `DAILY_SEED_SECRET`.
- Seeds and layouts are identical for every player on the same date.
- The per-day seed is sent to the browser because the client builds the same puzzle; the HMAC secret is never exposed.
- Replays are allowed. Each player's **best** daily run represents them on that day's leaderboard.
- Saving checks the session belongs to the user, the daily date is still current, the session is under 12 hours old, and each session can only be saved once.

### Memory Match

- 4×4 board, 8 pairs, seeded daily shuffle.
- 3D flip animation, match detection, move counter, timer, mismatch input lock, victory modal.
- Score is recomputed on the server from moves and duration; the client's claimed points are ignored.
- Personal best is ranked by fewest moves, then fastest time.

### 2048

- 4×4 board with standard slide/merge rules; each tile merges at most once per move.
- Arrow keys, WASD, on-screen D-pad, and touch swipes.
- Score, moves, timer, game-over detection, finish/save, restart, modal result summary.
- The server enforces session ownership and bounded values (score ≤ 5,000,000, valid move counts). 2048 scores are client-reported with basic sanity bounds; replay-based verification is future work.

### XP & levels

- XP is awarded per saved run: Memory rewards efficient solves; 2048 rewards score.
- Levels use `floor(sqrt(xp / 100)) + 1`.
- Totals, personal bests, and history update in the same transaction as the score.

## Features completed

- Pastel glassmorphism design system, animated navigation/buttons/cards/modals, soft shadows
- Responsive desktop/tablet/mobile layouts, including mobile bottom navigation
- Keyboard navigation with visible focus rings; `prefers-reduced-motion` support
- Real registration/login/logout, protected client routes, JWT-backed API auth
- SQLite schema with uniqueness, foreign keys, indexes, and genuine restart persistence
- Memory Match and 2048 fully playable with server-created sessions and saved results
- Daily IST seeds shared by all players, completion state, personal bests
- Daily and all-time leaderboards with top-three podium, current-user rank, empty states
- Profile with avatar, level/XP, personal bests, milestones, and recent history
- 404 page, rules page, loading/error/empty states, accessible modals and announcements

## Verification performed

Commands actually run from the project directory:

```bash
npm run typecheck
# server + client: no TypeScript errors

npm test
# Test Files  10 passed (10)
# Tests       104 passed (104)

npm run build
# Server TypeScript compiled to server/dist
# Vite production build succeeded (client/dist)
```

Runtime smoke checks against the production server:

- Registered a fresh account; password hash verified as bcrypt (`$2b$12$…`) and not plaintext
- Logged in with wrong password (401) and correct credentials (200)
- Exercised `/auth/me`, `/daily`, `/sessions`, `/scores`, `/leaderboards`, `/stats/me`, `/history`
- Saved real Memory and 2048 daily runs; XP/level/stats/history updated
- Restarted the server and confirmed the same account, scores, stats, and leaderboard rows persisted
- Browser smoke test in Chromium: guest home, signup/login, dashboard, Memory (flip + mismatch lock), 2048 (keyboard moves + save modal), leaderboards, profile, mobile layouts, console errors — none
- Confirmed API `Cache-Control: no-store`, no ETags, focus outline (3px solid), and reduced-motion media query

No automated browser test suite is committed; the browser checks above were manual smoke runs.

## Deferred / future work

- Email verification and password reset
- Persistent achievements table (profile milestones are derived from stats now)
- Replay-based anti-cheat and server-side 2048 validation
- HttpOnly cookie sessions/refresh tokens instead of localStorage JWT
- Persistent/distributed rate limiting (current limiter is per-process, in-memory)
- Account deletion, OAuth, email notifications
- HTTPS/security headers hardening for a real deployment

## Security limitations (read before deploying)

- This MVP stores the JWT in `localStorage` to keep the sprint simple; XSS would expose it. Prefer HttpOnly cookies in production.
- 2048 scores are bounded but client-reported; Memory scores are recalculated.
- Rate limits reset when the server restarts and are not shared across instances.
- Helmet is enabled, but CSP is disabled because the inline design assets/scripts setup was kept simple.
- Secrets must be strong and unique; do not reuse the example values.

## Project layout

```
puzzleport/
├── package.json
├── tsconfig.base.json
├── vitest.config.mts
├── .env.example
├── server/
│   ├── src/
│   │   ├── index.ts          # Entry: DB init + listen
│   │   ├── app.ts            # Express routes, validation, scoring, leaderboards
│   │   ├── auth.ts           # JWT signing/verification middleware
│   │   ├── db.ts             # SQLite schema/init
│   │   ├── env.ts            # Zod env validation
│   │   ├── init-db.ts        # db:init script
│   │   └── games/            # Shared 2048, Memory, and daily-seed logic
│   └── data/                 # SQLite file (gitignored)
├── client/
│   ├── index.html
│   ├── vite.config.mts
│   └── src/
│       ├── App.tsx
│       ├── components/       # Layout, AuthShell, UI kit, countdown
│       ├── hooks/useDaily.ts
│       ├── lib/              # API client, auth context, types, formatters
│       ├── pages/            # Home, auth, Play, Memory, 2048, Leaderboards, Profile, Rules
│       └── styles/           # base, components, pages, games, responsive
└── tests/                    # DB, auth, API, daily, game engines, scores, persistence
```
