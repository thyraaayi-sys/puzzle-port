export type MemoryThemeDefinition = {
  id: string;
  name: string;
  description: string;
  emoji: string;
  palette: string[];
  symbols: string[];
  unlockType: "default" | "coins" | "achievement" | "event";
  cost: number;
  achievementSlug?: string;
  eventId?: string;
  sortOrder: number;
};

const themes: Array<Omit<MemoryThemeDefinition, "sortOrder">> = [
  {
    id: "animals",
    name: "Animal Kingdom",
    description: "A friendly forest full of tiny companions.",
    emoji: "🦊",
    palette: ["#fde2e4", "#f9dcc4", "#fcd5ce"],
    symbols: ["🦊", "🐰", "🐼", "🐸", "🐨", "🦁", "🐯", "🐮", "🐷", "🐵", "🐔", "🐧", "🦉", "🦄", "🐙", "🦋", "🐢", "🐳"],
    unlockType: "default",
    cost: 0,
  },
  {
    id: "pets",
    name: "Cute Pets",
    description: "Cozy companions and their favorite toys.",
    emoji: "🐾",
    palette: ["#fff1e6", "#ffe5d9", "#ffd7ba"],
    symbols: ["🐶", "🐱", "🐹", "🐭", "🐰", "🐾", "🦴", "🐟", "🐦", "🪴", "🧶", "🎾", "🪀", "🍖", "🛏️", "🐕", "🐈‍⬛", "🦜"],
    unlockType: "coins",
    cost: 120,
  },
  {
    id: "fantasy",
    name: "Fantasy Creatures",
    description: "Dragons, wizards and enchanted relics.",
    emoji: "🐉",
    palette: ["#e7d7ff", "#d8b4fe", "#c4b5fd"],
    symbols: ["🐉", "🧚", "🧙", "🧝", "🧞", "🦄", "🔮", "🗡️", "🛡️", "🏰", "🌙", "⭐", "🧪", "📜", "🪄", "👑", "🦇", "🔥"],
    unlockType: "coins",
    cost: 180,
  },
  {
    id: "ocean",
    name: "Ocean World",
    description: "Sunlit coral reefs and deep-sea friends.",
    emoji: "🌊",
    palette: ["#dbeafe", "#bfdbfe", "#93c5fd"],
    symbols: ["🐠", "🐡", "🦈", "🐬", "🐳", "🐙", "🦑", "🦀", "🦞", "🐚", "🪸", "🌊", "⚓", "🏝️", "🐢", "🫧", "⭐", "🪼"],
    unlockType: "coins",
    cost: 150,
  },
  {
    id: "space",
    name: "Space Adventure",
    description: "Rockets, planets and starlit trails.",
    emoji: "🚀",
    palette: ["#dbeafe", "#c7d2fe", "#a5b4fc"],
    symbols: ["🚀", "🛸", "🌍", "🌕", "⭐", "🌟", "🪐", "☄️", "🌌", "👽", "🛰️", "🔭", "🌠", "🧑‍🚀", "💫", "🌞", "🌑", "✨"],
    unlockType: "coins",
    cost: 180,
  },
  {
    id: "desserts",
    name: "Food and Desserts",
    description: "Sweet treats from a pastel bakery.",
    emoji: "🧁",
    palette: ["#fce7f3", "#fbcfe8", "#f9a8d4"],
    symbols: ["🍓", "🫐", "🍋", "🍑", "🍡", "🧁", "🍰", "🍩", "🍪", "🍫", "🍦", "🍮", "🍬", "🍭", "🥧", "🍯", "🧋", "🧇"],
    unlockType: "coins",
    cost: 120,
  },
  {
    id: "nature",
    name: "Nature and Flowers",
    description: "Blooming gardens and gentle seasons.",
    emoji: "🌷",
    palette: ["#dcfce7", "#bbf7d0", "#86efac"],
    symbols: ["🌷", "🌻", "🌼", "🌸", "🌺", "🍄", "🌿", "🍀", "🌵", "🌴", "🍁", "🌱", "🪷", "🌹", "🌾", "🌳", "🪻", "🌲"],
    unlockType: "coins",
    cost: 120,
  },
  {
    id: "retro",
    name: "Retro Pixel",
    description: "Arcade nostalgia in chunky pixels.",
    emoji: "👾",
    palette: ["#ede9fe", "#ddd6fe", "#c4b5fd"],
    symbols: ["👾", "🎮", "🕹️", "💾", "📼", "📟", "🖥️", "⌨️", "🖱️", "💿", "📀", "🪩", "🧩", "🎲", "🃏", "🀄", "🎯", "🎰"],
    unlockType: "coins",
    cost: 200,
  },
  {
    id: "tech",
    name: "Technology Logos",
    description: "A playful take on gadgets and tools.",
    emoji: "🤖",
    palette: ["#e0f2fe", "#bae6fd", "#7dd3fc"],
    symbols: ["💻", "📱", "⌨️", "🖥️", "🖱️", "💾", "💿", "📀", "🔋", "🔌", "📡", "🛰️", "🤖", "⚙️", "🔧", "🔨", "🧲", "💡"],
    unlockType: "coins",
    cost: 180,
  },
  {
    id: "gems",
    name: "Magical Gems",
    description: "Sparkling stones and enchanted light.",
    emoji: "💎",
    palette: ["#fce7f3", "#e9d5ff", "#dbeafe"],
    symbols: ["💎", "💠", "🔮", "🪄", "✨", "⭐", "🌟", "💛", "💚", "💙", "💜", "🧡", "❤️", "🤍", "🖤", "🤎", "💖", "💫"],
    unlockType: "coins",
    cost: 150,
  },
  {
    id: "festival",
    name: "Seasonal Festival",
    description: "Lanterns, fireworks and cozy celebrations.",
    emoji: "🪔",
    palette: ["#fef3c7", "#fde68a", "#fcd34d"],
    symbols: ["🪔", "🎆", "🎇", "🧨", "🎉", "🎊", "🎈", "🎁", "🕯️", "🌙", "⭐", "🪷", "🍬", "🏮", "🎏", "🎐", "✨", "🧧"],
    unlockType: "event",
    cost: 150,
    eventId: "lantern-festival",
  },
  {
    id: "cartoon",
    name: "Cute Cartoon Objects",
    description: "Bright toys and storybook props.",
    emoji: "🎨",
    palette: ["#fee2e2", "#fecaca", "#fca5a5"],
    symbols: ["🎈", "🎁", "🎨", "🖍️", "📚", "✏️", "🧸", "🪁", "🎠", "🎡", "🍭", "🍿", "🎪", "🎭", "🎵", "🎺", "🥳", "🎯"],
    unlockType: "coins",
    cost: 180,
  },
  {
    id: "winter",
    name: "Winter Wish",
    description: "Snowy nights and frosty magic.",
    emoji: "❄️",
    palette: ["#e0f2fe", "#f0f9ff", "#dbeafe"],
    symbols: ["❄️", "☃️", "🌨️", "🧊", "🧣", "🧤", "🌲", "⭐", "🕯️", "🎁", "☕", "🌬️", "🪵", "🦌", "🛷", "⛸️", "🎿", "🏂"],
    unlockType: "event",
    cost: 180,
    eventId: "winter-wish",
  },
  {
    id: "spring",
    name: "Spring Bloom",
    description: "Fresh blossoms and new beginnings.",
    emoji: "🌸",
    palette: ["#fce7f3", "#fbcfe8", "#fdf2f8"],
    symbols: ["🌸", "🌺", "🌷", "🌼", "🌻", "🐝", "🦋", "🪷", "🌱", "🌿", "🍀", "🌳", "🌹", "🌾", "🍁", "🪻", "🌲", "🌞"],
    unlockType: "event",
    cost: 160,
    eventId: "spring-bloom",
  },
];

export const MEMORY_THEMES: MemoryThemeDefinition[] = themes.map((theme, index) => ({
  ...theme,
  symbols: theme.symbols.map((symbol) => symbol.trim()),
  sortOrder: index + 1,
}));

export function getTheme(id: string): MemoryThemeDefinition | undefined {
  return MEMORY_THEMES.find((theme) => theme.id === id);
}

export function themeSymbols(themeId: string, pairCount: number): string[] {
  const theme = getTheme(themeId) ?? getTheme("animals")!;
  const symbols = Array.from(new Set(theme.symbols)).slice(0, pairCount);
  if (symbols.length < pairCount) throw new Error(`Theme ${themeId} has only ${symbols.length} unique symbols`);
  return symbols;
}
