export type CosmeticType = "card_back" | "border" | "flip" | "match_effect" | "victory_effect" | "theme";

export type CosmeticDefinition = {
  id: string;
  type: CosmeticType;
  name: string;
  description: string;
  style: string;
  unlockType: "default" | "coins" | "achievement" | "event";
  cost: number;
  achievementSlug?: string;
  eventId?: string;
  sortOrder: number;
};

const cosmetics: Array<Omit<CosmeticDefinition, "sortOrder">> = [
  { id: "sparkle", type: "card_back", name: "Sparkle", description: "Soft twinkle particles on the card back.", style: "sparkle", unlockType: "default", cost: 0 },
  { id: "clouds", type: "card_back", name: "Cloud Drift", description: "Gentle drifting clouds.", style: "clouds", unlockType: "coins", cost: 60 },
  { id: "stars", type: "card_back", name: "Night Stars", description: "A starry evening sky.", style: "stars", unlockType: "coins", cost: 80 },
  { id: "hearts", type: "card_back", name: "Hearts", description: "Pastel heart pattern.", style: "hearts", unlockType: "achievement", cost: 0, achievementSlug: "first-victory" },
  { id: "vines", type: "card_back", name: "Vines", description: "Soft floral vines.", style: "vines", unlockType: "coins", cost: 70 },
  { id: "soft", type: "border", name: "Soft Glow", description: "The default cozy border.", style: "soft", unlockType: "default", cost: 0 },
  { id: "gold", type: "border", name: "Golden Edge", description: "A warm golden outline.", style: "gold", unlockType: "achievement", cost: 0, achievementSlug: "level-5" },
  { id: "neon", type: "border", name: "Neon Pulse", description: "Bright pastel neon.", style: "neon", unlockType: "coins", cost: 100 },
  { id: "floral", type: "border", name: "Floral Frame", description: "Delicate flower trim.", style: "floral", unlockType: "coins", cost: 90 },
  { id: "pixel", type: "border", name: "Pixel Grid", description: "Retro pixel border.", style: "pixel", unlockType: "coins", cost: 120 },
  { id: "flip-soft", type: "flip", name: "Soft Flip", description: "A gentle 3D flip.", style: "soft", unlockType: "default", cost: 0 },
  { id: "flip-snappy", type: "flip", name: "Snappy Flip", description: "Fast and crisp.", style: "snappy", unlockType: "coins", cost: 50 },
  { id: "flip-spin", type: "flip", name: "Spin Flip", description: "A playful spin.", style: "spin", unlockType: "coins", cost: 70 },
  { id: "match-ripple", type: "match_effect", name: "Ripple Match", description: "Ripples on a correct pair.", style: "ripple", unlockType: "default", cost: 0 },
  { id: "match-spark", type: "match_effect", name: "Spark Burst", description: "Sparkles on a match.", style: "spark", unlockType: "coins", cost: 90 },
  { id: "match-bloom", type: "match_effect", name: "Bloom", description: "Flowers bloom on a match.", style: "bloom", unlockType: "coins", cost: 100 },
  { id: "victory-confetti", type: "victory_effect", name: "Confetti", description: "Classic confetti shower.", style: "confetti", unlockType: "default", cost: 0 },
  { id: "victory-stars", type: "victory_effect", name: "Starfall", description: "Stars fall across the screen.", style: "stars", unlockType: "achievement", cost: 0, achievementSlug: "first-perfect-memory" },
  { id: "victory-fireworks", type: "victory_effect", name: "Fireworks", description: "Festival fireworks.", style: "fireworks", unlockType: "event", cost: 120, eventId: "lantern-festival" },
];

export const COSMETICS: CosmeticDefinition[] = cosmetics.map((item, index) => ({
  ...item,
  sortOrder: index + 1,
}));
