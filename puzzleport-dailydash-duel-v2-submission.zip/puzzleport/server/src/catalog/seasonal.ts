export type SeasonalEventDefinition = {
  id: string;
  name: string;
  description: string;
  emoji: string;
  startsOn: string;
  endsOn: string;
  themeId: string;
  banner: string;
  sortOrder: number;
};

export const SEASONAL_EVENTS: SeasonalEventDefinition[] = [
  {
    id: "lantern-festival",
    name: "Lantern Festival",
    description: "Light up the board with warm lanterns and festival fireworks.",
    emoji: "🪔",
    startsOn: "2026-11-01",
    endsOn: "2026-11-30",
    themeId: "festival",
    banner: "Limited-time festival cosmetics available all month.",
    sortOrder: 1,
  },
  {
    id: "winter-wish",
    name: "Winter Wish",
    description: "Cozy snow scenes and frosty rewards.",
    emoji: "❄️",
    startsOn: "2026-12-01",
    endsOn: "2027-01-15",
    themeId: "winter",
    banner: "Winter cosmetics arrive with the first snow.",
    sortOrder: 2,
  },
  {
    id: "spring-bloom",
    name: "Spring Bloom",
    description: "Fresh blossoms and new beginnings.",
    emoji: "🌸",
    startsOn: "2027-03-01",
    endsOn: "2027-05-31",
    themeId: "spring",
    banner: "Bloom cosmetics and spring challenges.",
    sortOrder: 3,
  },
];

export function eventIsActive(event: SeasonalEventDefinition, dateKey: string): boolean {
  return dateKey >= event.startsOn && dateKey <= event.endsOn;
}
