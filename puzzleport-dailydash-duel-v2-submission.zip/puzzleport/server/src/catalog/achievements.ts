export type AchievementDefinition = {
  slug: string;
  title: string;
  description: string;
  emoji: string;
  xpReward: number;
  coinReward: number;
  criteriaKind: string;
  criteriaValue: number;
  secret: boolean;
  sortOrder: number;
};

const achievements: Array<Omit<AchievementDefinition, "sortOrder">> = [
  { slug: "first-victory", title: "First Victory", description: "Complete any game.", emoji: "🎉", xpReward: 50, coinReward: 20, criteriaKind: "games", criteriaValue: 1, secret: false },
  { slug: "puzzle-regular", title: "Puzzle Regular", description: "Complete 10 games.", emoji: "🧩", xpReward: 100, coinReward: 40, criteriaKind: "games", criteriaValue: 10, secret: false },
  { slug: "devoted-player", title: "Devoted Player", description: "Complete 30 games.", emoji: "🌟", xpReward: 250, coinReward: 100, criteriaKind: "games", criteriaValue: 30, secret: false },
  { slug: "port-veteran", title: "Port Veteran", description: "Complete 100 games.", emoji: "🏆", xpReward: 500, coinReward: 200, criteriaKind: "games", criteriaValue: 100, secret: false },
  { slug: "memory-first", title: "Memory Beginner", description: "Complete Memory Match.", emoji: "🃏", xpReward: 50, coinReward: 20, criteriaKind: "memory-games", criteriaValue: 1, secret: false },
  { slug: "memory-ten", title: "Memory Explorer", description: "Complete 10 Memory Match games.", emoji: "🧠", xpReward: 120, coinReward: 50, criteriaKind: "memory-games", criteriaValue: 10, secret: false },
  { slug: "first-perfect-memory", title: "Perfect Memory", description: "Finish Memory with no mismatches.", emoji: "✨", xpReward: 150, coinReward: 75, criteriaKind: "memory-perfect", criteriaValue: 1, secret: false },
  { slug: "memory-speedster", title: "Speed Demon", description: "Finish Memory in under 60 seconds.", emoji: "⚡", xpReward: 120, coinReward: 60, criteriaKind: "memory-fast", criteriaValue: 1, secret: false },
  { slug: "memory-ace", title: "Memory Ace", description: "Finish 8-pair Memory in 20 moves or fewer.", emoji: "🎯", xpReward: 150, coinReward: 75, criteriaKind: "memory-ace", criteriaValue: 1, secret: false },
  { slug: "memory-marathon", title: "Memory Marathon", description: "Complete a 6x6 Memory board.", emoji: "🏃", xpReward: 200, coinReward: 100, criteriaKind: "memory-6x6", criteriaValue: 1, secret: false },
  { slug: "daily-first", title: "Daily Challenger", description: "Complete a daily challenge.", emoji: "🔥", xpReward: 50, coinReward: 25, criteriaKind: "daily-games", criteriaValue: 1, secret: false },
  { slug: "daily-seven", title: "Seven-Day Streak", description: "Reach a 7-day daily streak.", emoji: "🔥", xpReward: 200, coinReward: 100, criteriaKind: "daily-streak", criteriaValue: 7, secret: false },
  { slug: "daily-thirty", title: "Daily Devotee", description: "Complete 30 daily challenges.", emoji: "📅", xpReward: 300, coinReward: 150, criteriaKind: "daily-games", criteriaValue: 30, secret: false },
  { slug: "weekly-four", title: "Weekly Warrior", description: "Reach a 4-week streak.", emoji: "🗓️", xpReward: 250, coinReward: 125, criteriaKind: "weekly-streak", criteriaValue: 4, secret: false },
  { slug: "level-5", title: "Port Regular", description: "Reach level 5.", emoji: "⭐", xpReward: 100, coinReward: 50, criteriaKind: "level", criteriaValue: 5, secret: false },
  { slug: "level-10", title: "Rising Star", description: "Reach level 10.", emoji: "🌟", xpReward: 250, coinReward: 125, criteriaKind: "level", criteriaValue: 10, secret: false },
  { slug: "level-20", title: "Puzzle Legend", description: "Reach level 20.", emoji: "👑", xpReward: 500, coinReward: 250, criteriaKind: "level", criteriaValue: 20, secret: false },
  { slug: "coin-hoarder", title: "Coin Hoarder", description: "Earn 500 coins.", emoji: "🪙", xpReward: 100, coinReward: 0, criteriaKind: "coins-earned", criteriaValue: 500, secret: false },
  { slug: "theme-collector", title: "Theme Collector", description: "Own 3 Memory themes.", emoji: "🎨", xpReward: 100, coinReward: 50, criteriaKind: "themes-owned", criteriaValue: 3, secret: false },
  { slug: "theme-master", title: "Theme Master", description: "Own 6 Memory themes.", emoji: "🖼️", xpReward: 200, coinReward: 100, criteriaKind: "themes-owned", criteriaValue: 6, secret: false },
  { slug: "cosmetic-collector", title: "Cosmetic Collector", description: "Own 10 cosmetics.", emoji: "✨", xpReward: 150, coinReward: 75, criteriaKind: "cosmetics-owned", criteriaValue: 10, secret: false },
  { slug: "campaign-memory-5", title: "Memory Campaigner", description: "Complete 5 Memory campaign levels.", emoji: "🗺️", xpReward: 100, coinReward: 50, criteriaKind: "campaign-memory", criteriaValue: 5, secret: false },
  { slug: "campaign-memory-15", title: "Memory World Tour", description: "Complete 15 Memory campaign levels.", emoji: "🌍", xpReward: 250, coinReward: 125, criteriaKind: "campaign-memory", criteriaValue: 15, secret: false },
  { slug: "campaign-memory-all", title: "Memory Champion", description: "Complete all 30 Memory campaign levels.", emoji: "🏅", xpReward: 500, coinReward: 250, criteriaKind: "campaign-memory", criteriaValue: 30, secret: false },
  { slug: "campaign-2048-5", title: "2048 Explorer", description: "Complete 5 2048 campaign levels.", emoji: "🔢", xpReward: 100, coinReward: 50, criteriaKind: "campaign-2048", criteriaValue: 5, secret: false },
  { slug: "campaign-2048-15", title: "2048 Mastermind", description: "Complete 15 2048 campaign levels.", emoji: "🧮", xpReward: 250, coinReward: 125, criteriaKind: "campaign-2048", criteriaValue: 15, secret: false },
  { slug: "campaign-champion", title: "Campaign Champion", description: "Complete all 20 2048 campaign levels.", emoji: "👑", xpReward: 500, coinReward: 250, criteriaKind: "campaign-2048", criteriaValue: 20, secret: false },
  { slug: "tile-2048", title: "512 Master", description: "Reach the 2048 tile.", emoji: "✨", xpReward: 100, coinReward: 50, criteriaKind: "tile-2048", criteriaValue: 1, secret: false },
  { slug: "tile-4096", title: "4096 Legend", description: "Reach the 4096 tile.", emoji: "🌟", xpReward: 250, coinReward: 125, criteriaKind: "tile-4096", criteriaValue: 1, secret: false },
  { slug: "score-10000", title: "Score Hunter", description: "Score 10,000 points in 2048.", emoji: "🎯", xpReward: 150, coinReward: 75, criteriaKind: "score-2048", criteriaValue: 10000, secret: false },
];

export const ACHIEVEMENTS: AchievementDefinition[] = achievements.map((achievement, index) => ({
  ...achievement,
  sortOrder: index + 1,
}));
