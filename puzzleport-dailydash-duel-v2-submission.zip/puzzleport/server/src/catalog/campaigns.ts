import { MEMORY_THEMES } from "./memoryThemes";

export type CampaignLevel = {
  id: string;
  game: "memory" | "2048";
  levelNumber: number;
  world: number;
  worldName: string;
  name: string;
  config: Record<string, unknown>;
  stars: { threeMoves: number; twoMoves: number; threeTimeMs: number; twoTimeMs: number };
  xpReward: number;
  coinReward: number;
  unlockLevelId: string | null;
  sortOrder: number;
};

const memoryWorlds = [
  { world: 1, name: "Beginner", levels: 5, rows: 4, cols: 4, pairs: 8 },
  { world: 2, name: "Explorer", levels: 7, rows: 4, cols: 5, pairs: 10 },
  { world: 3, name: "Challenger", levels: 10, rows: 4, cols: 6, pairs: 12 },
  { world: 4, name: "Master", levels: 8, rows: 6, cols: 6, pairs: 18 },
];

export const MEMORY_CAMPAIGN: CampaignLevel[] = (() => {
  const levels: CampaignLevel[] = [];
  let number = 1;
  let previousId: string | null = null;
  for (const world of memoryWorlds) {
    for (let i = 0; i < world.levels; i += 1) {
      const theme = MEMORY_THEMES[(number - 1) % MEMORY_THEMES.length];
      const id = `memory-c${String(number).padStart(2, "0")}`;
      const perfectMoves = world.pairs;
      levels.push({
        id,
        game: "memory",
        levelNumber: number,
        world: world.world,
        worldName: world.name,
        name: `${world.name} ${i + 1}`,
        config: {
          rows: world.rows,
          cols: world.cols,
          pairs: world.pairs,
          themeId: theme.id,
          seed: `puzzleport-memory-campaign-v1-${number}`,
          moveLimit: world.pairs * 4,
          timeLimitMs: world.pairs * 12000,
        },
        stars: {
          threeMoves: perfectMoves + Math.ceil(world.pairs * 0.4),
          twoMoves: perfectMoves + Math.ceil(world.pairs * 0.9),
          threeTimeMs: world.pairs * 7000,
          twoTimeMs: world.pairs * 14000,
        },
        xpReward: 40 + number * 8,
        coinReward: 15 + number * 3,
        unlockLevelId: previousId,
        sortOrder: number,
      });
      previousId = id;
      number += 1;
    }
  }
  return levels;
})();

const game2048Worlds = [
  { world: 1, name: "Beginner", levels: 5, target: 256, moveLimit: 120, timeLimitMs: 180000 },
  { world: 2, name: "Explorer", levels: 5, target: 512, moveLimit: 110, timeLimitMs: 150000 },
  { world: 3, name: "Challenger", levels: 5, target: 1024, moveLimit: 100, timeLimitMs: 120000 },
  { world: 4, name: "Master", levels: 5, target: 2048, moveLimit: 90, timeLimitMs: 100000 },
];

export const GAME2048_CAMPAIGN: CampaignLevel[] = (() => {
  const levels: CampaignLevel[] = [];
  let number = 1;
  let previousId: string | null = null;
  for (const world of game2048Worlds) {
    for (let i = 0; i < world.levels; i += 1) {
      const id = `2048-c${String(number).padStart(2, "0")}`;
      levels.push({
        id,
        game: "2048",
        levelNumber: number,
        world: world.world,
        worldName: world.name,
        name: `${world.name} ${i + 1}`,
        config: {
          size: 4,
          seed: `puzzleport-2048-campaign-v1-${number}`,
          startTiles: 2,
          targetTile: world.target,
          moveLimit: world.moveLimit,
          timeLimitMs: world.timeLimitMs,
        },
        stars: {
          threeMoves: Math.max(20, world.moveLimit - 25),
          twoMoves: world.moveLimit - 10,
          threeTimeMs: Math.max(30000, world.timeLimitMs - 30000),
          twoTimeMs: world.timeLimitMs - 10000,
        },
        xpReward: 50 + number * 10,
        coinReward: 20 + number * 4,
        unlockLevelId: previousId,
        sortOrder: number,
      });
      previousId = id;
      number += 1;
    }
  }
  return levels;
})();

export const ALL_CAMPAIGN_LEVELS = [...MEMORY_CAMPAIGN, ...GAME2048_CAMPAIGN];
