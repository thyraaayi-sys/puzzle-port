export type QuestScope = "daily" | "weekly";
export type QuestDefinition = {
  slug: string;
  scope: QuestScope;
  title: string;
  description: string;
  metric: string;
  target: number;
  xpReward: number;
  coinReward: number;
  emoji: string;
  sortOrder: number;
};

const quests: Array<Omit<QuestDefinition, "sortOrder">> = [
  { slug: "play-two-games", scope: "daily", title: "Play two games", description: "Complete two games today.", metric: "games", target: 2, xpReward: 40, coinReward: 15, emoji: "🎮" },
  { slug: "daily-memory", scope: "daily", title: "Daily Memory", description: "Complete today's Memory daily.", metric: "daily-memory", target: 1, xpReward: 35, coinReward: 15, emoji: "🃏" },
  { slug: "daily-2048", scope: "daily", title: "Daily 2048", description: "Complete today's 2048 daily.", metric: "daily-2048", target: 1, xpReward: 35, coinReward: 15, emoji: "🔢" },
  { slug: "efficient-memory", scope: "daily", title: "Efficient Memory", description: "Finish Memory in 24 moves or fewer.", metric: "memory-efficient", target: 1, xpReward: 45, coinReward: 20, emoji: "⚡" },
  { slug: "score-1000", scope: "daily", title: "Score 1,000", description: "Score 1,000 points in a 2048 run.", metric: "2048-score-1000", target: 1, xpReward: 40, coinReward: 15, emoji: "🎯" },
  { slug: "campaign-progress", scope: "daily", title: "Campaign Progress", description: "Complete one campaign level.", metric: "campaign-level", target: 1, xpReward: 45, coinReward: 20, emoji: "🗺️" },
  { slug: "five-games-week", scope: "weekly", title: "Five Games", description: "Complete five games this week.", metric: "games", target: 5, xpReward: 120, coinReward: 50, emoji: "🎮" },
  { slug: "three-dailies", scope: "weekly", title: "Three Dailies", description: "Complete three daily challenges this week.", metric: "daily-games", target: 3, xpReward: 100, coinReward: 45, emoji: "🔥" },
  { slug: "memory-week", scope: "weekly", title: "Memory Week", description: "Complete five Memory games this week.", metric: "memory-games", target: 5, xpReward: 120, coinReward: 50, emoji: "🃏" },
  { slug: "2048-week", scope: "weekly", title: "2048 Week", description: "Complete five 2048 games this week.", metric: "2048-games", target: 5, xpReward: 120, coinReward: 50, emoji: "🔢" },
  { slug: "level-up-week", scope: "weekly", title: "Level Up", description: "Gain at least 500 XP this week.", metric: "xp-gained", target: 500, xpReward: 150, coinReward: 75, emoji: "✨" },
  { slug: "theme-hunt", scope: "weekly", title: "Theme Hunt", description: "Unlock one new cosmetic.", metric: "cosmetic-unlocked", target: 1, xpReward: 100, coinReward: 40, emoji: "🎨" },
];

export const QUESTS: QuestDefinition[] = quests.map((quest, index) => ({
  ...quest,
  sortOrder: index + 1,
}));

export function selectQuests(scope: QuestScope, periodKey: string, count: number): string[] {
  const pool = QUESTS.filter((quest) => quest.scope === scope).map((quest) => quest.slug);
  const seed = hashString(`${scope}:${periodKey}`);
  const result: string[] = [];
  let cursor = seed;
  while (result.length < count && pool.length > 0) {
    const index = cursor % pool.length;
    const [slug] = pool.splice(index, 1);
    result.push(slug);
    cursor = Math.imul(cursor, 16777619) >>> 0;
  }
  return result;
}

function hashString(value: string): number {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < value.length; i += 1) {
    h ^= value.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
