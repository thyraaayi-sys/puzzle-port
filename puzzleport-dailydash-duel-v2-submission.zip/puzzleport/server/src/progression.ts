import type Database from "better-sqlite3";
import { istDateKey, addDaysToKey } from "./games/daily";
import { MEMORY_THEMES } from "./catalog/memoryThemes";
import { COSMETICS } from "./catalog/cosmetics";
import { ACHIEVEMENTS } from "./catalog/achievements";
import { QUESTS, selectQuests } from "./catalog/quests";
import { ALL_CAMPAIGN_LEVELS } from "./catalog/campaigns";
import { SEASONAL_EVENTS, eventIsActive } from "./catalog/seasonal";

export type RunRewardSummary = {
  scoreId: number;
  replayId: number | null;
  xpGain: number;
  coinGain: number;
  user: { xp: number; level: number; coins: number };
  achievements: string[];
  questsCompleted: string[];
  stars: number;
  campaign: { levelId: string | null; completed: boolean; bestStars: number; unlockedNext: string | null } | null;
  streak: { current: number; best: number; weekly: number; weeklyBest: number };
};

function levelForXp(xp: number): number {
  return Math.floor(Math.sqrt(Math.max(0, xp) / 100)) + 1;
}

export function weekKey(dateKey: string): string {
  const date = new Date(`${dateKey}T12:00:00+05:30`);
  const utc = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
  const day = utc.getUTCDay() || 7;
  utc.setUTCDate(utc.getUTCDate() + 4 - day);
  const yearStart = new Date(Date.UTC(utc.getUTCFullYear(), 0, 1));
  const week = Math.ceil(((utc.getTime() - yearStart.getTime()) / 86400000 + 1) / 7);
  return `${utc.getUTCFullYear()}-W${String(week).padStart(2, "0")}`;
}

export function ensureUserSetup(db: Database.Database, userId: number): void {
  const defaults: Array<[string, string]> = [
    ["theme", "animals"],
    ["card_back", "sparkle"],
    ["border", "soft"],
    ["flip", "flip-soft"],
    ["match_effect", "match-ripple"],
    ["victory_effect", "victory-confetti"],
  ];
  const grant = db.prepare("INSERT OR IGNORE INTO user_inventory (user_id, item_type, item_id) VALUES (?, ?, ?)");
  for (const [type, id] of defaults) grant.run(userId, type, id);
  db.prepare("INSERT OR IGNORE INTO user_preferences (user_id) VALUES (?)").run(userId);
  const user = db.prepare("SELECT equipped_theme FROM users WHERE id = ?").get(userId) as { equipped_theme: string } | undefined;
  if (user && !user.equipped_theme) {
    db.prepare("UPDATE users SET equipped_theme = 'animals' WHERE id = ?").run(userId);
  }
}

export function grantCoins(db: Database.Database, userId: number, amount: number, reason: string, reference: string): number {
  if (amount <= 0) return 0;
  const user = db.prepare("SELECT coins FROM users WHERE id = ?").get(userId) as { coins: number };
  const balance = user.coins + amount;
  try {
    db.prepare("INSERT INTO currency_transactions (user_id, amount, balance_after, reason, reference) VALUES (?, ?, ?, ?, ?)").run(
      userId,
      amount,
      balance,
      reason,
      reference,
    );
  } catch {
    return 0;
  }
  db.prepare("UPDATE users SET coins = ? WHERE id = ?").run(balance, userId);
  return amount;
}

function ensureQuests(db: Database.Database, userId: number): void {
  const today = istDateKey();
  const currentWeek = weekKey(today);
  for (const scope of ["daily", "weekly"] as const) {
    const periodKey = scope === "daily" ? today : currentWeek;
    const selected = selectQuests(scope, periodKey, 3);
    const insert = db.prepare("INSERT OR IGNORE INTO user_quests (user_id, quest_slug, period_key) VALUES (?, ?, ?)");
    for (const slug of selected) insert.run(userId, slug, periodKey);
  }
}

function userContext(db: Database.Database, userId: number, run?: { game?: string; perfect?: boolean; fastMemory?: boolean; aceMemory?: boolean; memory6x6?: boolean; maxTile?: number; score?: number }) {
  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(userId) as Record<string, unknown>;
  const games = (db.prepare("SELECT COUNT(*) AS c FROM scores WHERE user_id = ?").get(userId) as { c: number }).c;
  const memoryGames = (db.prepare("SELECT COUNT(*) AS c FROM scores WHERE user_id = ? AND game = 'memory'").get(userId) as { c: number }).c;
  const dailyGames = (db.prepare("SELECT COUNT(*) AS c FROM scores WHERE user_id = ? AND mode = 'daily'").get(userId) as { c: number }).c;
  const perfectRuns = (db.prepare("SELECT COUNT(*) AS c FROM scores WHERE user_id = ? AND game = 'memory' AND json_extract(metadata_json, '$.perfect') = 1").get(userId) as { c: number }).c;
  const fastMemoryRuns = (db.prepare("SELECT COUNT(*) AS c FROM scores WHERE user_id = ? AND game = 'memory' AND duration_ms < 60000").get(userId) as { c: number }).c;
  const aceMemoryRuns = (db.prepare("SELECT COUNT(*) AS c FROM scores WHERE user_id = ? AND game = 'memory' AND moves <= 20").get(userId) as { c: number }).c;
  const memory6x6Runs = (db.prepare("SELECT COUNT(*) AS c FROM scores WHERE user_id = ? AND game = 'memory' AND json_extract(metadata_json, '$.rows') = 6").get(userId) as { c: number }).c;
  const themesOwned = (db.prepare("SELECT COUNT(*) AS c FROM user_inventory WHERE user_id = ? AND item_type = 'theme'").get(userId) as { c: number }).c;
  const cosmeticsOwned = (db.prepare("SELECT COUNT(*) AS c FROM user_inventory WHERE user_id = ?").get(userId) as { c: number }).c;
  const campaignMemory = (db.prepare("SELECT COUNT(*) AS c FROM user_level_progress WHERE user_id = ? AND game = 'memory' AND completed_at IS NOT NULL").get(userId) as { c: number }).c;
  const campaign2048 = (db.prepare("SELECT COUNT(*) AS c FROM user_level_progress WHERE user_id = ? AND game = '2048' AND completed_at IS NOT NULL").get(userId) as { c: number }).c;
  const maxTileRow = db.prepare("SELECT MAX(CAST(json_extract(metadata_json, '$.maxTile') AS INTEGER)) AS m FROM scores WHERE user_id = ? AND game = '2048'").get(userId) as { m: number | null };
  const best2048 = (db.prepare("SELECT best_score FROM user_stats WHERE user_id = ? AND game = '2048'").get(userId) as { best_score: number | null } | undefined)?.best_score ?? 0;
  const coinsEarned = (db.prepare("SELECT COALESCE(SUM(amount), 0) AS s FROM currency_transactions WHERE user_id = ? AND amount > 0").get(userId) as { s: number }).s;
  return {
    games,
    memoryGames,
    dailyGames,
    perfectRuns: perfectRuns + (run?.perfect ? 1 : 0),
    fastMemoryRuns: fastMemoryRuns + (run?.fastMemory ? 1 : 0),
    aceMemoryRuns: aceMemoryRuns + (run?.aceMemory ? 1 : 0),
    memory6x6Runs: memory6x6Runs + (run?.memory6x6 ? 1 : 0),
    themesOwned,
    cosmeticsOwned,
    campaignMemory,
    campaign2048,
    maxTile: Math.max(maxTileRow.m ?? 0, run?.maxTile ?? 0),
    best2048Score: Math.max(best2048, run?.score ?? 0),
    level: user.level as number,
    dailyStreak: user.streak_current as number,
    weeklyStreak: user.weekly_streak as number,
    coinsEarned,
  };
}

export function evaluateAchievements(db: Database.Database, userId: number, run?: { game?: string; perfect?: boolean; fastMemory?: boolean; aceMemory?: boolean; memory6x6?: boolean; maxTile?: number; score?: number }): string[] {
  ensureUserSetup(db, userId);
  const ctx = userContext(db, userId, run);
  const already = new Set(
    (db.prepare("SELECT achievement_slug FROM user_achievements WHERE user_id = ?").all(userId) as Array<{ achievement_slug: string }>).map((row) => row.achievement_slug),
  );
  const newly: string[] = [];
  let changed = true;
  while (changed) {
    changed = false;
    const rows = db.prepare("SELECT * FROM achievements ORDER BY sort_order").all() as Array<Record<string, unknown>>;
    for (const row of rows) {
      const slug = row.slug as string;
      if (already.has(slug)) continue;
      const kind = row.criteria_kind as string;
      const value = row.criteria_value as number;
      let ok = false;
      switch (kind) {
        case "games": ok = ctx.games >= value; break;
        case "memory-games": ok = ctx.memoryGames >= value; break;
        case "memory-perfect": ok = ctx.perfectRuns >= value; break;
        case "memory-fast": ok = ctx.fastMemoryRuns >= value; break;
        case "memory-ace": ok = ctx.aceMemoryRuns >= value; break;
        case "memory-6x6": ok = ctx.memory6x6Runs >= value; break;
        case "daily-games": ok = ctx.dailyGames >= value; break;
        case "daily-streak": ok = ctx.dailyStreak >= value; break;
        case "weekly-streak": ok = ctx.weeklyStreak >= value; break;
        case "level": ok = ctx.level >= value; break;
        case "coins-earned": ok = ctx.coinsEarned >= value; break;
        case "themes-owned": ok = ctx.themesOwned >= value; break;
        case "cosmetics-owned": ok = ctx.cosmeticsOwned >= value; break;
        case "campaign-memory": ok = ctx.campaignMemory >= value; break;
        case "campaign-2048": ok = ctx.campaign2048 >= value; break;
        case "tile-2048": ok = ctx.maxTile >= 2048; break;
        case "tile-4096": ok = ctx.maxTile >= 4096; break;
        case "score-2048": ok = ctx.best2048Score >= value; break;
      }
      if (!ok) continue;
      db.prepare("INSERT OR IGNORE INTO user_achievements (user_id, achievement_slug) VALUES (?, ?)").run(userId, slug);
      const xp = row.xp_reward as number;
      const coins = row.coin_reward as number;
      if (xp > 0) {
        const u = db.prepare("SELECT xp, level FROM users WHERE id = ?").get(userId) as { xp: number; level: number };
        const newXp = u.xp + xp;
        db.prepare("UPDATE users SET xp = ?, level = ? WHERE id = ?").run(newXp, levelForXp(newXp), userId);
      }
      if (coins > 0) grantCoins(db, userId, coins, "achievement", slug);
      already.add(slug);
      newly.push(slug);
      changed = true;
    }
  }
  return newly;
}

function updateQuestProgress(db: Database.Database, userId: number, run: {
  game: string;
  mode: string;
  score: number;
  moves: number;
  xpGain: number;
  completed: boolean;
  levelId: string | null;
  stars: number;
}): string[] {
  ensureQuests(db, userId);
  const today = istDateKey();
  const currentWeek = weekKey(today);
  const questRows = db.prepare("SELECT * FROM user_quests WHERE user_id = ? AND (period_key = ? OR period_key = ?)").all(userId, today, currentWeek) as Array<Record<string, unknown>>;
  const completedNow: string[] = [];
  for (const row of questRows) {
    const quest = QUESTS.find((q) => q.slug === row.quest_slug);
    if (!quest) continue;
    if (quest.scope === "daily" && row.period_key !== today) continue;
    if (quest.scope === "weekly" && row.period_key !== currentWeek) continue;
    if (row.completed_at) continue;
    let increment = 0;
    const metric = quest.metric;
    if (metric === "games") increment = 1;
    else if (metric === "memory-games" && run.game === "memory") increment = 1;
    else if (metric === "2048-games" && run.game === "2048") increment = 1;
    else if (metric === "daily-games" && run.mode === "daily") increment = 1;
    else if (metric === "daily-memory" && run.game === "memory" && run.mode === "daily") increment = 1;
    else if (metric === "daily-2048" && run.game === "2048" && run.mode === "daily") increment = 1;
    else if (metric === "memory-efficient" && run.game === "memory" && run.moves <= 24) increment = 1;
    else if (metric === "2048-score-1000" && run.game === "2048" && run.score >= 1000) increment = 1;
    else if (metric === "campaign-level" && run.levelId && run.stars > 0) increment = 1;
    else if (metric === "xp-gained") increment = run.xpGain;
    if (increment <= 0) continue;
    const newProgress = Math.min(quest.target, (row.progress as number) + increment);
    const completedAt = newProgress >= quest.target ? new Date().toISOString() : null;
    db.prepare("UPDATE user_quests SET progress = ?, completed_at = COALESCE(completed_at, ?) WHERE user_id = ? AND quest_slug = ? AND period_key = ?").run(
      newProgress,
      completedAt,
      userId,
      quest.slug,
      row.period_key,
    );
    if (completedAt) completedNow.push(quest.slug);
  }
  return completedNow;
}

function updateStreaks(db: Database.Database, userId: number, isDaily: boolean): void {
  const today = istDateKey();
  const user = db.prepare("SELECT streak_current, streak_best, last_streak_date, weekly_streak, weekly_best, last_week_key, coins FROM users WHERE id = ?").get(userId) as Record<string, unknown>;
  if (isDaily) {
    let current = user.streak_current as number;
    const last = user.last_streak_date as string | null;
    if (last !== today) {
      const yesterday = addDaysToKey(today, -1);
      current = last === yesterday ? current + 1 : 1;
      const best = Math.max(user.streak_best as number, current);
      db.prepare("UPDATE users SET streak_current = ?, streak_best = ?, last_streak_date = ? WHERE id = ?").run(current, best, today, userId);
    }
    const currentWeek = weekKey(today);
    if (user.last_week_key !== currentWeek) {
      const previousWeek = user.last_week_key as string | null;
      let weekly = user.weekly_streak as number;
      if (previousWeek) {
        const prevRuns = (db.prepare("SELECT COALESCE(SUM(daily_runs),0) AS s FROM daily_activity WHERE user_id = ? AND activity_date >= ? AND activity_date <= ?").get(userId, weekStart(previousWeek), weekEnd(previousWeek)) as { s: number }).s;
        if (prevRuns >= 3) weekly += 1;
        else weekly = 1;
      } else {
        weekly = 1;
      }
      const weeklyBest = Math.max(user.weekly_best as number, weekly);
      db.prepare("UPDATE users SET weekly_streak = ?, weekly_best = ?, last_week_key = ? WHERE id = ?").run(weekly, weeklyBest, currentWeek, userId);
    }
  }
  db.prepare(`
    INSERT INTO daily_activity (user_id, activity_date, runs, daily_runs)
    VALUES (?, ?, 1, ?)
    ON CONFLICT(user_id, activity_date) DO UPDATE SET
      runs = runs + 1,
      daily_runs = daily_runs + excluded.daily_runs
  `).run(userId, today, isDaily ? 1 : 0);
}

function weekStart(week: string): string {
  // Approximate: find a date in that week by parsing year-week; use first day of year + (week-1)*7.
  const [year, w] = week.split("-W");
  const first = new Date(Date.UTC(Number(year), 0, 1));
  const day = first.getUTCDay() || 7;
  const monday = new Date(first);
  monday.setUTCDate(first.getUTCDate() - day + 1 + (Number(w) - 1) * 7);
  return monday.toISOString().slice(0, 10);
}

function weekEnd(week: string): string {
  const start = new Date(`${weekStart(week)}T00:00:00Z`);
  start.setUTCDate(start.getUTCDate() + 6);
  return start.toISOString().slice(0, 10);
}

function updateCampaignProgress(db: Database.Database, userId: number, levelId: string | null, game: string, score: number, moves: number, durationMs: number, stars: number): { bestStars: number; unlockedNext: string | null; firstCompletion: boolean } {
  if (!levelId) return { bestStars: 0, unlockedNext: null, firstCompletion: false };
  const level = db.prepare("SELECT * FROM campaign_levels WHERE id = ?").get(levelId) as Record<string, unknown> | undefined;
  if (!level) return { bestStars: 0, unlockedNext: null, firstCompletion: false };
  const existing = db.prepare("SELECT * FROM user_level_progress WHERE user_id = ? AND level_id = ?").get(userId, levelId) as Record<string, unknown> | undefined;
  const firstCompletion = !existing || !existing.completed_at;
  const bestStars = Math.max(existing?.best_stars as number ?? 0, stars);
  db.prepare(`
    INSERT INTO user_level_progress (user_id, level_id, game, best_stars, best_score, best_moves, best_time_ms, completed_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(user_id, level_id) DO UPDATE SET
      best_stars = excluded.best_stars,
      best_score = CASE WHEN excluded.best_score IS NULL THEN best_score ELSE MAX(COALESCE(best_score, 0), excluded.best_score) END,
      best_moves = CASE WHEN excluded.best_moves IS NULL THEN best_moves ELSE MIN(COALESCE(best_moves, 999999999), excluded.best_moves) END,
      best_time_ms = CASE WHEN excluded.best_time_ms IS NULL THEN best_time_ms ELSE MIN(COALESCE(best_time_ms, 999999999), excluded.best_time_ms) END,
      completed_at = COALESCE(completed_at, excluded.completed_at)
  `).run(
    userId,
    levelId,
    game,
    bestStars,
    stars > 0 ? score : null,
    stars > 0 ? moves : null,
    stars > 0 ? durationMs : null,
    stars > 0 ? new Date().toISOString() : null,
  );
  const next = db.prepare("SELECT id FROM campaign_levels WHERE game = ? AND unlock_level_id = ? ORDER BY sort_order LIMIT 1").get(game, levelId) as { id: string } | undefined;
  return { bestStars, unlockedNext: next?.id ?? null, firstCompletion };
}

export function applyRunRewards(db: Database.Database, params: {
  userId: number;
  session: { id: string; game: string; mode: string; variant: string; level_id: string | null; seed: string; challenge_date: string | null; started_at: string };
  score: number;
  moves: number;
  durationMs: number;
  actions: unknown[];
  actionTimes: number[] | null;
  metadata: Record<string, unknown>;
  stars: number;
  completed: boolean;
  runXp: number;
  runCoins: number;
  levelXpBonus?: number;
  levelCoinBonus?: number;
  isDaily: boolean;
  isCampaign: boolean;
}): RunRewardSummary {
  ensureUserSetup(db, params.userId);
  const levelBefore = (db.prepare("SELECT level FROM users WHERE id = ?").get(params.userId) as { level: number }).level;

  const reward = db.transaction(() => {
    const userBefore = db.prepare("SELECT xp, level, coins, streak_current, streak_best, weekly_streak, weekly_best FROM users WHERE id = ?").get(params.userId) as Record<string, unknown>;
    let totalXp = params.runXp;
    let totalCoins = params.runCoins;

    // User stats.
    const currentStats = db.prepare("SELECT * FROM user_stats WHERE user_id = ? AND game = ?").get(params.userId, params.session.game) as Record<string, unknown> | undefined;
    const bestScore = currentStats?.best_score == null ? params.score : Math.max(currentStats.best_score as number, params.score);
    const bestMoves = currentStats?.best_moves == null ? params.moves : Math.min(currentStats.best_moves as number, params.moves);
    const bestTime = currentStats?.best_time_ms == null ? params.durationMs : Math.min(currentStats.best_time_ms as number, params.durationMs);
    db.prepare(`
      INSERT INTO user_stats (user_id, game, games_played, best_score, best_moves, best_time_ms, total_score, updated_at)
      VALUES (?, ?, 1, ?, ?, ?, ?, ?)
      ON CONFLICT(user_id, game) DO UPDATE SET
        games_played = games_played + 1,
        best_score = excluded.best_score,
        best_moves = excluded.best_moves,
        best_time_ms = excluded.best_time_ms,
        total_score = total_score + excluded.total_score,
        updated_at = excluded.updated_at
    `).run(params.userId, params.session.game, bestScore, bestMoves, bestTime, params.score, new Date().toISOString());

    // Insert score.
    const insert = db.prepare(`
      INSERT INTO scores (user_id, game, mode, variant, score, moves, duration_ms, challenge_date, session_id, level_id, stars, ranked, verified, xp_awarded, coins_awarded, metadata_json, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const ranked = params.session.variant === "daily" || params.session.variant === "classic" || params.isCampaign ? 1 : 0;
    const verified = params.actions.length > 0 ? 1 : 0;
    const scoreId = Number(insert.run(
      params.userId,
      params.session.game,
      params.session.mode,
      params.session.variant,
      params.score,
      params.moves,
      params.durationMs,
      params.session.challenge_date,
      params.session.id,
      params.session.level_id,
      params.stars,
      ranked,
      verified,
      0,
      0,
      JSON.stringify(params.metadata),
      new Date().toISOString(),
    ).lastInsertRowid);

    // Streaks/activity.
    updateStreaks(db, params.userId, params.isDaily);

    // XP/coins base.
    const user = db.prepare("SELECT xp, level, coins FROM users WHERE id = ?").get(params.userId) as { xp: number; level: number; coins: number };
    let newXp = user.xp + totalXp;
    let newCoins = user.coins + totalCoins;
    db.prepare("UPDATE users SET xp = ?, level = ?, coins = ? WHERE id = ?").run(newXp, levelForXp(newXp), newCoins, params.userId);

    // Campaign progress + first-clear rewards.
    let campaignSummary: RunRewardSummary["campaign"] = null;
    if (params.isCampaign && params.session.level_id) {
      const progress = updateCampaignProgress(db, params.userId, params.session.level_id, params.session.game, params.score, params.moves, params.durationMs, params.stars);
      if (progress.firstCompletion && params.stars > 0) {
        const level = db.prepare("SELECT xp_reward, coin_reward FROM campaign_levels WHERE id = ?").get(params.session.level_id) as { xp_reward: number; coin_reward: number };
        totalXp += level.xp_reward;
        totalCoins += level.coin_reward;
        const bonusCoins = grantCoins(db, params.userId, level.coin_reward, "campaign-clear", params.session.level_id);
        totalCoins = totalCoins; // already added via grant? grant updates user; keep totalCoins consistent
        // grant xp
        const u = db.prepare("SELECT xp, level FROM users WHERE id = ?").get(params.userId) as { xp: number; level: number };
        db.prepare("UPDATE users SET xp = ?, level = ? WHERE id = ?").run(u.xp + level.xp_reward, levelForXp(u.xp + level.xp_reward), params.userId);
        newXp = (db.prepare("SELECT xp FROM users WHERE id = ?").get(params.userId) as { xp: number }).xp;
      }
      campaignSummary = {
        levelId: params.session.level_id,
        completed: params.stars > 0,
        bestStars: progress.bestStars,
        unlockedNext: progress.unlockedNext,
      };
    }

    // Quest progress.
    const questsCompleted = updateQuestProgress(db, params.userId, {
      game: params.session.game,
      mode: params.session.mode,
      score: params.score,
      moves: params.moves,
      xpGain: totalXp,
      completed: params.completed,
      levelId: params.session.level_id,
      stars: params.stars,
    });

    // Quest rewards.
    for (const slug of questsCompleted) {
      const quest = QUESTS.find((q) => q.slug === slug);
      if (!quest) continue;
      const periodKey = quest.scope === "daily" ? istDateKey() : weekKey(istDateKey());
      const row = db.prepare("SELECT claimed_at FROM user_quests WHERE user_id = ? AND quest_slug = ? AND period_key = ?").get(params.userId, slug, periodKey) as { claimed_at: string | null } | undefined;
      if (row && !row.claimed_at) {
        db.prepare("UPDATE user_quests SET claimed_at = ? WHERE user_id = ? AND quest_slug = ? AND period_key = ?").run(new Date().toISOString(), params.userId, slug, periodKey);
        totalXp += quest.xpReward;
        const u = db.prepare("SELECT xp, level FROM users WHERE id = ?").get(params.userId) as { xp: number; level: number };
        db.prepare("UPDATE users SET xp = ?, level = ? WHERE id = ?").run(u.xp + quest.xpReward, levelForXp(u.xp + quest.xpReward), params.userId);
        grantCoins(db, params.userId, quest.coinReward, "quest", `${slug}:${periodKey}`);
        totalCoins += quest.coinReward;
      }
    }

    // Insert replay.
    let replayId: number | null = null;
    try {
      replayId = Number(db.prepare("INSERT INTO replays (score_id, seed, game, actions_json, action_times_json, verified) VALUES (?, ?, ?, ?, ?, ?)").run(
        scoreId,
        params.session.seed,
        params.session.game,
        JSON.stringify(params.actions),
        params.actionTimes ? JSON.stringify(params.actionTimes) : null,
        params.actions.length > 0 ? 1 : 0,
      ).lastInsertRowid);
    } catch {
      replayId = null;
    }

    // Update score awarded amounts (approx).
    db.prepare("UPDATE scores SET xp_awarded = ?, coins_awarded = ? WHERE id = ?").run(totalXp, totalCoins, scoreId);

    // Complete session.
    db.prepare("UPDATE game_sessions SET status = 'completed', completed_at = ? WHERE id = ?").run(new Date().toISOString(), params.session.id);

    // Evaluate achievements (may grant more).
    const achievementSlugs = evaluateAchievements(db, params.userId, {
      game: params.session.game,
      perfect: Boolean(params.metadata.perfect),
      fastMemory: params.durationMs < 60000 && params.session.game === "memory",
      aceMemory: params.session.game === "memory" && params.moves <= 20,
      memory6x6: params.metadata.rows === 6,
      maxTile: params.metadata.maxTile as number | undefined,
      score: params.score,
    });

    const finalUser = db.prepare("SELECT xp, level, coins FROM users WHERE id = ?").get(params.userId) as { xp: number; level: number; coins: number };
    const finalStreak = db.prepare("SELECT streak_current, streak_best, weekly_streak, weekly_best FROM users WHERE id = ?").get(params.userId) as Record<string, number>;

    return {
      scoreId,
      replayId,
      xpGain: finalUser.xp - (userBefore.xp as number),
      coinGain: finalUser.coins - (userBefore.coins as number),
      user: { xp: finalUser.xp, level: finalUser.level, coins: finalUser.coins },
      achievements: achievementSlugs,
      questsCompleted,
      stars: params.stars,
      campaign: campaignSummary,
      streak: {
        current: finalStreak.streak_current,
        best: finalStreak.streak_best,
        weekly: finalStreak.weekly_streak,
        weeklyBest: finalStreak.weekly_best,
      },
    };
  });

  return reward();
}

export function getCatalog(db: Database.Database) {
  const themes = db.prepare("SELECT * FROM themes ORDER BY sort_order").all() as Array<Record<string, unknown>>;
  const cosmetics = db.prepare("SELECT * FROM cosmetic_items ORDER BY sort_order").all() as Array<Record<string, unknown>>;
  const achievements = db.prepare("SELECT * FROM achievements ORDER BY sort_order").all() as Array<Record<string, unknown>>;
  const quests = db.prepare("SELECT * FROM quests ORDER BY sort_order").all() as Array<Record<string, unknown>>;
  const levels = db.prepare("SELECT * FROM campaign_levels ORDER BY game, sort_order").all() as Array<Record<string, unknown>>;
  const events = db.prepare("SELECT * FROM seasonal_events ORDER BY sort_order").all() as Array<Record<string, unknown>>;
  const today = istDateKey();
  return {
    themes: themes.map((row) => ({
      id: row.id,
      name: row.name,
      description: row.description,
      emoji: row.emoji,
      palette: JSON.parse(row.palette_json as string),
      symbols: JSON.parse(row.symbols_json as string),
      unlockType: row.unlock_type,
      cost: row.cost,
      achievementSlug: row.achievement_slug,
      eventId: row.event_id,
      sortOrder: row.sort_order,
      active: row.event_id ? eventIsActive(SEASONAL_EVENTS.find((e) => e.id === row.event_id)!, today) : true,
    })),
    cosmetics: cosmetics.map((row) => ({
      id: row.id,
      type: row.type,
      name: row.name,
      description: row.description,
      style: row.style,
      unlockType: row.unlock_type,
      cost: row.cost,
      achievementSlug: row.achievement_slug,
      eventId: row.event_id,
      sortOrder: row.sort_order,
      active: row.event_id ? eventIsActive(SEASONAL_EVENTS.find((e) => e.id === row.event_id)!, today) : true,
    })),
    achievements: achievements.map((row) => ({
      slug: row.slug,
      title: row.title,
      description: row.description,
      emoji: row.emoji,
      xpReward: row.xp_reward,
      coinReward: row.coin_reward,
      criteriaKind: row.criteria_kind,
      criteriaValue: row.criteria_value,
      secret: Boolean(row.secret),
      sortOrder: row.sort_order,
    })),
    quests: quests.map((row) => ({
      slug: row.slug,
      scope: row.scope,
      title: row.title,
      description: row.description,
      metric: row.metric,
      target: row.target,
      xpReward: row.xp_reward,
      coinReward: row.coin_reward,
      emoji: row.emoji,
      sortOrder: row.sort_order,
    })),
    campaignLevels: levels.map((row) => ({
      id: row.id,
      game: row.game,
      levelNumber: row.level_number,
      world: row.world,
      worldName: row.world_name,
      name: row.name,
      config: JSON.parse(row.config_json as string),
      stars: JSON.parse(row.star_rules_json as string),
      xpReward: row.xp_reward,
      coinReward: row.coin_reward,
      unlockLevelId: row.unlock_level_id,
      sortOrder: row.sort_order,
    })),
    seasonalEvents: SEASONAL_EVENTS.map((event) => ({
      ...event,
      active: eventIsActive(event, today),
    })),
  };
}

export function getProgression(db: Database.Database, userId: number) {
  ensureUserSetup(db, userId);
  ensureQuests(db, userId);
  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(userId) as Record<string, unknown>;
  const prefs = db.prepare("SELECT * FROM user_preferences WHERE user_id = ?").get(userId) as Record<string, unknown> | undefined;
  const inventoryRows = db.prepare("SELECT item_type, item_id FROM user_inventory WHERE user_id = ?").all(userId) as Array<{ item_type: string; item_id: string }>;
  const inventory: Record<string, string[]> = {};
  for (const row of inventoryRows) {
    (inventory[row.item_type] ??= []).push(row.item_id);
  }
  const achievementRows = db.prepare(`
    SELECT a.*, ua.unlocked_at, ua.seen
    FROM achievements a
    LEFT JOIN user_achievements ua ON ua.achievement_slug = a.slug AND ua.user_id = ?
    ORDER BY a.sort_order
  `).all(userId) as Array<Record<string, unknown>>;
  const achievements = achievementRows.map((row) => ({
    slug: row.slug,
    title: row.title,
    description: row.description,
    emoji: row.emoji,
    xpReward: row.xp_reward,
    coinReward: row.coin_reward,
    unlocked: Boolean(row.unlocked_at),
    unlockedAt: row.unlocked_at ?? null,
    seen: Boolean(row.seen),
  }));

  const today = istDateKey();
  const currentWeek = weekKey(today);
  const questRows = db.prepare("SELECT * FROM user_quests WHERE user_id = ? AND (period_key = ? OR period_key = ?)").all(userId, today, currentWeek) as Array<Record<string, unknown>>;
  const toQuest = (row: Record<string, unknown>) => {
    const quest = QUESTS.find((q) => q.slug === row.quest_slug)!;
    return {
      slug: quest.slug,
      scope: quest.scope,
      title: quest.title,
      description: quest.description,
      emoji: quest.emoji,
      metric: quest.metric,
      target: quest.target,
      progress: row.progress as number,
      completed: Boolean(row.completed_at),
      claimed: Boolean(row.claimed_at),
      xpReward: quest.xpReward,
      coinReward: quest.coinReward,
    };
  };
  const dailyQuests = questRows.filter((row) => row.period_key === today).map(toQuest);
  const weeklyQuests = questRows.filter((row) => row.period_key === currentWeek).map(toQuest);

  const progressRows = db.prepare("SELECT * FROM user_level_progress WHERE user_id = ?").all(userId) as Array<Record<string, unknown>>;
  const progressMap = new Map(progressRows.map((row) => [row.level_id as string, row]));
  const campaign = {
    memory: (db.prepare("SELECT * FROM campaign_levels WHERE game = 'memory' ORDER BY sort_order").all() as Array<Record<string, unknown>>).map((row) => {
      const progress = progressMap.get(row.id as string);
      const unlocked = row.unlock_level_id === null || progressMap.has(row.unlock_level_id as string);
      return {
        id: row.id,
        game: row.game,
        levelNumber: row.level_number,
        world: row.world,
        worldName: row.world_name,
        name: row.name,
        config: JSON.parse(row.config_json as string),
        stars: JSON.parse(row.star_rules_json as string),
        xpReward: row.xp_reward,
        coinReward: row.coin_reward,
        unlockLevelId: row.unlock_level_id,
        unlocked,
        progress: progress
          ? { bestStars: progress.best_stars, bestScore: progress.best_score, bestMoves: progress.best_moves, bestTimeMs: progress.best_time_ms, completedAt: progress.completed_at }
          : null,
      };
    }),
    "2048": (db.prepare("SELECT * FROM campaign_levels WHERE game = '2048' ORDER BY sort_order").all() as Array<Record<string, unknown>>).map((row) => {
      const progress = progressMap.get(row.id as string);
      const unlocked = row.unlock_level_id === null || progressMap.has(row.unlock_level_id as string);
      return {
        id: row.id,
        game: row.game,
        levelNumber: row.level_number,
        world: row.world,
        worldName: row.world_name,
        name: row.name,
        config: JSON.parse(row.config_json as string),
        stars: JSON.parse(row.star_rules_json as string),
        xpReward: row.xp_reward,
        coinReward: row.coin_reward,
        unlockLevelId: row.unlock_level_id,
        unlocked,
        progress: progress
          ? { bestStars: progress.best_stars, bestScore: progress.best_score, bestMoves: progress.best_moves, bestTimeMs: progress.best_time_ms, completedAt: progress.completed_at }
          : null,
      };
    }),
  };

  return {
    user: {
      id: user.id,
      username: user.username,
      displayName: user.display_name,
      avatar: user.avatar,
      xp: user.xp,
      level: user.level,
      coins: user.coins,
      createdAt: user.created_at,
      email: user.email,
      equipped: {
        theme: user.equipped_theme,
        cardBack: user.equipped_back,
        border: user.equipped_border,
        flip: user.equipped_flip,
        matchEffect: user.equipped_match_effect,
        victoryEffect: user.equipped_victory_effect,
      },
      streak: {
        current: user.streak_current,
        best: user.streak_best,
        lastDate: user.last_streak_date,
        weekly: user.weekly_streak,
        weeklyBest: user.weekly_best,
        lastWeek: user.last_week_key,
      },
    },
    preferences: {
      highContrast: Boolean(prefs?.high_contrast ?? user.high_contrast),
      colorblindPatterns: Boolean(prefs?.colorblind_patterns ?? user.colorblind_patterns),
      reducedMotion: Boolean(prefs?.reduced_motion ?? user.reduced_motion),
      soundEnabled: Boolean(prefs?.sound_enabled ?? user.sound_enabled),
      sfxEnabled: Boolean(prefs?.sfx_enabled ?? user.sfx_enabled),
      masterVolume: Number(prefs?.master_volume ?? user.master_volume ?? 0.7),
    },
    inventory,
    achievements,
    quests: {
      daily: dailyQuests,
      weekly: weeklyQuests,
      dailyPeriodKey: today,
      weeklyPeriodKey: currentWeek,
    },
    campaign,
    seasonalEvents: SEASONAL_EVENTS.map((event) => ({ ...event, active: eventIsActive(event, today) })),
  };
}

export function purchaseItem(db: Database.Database, userId: number, itemType: string, itemId: string): { item: Record<string, unknown>; balance: number } {
  ensureUserSetup(db, userId);
  const table = itemType === "theme" ? "themes" : "cosmetic_items";
  const idColumn = "id";
  const row = db.prepare(`SELECT * FROM ${table} WHERE ${idColumn} = ?`).get(itemId) as Record<string, unknown> | undefined;
  if (!row) throw new Error("Item not found.");
  if (itemType !== "theme" && row.type !== itemType) throw new Error("Item type mismatch.");
  const inventoryType = itemType === "theme" ? "theme" : (row.type as string);
  const owned = db.prepare("SELECT 1 FROM user_inventory WHERE user_id = ? AND item_type = ? AND item_id = ?").get(userId, inventoryType, itemId);
  if (owned) throw new Error("You already own this item.");
  const today = istDateKey();
  const eventActive = row.event_id ? eventIsActive(SEASONAL_EVENTS.find((e) => e.id === row.event_id)!, today) : true;
  if (!eventActive) throw new Error("This item is not available right now.");
  const unlockType = row.unlock_type as string;
  if (unlockType === "achievement") {
    const achievementSlug = row.achievement_slug as string | null;
    if (!achievementSlug) throw new Error("This item is locked.");
    const unlocked = db.prepare("SELECT 1 FROM user_achievements WHERE user_id = ? AND achievement_slug = ?").get(userId, achievementSlug);
    if (!unlocked) throw new Error("Unlock the required achievement first.");
  }
  const cost = row.cost as number;
  const user = db.prepare("SELECT coins FROM users WHERE id = ?").get(userId) as { coins: number };
  if (user.coins < cost) throw new Error("Not enough coins.");
  const tx = db.transaction(() => {
    if (cost > 0) {
      const balance = user.coins - cost;
      db.prepare("UPDATE users SET coins = ? WHERE id = ?").run(balance, userId);
      db.prepare("INSERT INTO currency_transactions (user_id, amount, balance_after, reason, reference) VALUES (?, ?, ?, ?, ?)").run(userId, -cost, balance, "purchase", `${inventoryType}:${itemId}`);
    }
    db.prepare("INSERT INTO user_inventory (user_id, item_type, item_id) VALUES (?, ?, ?)").run(userId, inventoryType, itemId);
    // quest progress for cosmetic unlocks
    const currentWeek = weekKey(today);
    const questRows = db.prepare("SELECT * FROM user_quests WHERE user_id = ? AND period_key IN (?, ?)").all(userId, today, currentWeek) as Array<Record<string, unknown>>;
    for (const qrow of questRows) {
      const quest = QUESTS.find((q) => q.slug === qrow.quest_slug);
      if (quest?.metric === "cosmetic-unlocked" && !qrow.completed_at) {
        const newProgress = Math.min(quest.target, (qrow.progress as number) + 1);
        const completedAt = newProgress >= quest.target ? new Date().toISOString() : null;
        db.prepare("UPDATE user_quests SET progress = ?, completed_at = COALESCE(completed_at, ?) WHERE user_id = ? AND quest_slug = ? AND period_key = ?").run(newProgress, completedAt, userId, quest.slug, qrow.period_key);
      }
    }
    evaluateAchievements(db, userId);
  });
  tx();
  const balance = (db.prepare("SELECT coins FROM users WHERE id = ?").get(userId) as { coins: number }).coins;
  return { item: row, balance };
}

export function equipItem(db: Database.Database, userId: number, slot: string, itemId: string): void {
  ensureUserSetup(db, userId);
  const columnMap: Record<string, { type: string; column: string }> = {
    theme: { type: "theme", column: "equipped_theme" },
    cardBack: { type: "card_back", column: "equipped_back" },
    border: { type: "border", column: "equipped_border" },
    flip: { type: "flip", column: "equipped_flip" },
    matchEffect: { type: "match_effect", column: "equipped_match_effect" },
    victoryEffect: { type: "victory_effect", column: "equipped_victory_effect" },
  };
  const slotInfo = columnMap[slot];
  if (!slotInfo) throw new Error("Unknown equipment slot.");
  const owned = db.prepare("SELECT 1 FROM user_inventory WHERE user_id = ? AND item_type = ? AND item_id = ?").get(userId, slotInfo.type, itemId);
  const isDefault = (slot === "theme" && itemId === "animals") || (slot === "cardBack" && itemId === "sparkle") || (slot === "border" && itemId === "soft") || (slot === "flip" && itemId === "flip-soft") || (slot === "matchEffect" && itemId === "match-ripple") || (slot === "victoryEffect" && itemId === "victory-confetti");
  if (!owned && !isDefault) throw new Error("You do not own this item.");
  db.prepare(`UPDATE users SET ${slotInfo.column} = ? WHERE id = ?`).run(itemId, userId);
}

export function getPreferences(db: Database.Database, userId: number) {
  ensureUserSetup(db, userId);
  const prefs = db.prepare("SELECT * FROM user_preferences WHERE user_id = ?").get(userId) as Record<string, unknown>;
  const user = db.prepare("SELECT high_contrast, colorblind_patterns, reduced_motion, sound_enabled, sfx_enabled, master_volume FROM users WHERE id = ?").get(userId) as Record<string, unknown>;
  return {
    highContrast: Boolean(prefs.high_contrast ?? user.high_contrast),
    colorblindPatterns: Boolean(prefs.colorblind_patterns ?? user.colorblind_patterns),
    reducedMotion: Boolean(prefs.reduced_motion ?? user.reduced_motion),
    soundEnabled: Boolean(prefs.sound_enabled ?? user.sound_enabled),
    sfxEnabled: Boolean(prefs.sfx_enabled ?? user.sfx_enabled),
    masterVolume: Number(prefs.master_volume ?? user.master_volume ?? 0.7),
  };
}

export function updatePreferences(db: Database.Database, userId: number, patch: Partial<{
  highContrast: boolean;
  colorblindPatterns: boolean;
  reducedMotion: boolean;
  soundEnabled: boolean;
  sfxEnabled: boolean;
  masterVolume: number;
}>) {
  ensureUserSetup(db, userId);
  const current = getPreferences(db, userId);
  const next = { ...current, ...patch };
  db.prepare(`
    INSERT INTO user_preferences (user_id, high_contrast, colorblind_patterns, reduced_motion, sound_enabled, sfx_enabled, master_volume, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(user_id) DO UPDATE SET
      high_contrast = excluded.high_contrast,
      colorblind_patterns = excluded.colorblind_patterns,
      reduced_motion = excluded.reduced_motion,
      sound_enabled = excluded.sound_enabled,
      sfx_enabled = excluded.sfx_enabled,
      master_volume = excluded.master_volume,
      updated_at = excluded.updated_at
  `).run(
    userId,
    next.highContrast ? 1 : 0,
    next.colorblindPatterns ? 1 : 0,
    next.reducedMotion ? 1 : 0,
    next.soundEnabled ? 1 : 0,
    next.sfxEnabled ? 1 : 0,
    next.masterVolume,
    new Date().toISOString(),
  );
  db.prepare("UPDATE users SET high_contrast = ?, colorblind_patterns = ?, reduced_motion = ?, sound_enabled = ?, sfx_enabled = ?, master_volume = ? WHERE id = ?").run(
    next.highContrast ? 1 : 0,
    next.colorblindPatterns ? 1 : 0,
    next.reducedMotion ? 1 : 0,
    next.soundEnabled ? 1 : 0,
    next.sfxEnabled ? 1 : 0,
    next.masterVolume,
    userId,
  );
  return next;
}

export function getReplay(db: Database.Database, id: number) {
  const replayById = db.prepare("SELECT * FROM replays WHERE id = ?").get(id) as Record<string, unknown> | undefined;
  const replayByScore = db.prepare("SELECT * FROM replays WHERE score_id = ?").get(id) as Record<string, unknown> | undefined;
  const replay = replayById ?? replayByScore;
  if (!replay) return null;
  const scoreId = replay.score_id as number;
  const score = db.prepare("SELECT s.*, u.display_name, u.avatar, u.level FROM scores s JOIN users u ON u.id = s.user_id WHERE s.id = ?").get(scoreId) as Record<string, unknown> | undefined;
  if (!score) return null;
  const session = db.prepare("SELECT config_json, seed FROM game_sessions WHERE id = ?").get(score.session_id) as { config_json: string; seed: string } | undefined;
  return {
    scoreId,
    game: score.game,
    mode: score.mode,
    variant: score.variant,
    levelId: score.level_id,
    score: score.score,
    moves: score.moves,
    durationMs: score.duration_ms,
    completedAt: score.created_at,
    displayName: score.display_name,
    avatar: score.avatar,
    level: score.level,
    seed: replay.seed,
    sessionSeed: session?.seed ?? replay.seed,
    config: session ? JSON.parse(session.config_json) : {},
    actions: JSON.parse(replay.actions_json as string),
    actionTimes: replay.action_times_json ? JSON.parse(replay.action_times_json as string) : null,
    verified: Boolean(replay.verified),
  };
}

export function featuredReplay(db: Database.Database, game: string, period: string) {
  const today = istDateKey();
  let where = "s.game = ? AND s.mode = 'daily' AND s.challenge_date = ? AND s.ranked = 1";
  const params: unknown[] = [game, today];
  if (period === "all") {
    where = "s.game = ? AND s.ranked = 1";
    params.splice(1, 1);
  }
  const row = db.prepare(`
    SELECT s.id FROM scores s
    JOIN replays r ON r.score_id = s.id
    ${where.replace("s.game", "s.game")}
    ORDER BY ${game === "memory" ? "s.moves ASC, s.duration_ms ASC" : "s.score DESC, s.moves ASC, s.duration_ms ASC"}
    LIMIT 1
  `).get(...params) as { id: number } | undefined;
  if (!row) return null;
  return getReplay(db, row.id);
}
