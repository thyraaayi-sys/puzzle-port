import fs from "node:fs";
import path from "node:path";
import Database from "better-sqlite3";
import { migrateDatabase } from "./migrations";

export type DB = Database.Database;

export function initDb(filename = process.env.DATABASE_PATH || "./server/data/puzzleport.db"): DB {
  if (filename !== ":memory:") {
    fs.mkdirSync(path.dirname(path.resolve(filename)), { recursive: true });
  }
  const db = new Database(filename);
  db.pragma("journal_mode = WAL");
  db.pragma("foreign_keys = ON");
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE COLLATE NOCASE,
      email TEXT NOT NULL UNIQUE COLLATE NOCASE,
      display_name TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      avatar TEXT NOT NULL DEFAULT '🦊',
      xp INTEGER NOT NULL DEFAULT 0 CHECK (xp >= 0),
      level INTEGER NOT NULL DEFAULT 1 CHECK (level >= 1),
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );

    CREATE TABLE IF NOT EXISTS daily_challenges (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      game TEXT NOT NULL CHECK (game IN ('memory', '2048')),
      challenge_date TEXT NOT NULL,
      seed TEXT NOT NULL,
      config_json TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
      UNIQUE (game, challenge_date)
    );

    CREATE TABLE IF NOT EXISTS game_sessions (
      id TEXT PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      game TEXT NOT NULL CHECK (game IN ('memory', '2048')),
      mode TEXT NOT NULL CHECK (mode IN ('daily', 'classic')),
      status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'completed')),
      seed TEXT NOT NULL,
      challenge_date TEXT,
      started_at TEXT NOT NULL,
      completed_at TEXT
    );

    CREATE TABLE IF NOT EXISTS scores (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      game TEXT NOT NULL CHECK (game IN ('memory', '2048')),
      mode TEXT NOT NULL CHECK (mode IN ('daily', 'classic')),
      score INTEGER NOT NULL CHECK (score >= 0),
      moves INTEGER NOT NULL CHECK (moves >= 0),
      duration_ms INTEGER NOT NULL CHECK (duration_ms >= 0),
      challenge_date TEXT,
      session_id TEXT NOT NULL UNIQUE REFERENCES game_sessions(id) ON DELETE CASCADE,
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );

    CREATE TABLE IF NOT EXISTS user_stats (
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      game TEXT NOT NULL CHECK (game IN ('memory', '2048')),
      games_played INTEGER NOT NULL DEFAULT 0,
      best_score INTEGER,
      best_moves INTEGER,
      best_time_ms INTEGER,
      total_score INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
      PRIMARY KEY (user_id, game)
    );

    CREATE INDEX IF NOT EXISTS idx_scores_game_created ON scores(game, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_scores_daily ON scores(game, mode, challenge_date);
    CREATE INDEX IF NOT EXISTS idx_scores_user ON scores(user_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_sessions_user ON game_sessions(user_id, status);
    CREATE INDEX IF NOT EXISTS idx_daily_date ON daily_challenges(challenge_date);
  `);
  migrateDatabase(db, filename);
  return db;
}
