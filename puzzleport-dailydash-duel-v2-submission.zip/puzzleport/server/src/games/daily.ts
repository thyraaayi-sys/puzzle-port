import crypto from "node:crypto";
import type Database from "better-sqlite3";

export type GameKey = "memory" | "2048";

export const IST_TIMEZONE = "Asia/Kolkata";

export function istDateKey(now = new Date()): string {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: IST_TIMEZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(now);
  const get = (type: string) => parts.find((part) => part.type === type)?.value ?? "";
  return `${get("year")}-${get("month")}-${get("day")}`;
}

export function addDaysToKey(dateKey: string, days: number): string {
  const [year, month, day] = dateKey.split("-").map(Number);
  const date = new Date(Date.UTC(year, month - 1, day + days));
  return date.toISOString().slice(0, 10);
}

export function dailyWindow(dateKey: string): { startsAt: string; endsAt: string } {
  const nextKey = addDaysToKey(dateKey, 1);
  return {
    startsAt: new Date(`${dateKey}T00:00:00+05:30`).toISOString(),
    endsAt: new Date(`${nextKey}T00:00:00+05:30`).toISOString(),
  };
}

export function dailySeed(game: GameKey, dateKey: string): string {
  const secret = process.env.DAILY_SEED_SECRET;
  if (!secret) throw new Error("DAILY_SEED_SECRET is required to derive daily seeds.");
  return crypto.createHmac("sha256", secret).update(`puzzleport:daily:v1:${game}:${dateKey}`).digest("hex");
}

export const dailyConfigs: Record<GameKey, Record<string, number>> = {
  memory: { gridSize: 4, pairs: 8 },
  "2048": { size: 4, startTiles: 2 },
};

export type DailyRow = {
  id: number;
  game: GameKey;
  challenge_date: string;
  seed: string;
  config_json: string;
  created_at: string;
};

export function getOrCreateDaily(db: Database.Database, game: GameKey, dateKey: string): DailyRow {
  db.prepare(
    `INSERT OR IGNORE INTO daily_challenges (game, challenge_date, seed, config_json)
     VALUES (?, ?, ?, ?)`,
  ).run(game, dateKey, dailySeed(game, dateKey), JSON.stringify(dailyConfigs[game]));
  return db
    .prepare("SELECT * FROM daily_challenges WHERE game = ? AND challenge_date = ?")
    .get(game, dateKey) as DailyRow;
}
