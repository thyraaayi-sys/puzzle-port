import { hashSeed, mulberry32 } from "./game2048";

export const MEMORY_SYMBOLS = ["🍓", "🫐", "🍋", "🍑", "🍡", "🧁", "🌷", "⭐"] as const;

export type MemoryCard = {
  id: number;
  pairId: number;
  symbol: string;
  flipped: boolean;
  matched: boolean;
};

export type MemorySnapshot = {
  cards: MemoryCard[];
  moves: number;
  matchedPairs: number;
  locked: boolean;
  completed: boolean;
};

export function createMemoryDeck(
  seed: string,
  symbols: readonly string[] = MEMORY_SYMBOLS,
  pairCount = Math.min(8, symbols.length),
): MemoryCard[] {
  if (pairCount < 1 || pairCount > symbols.length) {
    throw new Error(`Memory needs between 1 and ${symbols.length} pairs.`);
  }
  const rng = mulberry32(hashSeed(seed));
  const cards: MemoryCard[] = [];
  for (let pairId = 0; pairId < pairCount; pairId += 1) {
    cards.push({ id: cards.length, pairId, symbol: symbols[pairId], flipped: false, matched: false });
    cards.push({ id: cards.length, pairId, symbol: symbols[pairId], flipped: false, matched: false });
  }
  for (let i = cards.length - 1; i > 0; i -= 1) {
    const j = Math.floor(rng() * (i + 1));
    [cards[i], cards[j]] = [cards[j], cards[i]];
  }
  return cards.map((card, index) => ({ ...card, id: index }));
}

export class MemoryGame {
  readonly deck: MemoryCard[];
  readonly symbols: string[];
  readonly pairCount: number;
  moves = 0;
  matchedPairs = 0;
  locked = false;
  completed = false;
  firstIndex: number | null = null;
  secondIndex: number | null = null;
  mismatches = 0;

  constructor(seed: string, symbols: readonly string[] = MEMORY_SYMBOLS, pairCount = Math.min(8, symbols.length)) {
    this.symbols = [...symbols];
    this.pairCount = pairCount;
    this.deck = createMemoryDeck(seed, symbols, pairCount);
  }

  flip(index: number): {
    ok: boolean;
    reason?: string;
    card?: MemoryCard;
    mismatch?: boolean;
    matched?: boolean;
    completed?: boolean;
  } {
    if (this.completed) return { ok: false, reason: "Game complete" };
    if (this.locked) return { ok: false, reason: "Waiting for cards to resolve" };
    const card = this.deck[index];
    if (!card) return { ok: false, reason: "Invalid card" };
    if (card.matched || card.flipped) return { ok: false, reason: "Card unavailable" };

    if (this.firstIndex === null) {
      card.flipped = true;
      this.firstIndex = index;
      return { ok: true, card };
    }

    this.secondIndex = index;
    card.flipped = true;
    this.moves += 1;
    const first = this.deck[this.firstIndex];
    if (first.pairId === card.pairId) {
      first.matched = true;
      card.matched = true;
      this.matchedPairs += 1;
      this.firstIndex = null;
      this.secondIndex = null;
      this.completed = this.matchedPairs === this.pairCount;
      return { ok: true, card, matched: true, completed: this.completed };
    }

    this.locked = true;
    this.mismatches += 1;
    return { ok: true, card, matched: false, mismatch: true };
  }

  resolve(): boolean {
    if (!this.locked || this.firstIndex === null || this.secondIndex === null) return false;
    this.deck[this.firstIndex].flipped = false;
    this.deck[this.secondIndex].flipped = false;
    this.firstIndex = null;
    this.secondIndex = null;
    this.locked = false;
    return true;
  }

  snapshot(): MemorySnapshot {
    return {
      cards: this.deck.map((card) => ({ ...card })),
      moves: this.moves,
      matchedPairs: this.matchedPairs,
      locked: this.locked,
      completed: this.completed,
    };
  }
}

export function memoryScore(moves: number, durationMs: number, pairs = 8): number {
  const seconds = Math.max(0, Math.floor(durationMs / 1000));
  return Math.max(50, pairs * 125 - moves * 12 - seconds * 2);
}

export function validateMemoryActions(
  seed: string,
  symbols: readonly string[],
  pairCount: number,
  actions: number[],
  elapsedMs: number,
): { ok: boolean; moves: number; mismatches: number; completed: boolean } {
  const game = new MemoryGame(seed, symbols, pairCount);
  for (const index of actions) {
    if (!Number.isInteger(index) || index < 0 || index >= pairCount * 2) {
      return { ok: false, moves: game.moves, mismatches: game.mismatches, completed: game.completed };
    }
    const result = game.flip(index);
    if (!result.ok) {
      return { ok: false, moves: game.moves, mismatches: game.mismatches, completed: game.completed };
    }
    if (result.mismatch) game.resolve();
  }
  return {
    ok: game.completed,
    moves: game.moves,
    mismatches: game.mismatches,
    completed: game.completed,
  };
}
