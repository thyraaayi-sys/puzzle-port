export type Direction = "left" | "right" | "up" | "down";
export type Board = number[][];
export type Rng = (() => number) & { getState: () => number; setState: (state: number) => void };

export function hashSeed(seed: string): number {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < seed.length; i += 1) {
    h ^= seed.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export function mulberry32(seed: number): Rng {
  let a = seed >>> 0;
  const rng = (() => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }) as Rng;
  rng.getState = () => a;
  rng.setState = (state: number) => {
    a = state >>> 0;
  };
  return rng;
}

export function emptyBoard(size = 4): Board {
  return Array.from({ length: size }, () => Array<number>(size).fill(0));
}

export function cloneBoard(board: Board): Board {
  return board.map((row) => [...row]);
}

export function spawnTile(board: Board, rng: Rng): Board {
  const empty: Array<[number, number]> = [];
  for (let r = 0; r < board.length; r += 1) {
    for (let c = 0; c < board.length; c += 1) {
      if (board[r][c] === 0) empty.push([r, c]);
    }
  }
  if (empty.length === 0) return board;
  const [row, col] = empty[Math.floor(rng() * empty.length)];
  const next = cloneBoard(board);
  next[row][col] = rng() < 0.9 ? 2 : 4;
  return next;
}

export function createGame(seed: string, size = 4): { board: Board; rng: Rng; score: number; moves: number } {
  const rng = mulberry32(hashSeed(seed));
  let board = emptyBoard(size);
  board = spawnTile(board, rng);
  board = spawnTile(board, rng);
  return { board, rng, score: 0, moves: 0 };
}

export function slideLine(line: number[]): { line: number[]; gained: number; moved: boolean } {
  const values = line.filter((value) => value !== 0);
  const merged: number[] = [];
  let gained = 0;
  for (let i = 0; i < values.length; i += 1) {
    if (i + 1 < values.length && values[i] === values[i + 1]) {
      const value = values[i] * 2;
      merged.push(value);
      gained += value;
      i += 1;
    } else {
      merged.push(values[i]);
    }
  }
  while (merged.length < line.length) merged.push(0);
  return {
    line: merged,
    gained,
    moved: merged.some((value, index) => value !== line[index]),
  };
}

function getLine(board: Board, direction: Direction, index: number): number[] {
  const size = board.length;
  const line: number[] = [];
  for (let i = 0; i < size; i += 1) {
    if (direction === "left") line.push(board[index][i]);
    else if (direction === "right") line.push(board[index][size - 1 - i]);
    else if (direction === "up") line.push(board[i][index]);
    else line.push(board[size - 1 - i][index]);
  }
  return line;
}

function setLine(board: Board, direction: Direction, index: number, line: number[]): void {
  const size = board.length;
  for (let i = 0; i < size; i += 1) {
    if (direction === "left") board[index][i] = line[i];
    else if (direction === "right") board[index][size - 1 - i] = line[i];
    else if (direction === "up") board[i][index] = line[i];
    else board[size - 1 - i][index] = line[i];
  }
}

export function moveBoard(board: Board, direction: Direction): { board: Board; gained: number; moved: boolean } {
  const next = cloneBoard(board);
  let gained = 0;
  let moved = false;
  const size = next.length;
  for (let index = 0; index < size; index += 1) {
    const line = getLine(next, direction, index);
    const result = slideLine(line);
    if (result.moved) moved = true;
    gained += result.gained;
    setLine(next, direction, index, result.line);
  }
  return { board: next, gained, moved };
}

export function hasMoves(board: Board): boolean {
  const size = board.length;
  for (let r = 0; r < size; r += 1) {
    for (let c = 0; c < size; c += 1) {
      if (board[r][c] === 0) return true;
      if (c + 1 < size && board[r][c] === board[r][c + 1]) return true;
      if (r + 1 < size && board[r][c] === board[r + 1][c]) return true;
    }
  }
  return false;
}

export function applyMove(
  board: Board,
  direction: Direction,
  rng: Rng,
): { board: Board; gained: number; moved: boolean; gameOver: boolean } {
  const result = moveBoard(board, direction);
  if (!result.moved) {
    return { board, gained: 0, moved: false, gameOver: !hasMoves(board) };
  }
  const spawned = spawnTile(result.board, rng);
  return { board: spawned, gained: result.gained, moved: true, gameOver: !hasMoves(spawned) };
}

export function maxTile(board: Board): number {
  return board.reduce((max, row) => Math.max(max, ...row), 0);
}

export type ReplayAction = Direction;

export class Game2048Engine {
  readonly size: number;
  readonly seed: string;
  rng: Rng;
  board: Board;
  score = 0;
  moves = 0;
  reached = false;
  gameOver = false;
  actions: Direction[] = [];
  private undoStack: Array<{ board: Board; score: number; moves: number; reached: boolean; rngState: number; actionsLength: number }> = [];

  constructor(seed: string, size = 4, startTiles = 2) {
    this.seed = seed;
    this.size = size;
    this.rng = mulberry32(hashSeed(seed));
    this.board = emptyBoard(size);
    for (let i = 0; i < startTiles; i += 1) this.board = spawnTile(this.board, this.rng);
  }

  apply(direction: Direction, record = true): { gained: number; moved: boolean; gameOver: boolean } {
    if (this.gameOver) return { gained: 0, moved: false, gameOver: true };
    const result = moveBoard(this.board, direction);
    if (!result.moved) {
      const over = !hasMoves(this.board);
      if (over) this.gameOver = true;
      return { gained: 0, moved: false, gameOver: over };
    }
    this.undoStack.push({
      board: cloneBoard(this.board),
      score: this.score,
      moves: this.moves,
      reached: this.reached,
      rngState: this.rng.getState(),
      actionsLength: this.actions.length,
    });
    if (this.undoStack.length > 200) this.undoStack.shift();
    this.board = spawnTile(result.board, this.rng);
    this.score += result.gained;
    this.moves += 1;
    if (maxTile(this.board) >= 2048) this.reached = true;
    this.gameOver = !hasMoves(this.board);
    if (record) this.actions.push(direction);
    return { gained: result.gained, moved: true, gameOver: this.gameOver };
  }

  undo(): boolean {
    const snapshot = this.undoStack.pop();
    if (!snapshot) return false;
    this.board = snapshot.board;
    this.score = snapshot.score;
    this.moves = snapshot.moves;
    this.reached = snapshot.reached;
    this.rng.setState(snapshot.rngState);
    this.actions = this.actions.slice(0, snapshot.actionsLength);
    this.gameOver = false;
    return true;
  }

  static fromActions(seed: string, size: number, actions: Direction[]): Game2048Engine {
    const engine = new Game2048Engine(seed, size);
    for (const action of actions) engine.apply(action, false);
    return engine;
  }
}

export function validate2048Actions(
  seed: string,
  size: number,
  actions: Direction[],
  expectedScore: number,
  expectedMoves: number,
): { ok: boolean; score: number; moves: number; maxTile: number; gameOver: boolean } {
  const engine = Game2048Engine.fromActions(seed, size, actions);
  return {
    ok:
      engine.moves === expectedMoves &&
      engine.score === expectedScore &&
      engine.moves === actions.length,
    score: engine.score,
    moves: engine.moves,
    maxTile: maxTile(engine.board),
    gameOver: engine.gameOver,
  };
}
