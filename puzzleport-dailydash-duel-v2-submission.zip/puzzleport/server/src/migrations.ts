import type Database from "better-sqlite3";
import { MEMORY_THEMES } from "./catalog/memoryThemes";
import { COSMETICS } from "./catalog/cosmetics";
import { ACHIEVEMENTS } from "./catalog/achievements";
import { QUESTS } from "./catalog/quests";
import { ALL_CAMPAIGN_LEVELS } from "./catalog/campaigns";
import { SEASONAL_EVENTS } from "./catalog/seasonal";

export const V2_MIGRATION_VERSION = 2;

function tableColumns(db: Database.Database, table: string): Set<string> {
  return new Set(
    (db.prepare(`PRAGMA table_info(${table})`).all() as Array<{ name: string }>).map((row) => row.name),
  );
}

function addColumn(db: Database.Database, table: string, name: string, definition: string): void {
  if (!tableColumns(db, table).has(name)) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${name} ${definition}`);
  }
}

function backupDatabase(db: Database.Database, filename: string): void {
  if (filename === ":memory:") return;
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const target = filename.replace(/\.db$/, `-pre-v2-${stamp}.db`);
  try {
    db.exec(`VACUUM INTO '${target.replace(/'/g, "''")}'`);
  } catch {
    // Best-effort backup; migration still proceeds because schema changes are additive.
  }
}

export function migrateDatabase(db: Database.Database, filename = process.env.DATABASE_PATH || "./server/data/puzzleport.db"): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version INTEGER PRIMARY KEY,
      applied_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );
  `);

  const currentVersion = (db.prepare("SELECT COALESCE(MAX(version), 0) AS version FROM schema_migrations").get() as { version: number }).version;
  if (currentVersion >= V2_MIGRATION_VERSION) return;

  backupDatabase(db, filename);

  const migrate = db.transaction(() => {
    // Extend users with progression and preference fields.
    addColumn(db, "users", "coins", "INTEGER NOT NULL DEFAULT 0 CHECK (coins >= 0)");
    addColumn(db, "users", "equipped_theme", "TEXT NOT NULL DEFAULT 'animals'");
    addColumn(db, "users", "equipped_back", "TEXT NOT NULL DEFAULT 'sparkle'");
    addColumn(db, "users", "equipped_border", "TEXT NOT NULL DEFAULT 'soft'");
    addColumn(db, "users", "equipped_flip", "TEXT NOT NULL DEFAULT 'flip-soft'");
    addColumn(db, "users", "equipped_match_effect", "TEXT NOT NULL DEFAULT 'match-ripple'");
    addColumn(db, "users", "equipped_victory_effect", "TEXT NOT NULL DEFAULT 'victory-confetti'");
    addColumn(db, "users", "streak_current", "INTEGER NOT NULL DEFAULT 0");
    addColumn(db, "users", "streak_best", "INTEGER NOT NULL DEFAULT 0");
    addColumn(db, "users", "last_streak_date", "TEXT");
    addColumn(db, "users", "weekly_streak", "INTEGER NOT NULL DEFAULT 0");
    addColumn(db, "users", "weekly_best", "INTEGER NOT NULL DEFAULT 0");
    addColumn(db, "users", "last_week_key", "TEXT");
    addColumn(db, "users", "high_contrast", "INTEGER NOT NULL DEFAULT 0");
    addColumn(db, "users", "colorblind_patterns", "INTEGER NOT NULL DEFAULT 0");
    addColumn(db, "users", "reduced_motion", "INTEGER NOT NULL DEFAULT 0");
    addColumn(db, "users", "sound_enabled", "INTEGER NOT NULL DEFAULT 1");
    addColumn(db, "users", "sfx_enabled", "INTEGER NOT NULL DEFAULT 1");
    addColumn(db, "users", "master_volume", "REAL NOT NULL DEFAULT 0.7");

    // Extend sessions and scores with V2 run metadata.
    addColumn(db, "game_sessions", "variant", "TEXT NOT NULL DEFAULT 'classic'");
    addColumn(db, "game_sessions", "level_id", "TEXT");
    addColumn(db, "game_sessions", "config_json", "TEXT NOT NULL DEFAULT '{}'");
    addColumn(db, "scores", "variant", "TEXT NOT NULL DEFAULT 'classic'");
    addColumn(db, "scores", "level_id", "TEXT");
    addColumn(db, "scores", "stars", "INTEGER NOT NULL DEFAULT 0");
    addColumn(db, "scores", "ranked", "INTEGER NOT NULL DEFAULT 0");
    addColumn(db, "scores", "verified", "INTEGER NOT NULL DEFAULT 0");
    addColumn(db, "scores", "xp_awarded", "INTEGER NOT NULL DEFAULT 0");
    addColumn(db, "scores", "coins_awarded", "INTEGER NOT NULL DEFAULT 0");
    addColumn(db, "scores", "metadata_json", "TEXT");

    // Backfill legacy rows.
    db.exec("UPDATE game_sessions SET variant = mode WHERE variant = 'classic' AND mode IN ('daily','classic')");
    db.exec("UPDATE scores SET ranked = CASE WHEN mode = 'daily' THEN 1 ELSE 0 END WHERE ranked = 0");
    db.exec("UPDATE scores SET variant = mode WHERE variant = 'classic' AND mode IN ('daily','classic')");

    // New V2 tables.
    db.exec(`
      CREATE TABLE IF NOT EXISTS user_preferences (
        user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
        high_contrast INTEGER NOT NULL DEFAULT 0,
        colorblind_patterns INTEGER NOT NULL DEFAULT 0,
        reduced_motion INTEGER NOT NULL DEFAULT 0,
        sound_enabled INTEGER NOT NULL DEFAULT 1,
        sfx_enabled INTEGER NOT NULL DEFAULT 1,
        master_volume REAL NOT NULL DEFAULT 0.7,
        updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
      );

      CREATE TABLE IF NOT EXISTS themes (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT NOT NULL,
        emoji TEXT NOT NULL,
        palette_json TEXT NOT NULL,
        symbols_json TEXT NOT NULL,
        unlock_type TEXT NOT NULL CHECK (unlock_type IN ('default','coins','achievement','event')),
        cost INTEGER NOT NULL DEFAULT 0 CHECK (cost >= 0),
        achievement_slug TEXT,
        event_id TEXT,
        sort_order INTEGER NOT NULL DEFAULT 0
      );

      CREATE TABLE IF NOT EXISTS cosmetic_items (
        id TEXT PRIMARY KEY,
        type TEXT NOT NULL CHECK (type IN ('card_back','border','flip','match_effect','victory_effect')),
        name TEXT NOT NULL,
        description TEXT NOT NULL,
        style TEXT NOT NULL,
        unlock_type TEXT NOT NULL CHECK (unlock_type IN ('default','coins','achievement','event')),
        cost INTEGER NOT NULL DEFAULT 0 CHECK (cost >= 0),
        achievement_slug TEXT,
        event_id TEXT,
        sort_order INTEGER NOT NULL DEFAULT 0
      );

      CREATE TABLE IF NOT EXISTS user_inventory (
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        item_type TEXT NOT NULL CHECK (item_type IN ('theme','card_back','border','flip','match_effect','victory_effect')),
        item_id TEXT NOT NULL,
        acquired_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
        PRIMARY KEY (user_id, item_type, item_id)
      );

      CREATE TABLE IF NOT EXISTS achievements (
        slug TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        emoji TEXT NOT NULL,
        xp_reward INTEGER NOT NULL DEFAULT 0 CHECK (xp_reward >= 0),
        coin_reward INTEGER NOT NULL DEFAULT 0 CHECK (coin_reward >= 0),
        criteria_kind TEXT NOT NULL,
        criteria_value INTEGER NOT NULL DEFAULT 0,
        secret INTEGER NOT NULL DEFAULT 0,
        sort_order INTEGER NOT NULL DEFAULT 0
      );

      CREATE TABLE IF NOT EXISTS user_achievements (
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        achievement_slug TEXT NOT NULL REFERENCES achievements(slug) ON DELETE CASCADE,
        unlocked_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
        seen INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (user_id, achievement_slug)
      );

      CREATE TABLE IF NOT EXISTS quests (
        slug TEXT PRIMARY KEY,
        scope TEXT NOT NULL CHECK (scope IN ('daily','weekly')),
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        metric TEXT NOT NULL,
        target INTEGER NOT NULL CHECK (target > 0),
        xp_reward INTEGER NOT NULL DEFAULT 0 CHECK (xp_reward >= 0),
        coin_reward INTEGER NOT NULL DEFAULT 0 CHECK (coin_reward >= 0),
        emoji TEXT NOT NULL,
        sort_order INTEGER NOT NULL DEFAULT 0
      );

      CREATE TABLE IF NOT EXISTS user_quests (
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        quest_slug TEXT NOT NULL REFERENCES quests(slug) ON DELETE CASCADE,
        period_key TEXT NOT NULL,
        progress INTEGER NOT NULL DEFAULT 0 CHECK (progress >= 0),
        completed_at TEXT,
        claimed_at TEXT,
        PRIMARY KEY (user_id, quest_slug, period_key)
      );

      CREATE TABLE IF NOT EXISTS campaign_levels (
        id TEXT PRIMARY KEY,
        game TEXT NOT NULL CHECK (game IN ('memory','2048')),
        level_number INTEGER NOT NULL,
        world INTEGER NOT NULL,
        world_name TEXT NOT NULL,
        name TEXT NOT NULL,
        config_json TEXT NOT NULL,
        star_rules_json TEXT NOT NULL,
        xp_reward INTEGER NOT NULL DEFAULT 0 CHECK (xp_reward >= 0),
        coin_reward INTEGER NOT NULL DEFAULT 0 CHECK (coin_reward >= 0),
        unlock_level_id TEXT,
        sort_order INTEGER NOT NULL DEFAULT 0,
        UNIQUE (game, level_number)
      );

      CREATE TABLE IF NOT EXISTS user_level_progress (
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        level_id TEXT NOT NULL REFERENCES campaign_levels(id) ON DELETE CASCADE,
        game TEXT NOT NULL CHECK (game IN ('memory','2048')),
        best_stars INTEGER NOT NULL DEFAULT 0 CHECK (best_stars BETWEEN 0 AND 3),
        best_score INTEGER,
        best_moves INTEGER,
        best_time_ms INTEGER,
        completed_at TEXT,
        PRIMARY KEY (user_id, level_id)
      );

      CREATE TABLE IF NOT EXISTS replays (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        score_id INTEGER NOT NULL UNIQUE REFERENCES scores(id) ON DELETE CASCADE,
        seed TEXT NOT NULL,
        game TEXT NOT NULL CHECK (game IN ('memory','2048')),
        actions_json TEXT NOT NULL,
        action_times_json TEXT,
        verified INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
      );

      CREATE TABLE IF NOT EXISTS currency_transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        amount INTEGER NOT NULL,
        balance_after INTEGER NOT NULL CHECK (balance_after >= 0),
        reason TEXT NOT NULL,
        reference TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
        UNIQUE (user_id, reason, reference)
      );

      CREATE TABLE IF NOT EXISTS daily_activity (
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        activity_date TEXT NOT NULL,
        runs INTEGER NOT NULL DEFAULT 0 CHECK (runs >= 0),
        daily_runs INTEGER NOT NULL DEFAULT 0 CHECK (daily_runs >= 0),
        PRIMARY KEY (user_id, activity_date)
      );

      CREATE TABLE IF NOT EXISTS seasonal_events (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT NOT NULL,
        emoji TEXT NOT NULL,
        starts_on TEXT NOT NULL,
        ends_on TEXT NOT NULL,
        theme_id TEXT NOT NULL,
        banner TEXT NOT NULL,
        sort_order INTEGER NOT NULL DEFAULT 0
      );
    `);

    // Seed catalogs.
    const insertTheme = db.prepare(`
      INSERT INTO themes (id, name, description, emoji, palette_json, symbols_json, unlock_type, cost, achievement_slug, event_id, sort_order)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET
        name = excluded.name,
        description = excluded.description,
        emoji = excluded.emoji,
        palette_json = excluded.palette_json,
        symbols_json = excluded.symbols_json,
        unlock_type = excluded.unlock_type,
        cost = excluded.cost,
        achievement_slug = excluded.achievement_slug,
        event_id = excluded.event_id,
        sort_order = excluded.sort_order
    `);
    for (const theme of MEMORY_THEMES) {
      insertTheme.run(
        theme.id,
        theme.name,
        theme.description,
        theme.emoji,
        JSON.stringify(theme.palette),
        JSON.stringify(theme.symbols),
        theme.unlockType,
        theme.cost,
        theme.achievementSlug ?? null,
        theme.eventId ?? null,
        theme.sortOrder,
      );
    }

    const insertCosmetic = db.prepare(`
      INSERT INTO cosmetic_items (id, type, name, description, style, unlock_type, cost, achievement_slug, event_id, sort_order)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET
        type = excluded.type,
        name = excluded.name,
        description = excluded.description,
        style = excluded.style,
        unlock_type = excluded.unlock_type,
        cost = excluded.cost,
        achievement_slug = excluded.achievement_slug,
        event_id = excluded.event_id,
        sort_order = excluded.sort_order
    `);
    for (const item of COSMETICS) {
      insertCosmetic.run(
        item.id,
        item.type,
        item.name,
        item.description,
        item.style,
        item.unlockType,
        item.cost,
        item.achievementSlug ?? null,
        item.eventId ?? null,
        item.sortOrder,
      );
    }

    const insertAchievement = db.prepare(`
      INSERT INTO achievements (slug, title, description, emoji, xp_reward, coin_reward, criteria_kind, criteria_value, secret, sort_order)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(slug) DO UPDATE SET
        title = excluded.title,
        description = excluded.description,
        emoji = excluded.emoji,
        xp_reward = excluded.xp_reward,
        coin_reward = excluded.coin_reward,
        criteria_kind = excluded.criteria_kind,
        criteria_value = excluded.criteria_value,
        secret = excluded.secret,
        sort_order = excluded.sort_order
    `);
    for (const achievement of ACHIEVEMENTS) {
      insertAchievement.run(
        achievement.slug,
        achievement.title,
        achievement.description,
        achievement.emoji,
        achievement.xpReward,
        achievement.coinReward,
        achievement.criteriaKind,
        achievement.criteriaValue,
        achievement.secret ? 1 : 0,
        achievement.sortOrder,
      );
    }

    const insertQuest = db.prepare(`
      INSERT INTO quests (slug, scope, title, description, metric, target, xp_reward, coin_reward, emoji, sort_order)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(slug) DO UPDATE SET
        scope = excluded.scope,
        title = excluded.title,
        description = excluded.description,
        metric = excluded.metric,
        target = excluded.target,
        xp_reward = excluded.xp_reward,
        coin_reward = excluded.coin_reward,
        emoji = excluded.emoji,
        sort_order = excluded.sort_order
    `);
    for (const quest of QUESTS) {
      insertQuest.run(
        quest.slug,
        quest.scope,
        quest.title,
        quest.description,
        quest.metric,
        quest.target,
        quest.xpReward,
        quest.coinReward,
        quest.emoji,
        quest.sortOrder,
      );
    }

    const insertLevel = db.prepare(`
      INSERT INTO campaign_levels (id, game, level_number, world, world_name, name, config_json, star_rules_json, xp_reward, coin_reward, unlock_level_id, sort_order)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET
        game = excluded.game,
        level_number = excluded.level_number,
        world = excluded.world,
        world_name = excluded.world_name,
        name = excluded.name,
        config_json = excluded.config_json,
        star_rules_json = excluded.star_rules_json,
        xp_reward = excluded.xp_reward,
        coin_reward = excluded.coin_reward,
        unlock_level_id = excluded.unlock_level_id,
        sort_order = excluded.sort_order
    `);
    for (const level of ALL_CAMPAIGN_LEVELS) {
      insertLevel.run(
        level.id,
        level.game,
        level.levelNumber,
        level.world,
        level.worldName,
        level.name,
        JSON.stringify(level.config),
        JSON.stringify(level.stars),
        level.xpReward,
        level.coinReward,
        level.unlockLevelId,
        level.sortOrder,
      );
    }

    const insertEvent = db.prepare(`
      INSERT INTO seasonal_events (id, name, description, emoji, starts_on, ends_on, theme_id, banner, sort_order)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET
        name = excluded.name,
        description = excluded.description,
        emoji = excluded.emoji,
        starts_on = excluded.starts_on,
        ends_on = excluded.ends_on,
        theme_id = excluded.theme_id,
        banner = excluded.banner,
        sort_order = excluded.sort_order
    `);
    for (const event of SEASONAL_EVENTS) {
      insertEvent.run(
        event.id,
        event.name,
        event.description,
        event.emoji,
        event.startsOn,
        event.endsOn,
        event.themeId,
        event.banner,
        event.sortOrder,
      );
    }

    // Grant default cosmetics to existing users.
    const users = db.prepare("SELECT id FROM users").all() as Array<{ id: number }>;
    const grant = db.prepare("INSERT OR IGNORE INTO user_inventory (user_id, item_type, item_id) VALUES (?, ?, ?)");
    for (const user of users) {
      grant.run(user.id, "theme", "animals");
      grant.run(user.id, "card_back", "sparkle");
      grant.run(user.id, "border", "soft");
      grant.run(user.id, "flip", "flip-soft");
      grant.run(user.id, "match_effect", "match-ripple");
      grant.run(user.id, "victory_effect", "victory-confetti");
      db.prepare("INSERT OR IGNORE INTO user_preferences (user_id) VALUES (?)").run(user.id);
    }

    db.prepare("INSERT OR REPLACE INTO schema_migrations (version) VALUES (?)").run(V2_MIGRATION_VERSION);
  });

  migrate();
}
