import type { RequestHandler } from "express";
import jwt from "jsonwebtoken";
import type { DB } from "./db";

export type AuthUser = {
  id: number;
  username: string;
  email: string;
  display_name: string;
  avatar: string;
  xp: number;
  level: number;
  created_at: string;
};

type TokenPayload = { sub: string; username: string };

export function signToken(user: Pick<AuthUser, "id" | "username">): string {
  return jwt.sign({ sub: String(user.id), username: user.username }, process.env.JWT_SECRET as string, {
    expiresIn: "7d",
    issuer: "puzzleport",
    audience: "puzzleport-web",
  });
}

function verifyToken(token: string): TokenPayload {
  return jwt.verify(token, process.env.JWT_SECRET as string, {
    issuer: "puzzleport",
    audience: "puzzleport-web",
  }) as TokenPayload;
}

function findUser(db: DB, id: number): AuthUser | undefined {
  return db.prepare("SELECT * FROM users WHERE id = ?").get(id) as AuthUser | undefined;
}

export function requireAuth(db: DB): RequestHandler {
  return (req, res, next) => {
    const header = req.header("authorization");
    const token = header?.startsWith("Bearer ") ? header.slice(7) : null;
    if (!token) {
      res.status(401).json({ error: { code: "AUTH_REQUIRED", message: "Please sign in to continue." } });
      return;
    }
    try {
      const payload = verifyToken(token);
      const user = findUser(db, Number(payload.sub));
      if (!user) {
        res.status(401).json({ error: { code: "AUTH_INVALID", message: "Account no longer exists." } });
        return;
      }
      req.user = user;
      next();
    } catch {
      res.status(401).json({ error: { code: "TOKEN_INVALID", message: "Session expired. Please sign in again." } });
    }
  };
}

export function optionalAuth(db: DB): RequestHandler {
  return (req, _res, next) => {
    const header = req.header("authorization");
    const token = header?.startsWith("Bearer ") ? header.slice(7) : null;
    if (!token) {
      next();
      return;
    }
    try {
      const payload = verifyToken(token);
      const user = findUser(db, Number(payload.sub));
      if (user) req.user = user;
    } catch {
      // Optional auth silently ignores stale tokens; private routes still reject.
    }
    next();
  };
}

declare global {
  namespace Express {
    interface Request {
      user?: AuthUser;
    }
  }
}
