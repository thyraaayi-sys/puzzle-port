import "dotenv/config";
import { z } from "zod";

const envSchema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  PORT: z.coerce.number().int().positive().default(4000),
  JWT_SECRET: z.string().min(32, "JWT_SECRET must be at least 32 characters"),
  DAILY_SEED_SECRET: z.string().min(32, "DAILY_SEED_SECRET must be at least 32 characters"),
  DATABASE_PATH: z.string().default("./server/data/puzzleport.db"),
});

const parsed = envSchema.safeParse(process.env);
if (!parsed.success) {
  console.error("Invalid server environment:", parsed.error.flatten().fieldErrors);
  throw new Error("Server environment validation failed");
}
export const env = parsed.data;
