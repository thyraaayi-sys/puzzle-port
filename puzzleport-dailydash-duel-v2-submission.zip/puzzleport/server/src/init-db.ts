import "dotenv/config";
import { initDb } from "./db";

const filename = process.env.DATABASE_PATH || "./server/data/puzzleport.db";
const db = initDb(filename);
const tables = db
  .prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' ORDER BY name")
  .all() as Array<{ name: string }>;
console.log(`Initialized SQLite database at ${filename}`);
console.log(`Tables: ${tables.map((table) => table.name).join(", ")}`);
db.close();
