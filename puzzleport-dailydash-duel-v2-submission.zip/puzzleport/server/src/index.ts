import { createApp } from "./app";
import { env } from "./env";
import { initDb } from "./db";

const db = initDb(env.DATABASE_PATH);
const app = createApp(db);
const server = app.listen(env.PORT, () => {
  console.log(`PuzzlePort API listening on http://localhost:${env.PORT}`);
  console.log(`SQLite database: ${env.DATABASE_PATH}`);
});

function shutdown(signal: string) {
  console.log(`${signal} received; shutting down.`);
  server.close(() => {
    db.close();
    process.exit(0);
  });
}

process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));
