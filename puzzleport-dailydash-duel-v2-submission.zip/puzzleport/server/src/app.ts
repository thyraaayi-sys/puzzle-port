import express, { type NextFunction, type Request, type RequestHandler, type Response } from "express";
import helmet from "helmet";
import bcrypt from "bcryptjs";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { z } from "zod";
import { requireAuth, optionalAuth, signToken, type AuthUser } from "./auth";
import type { DB } from "./db";
import {
  dailyConfigs,
  dailyWindow,
  getOrCreateDaily,
  IST_TIMEZONE,
  istDateKey,
  addDaysToKey,
  type GameKey,
} from "./games/daily";
import { memoryScore, validateMemoryActions } from "./games/memory";
import { validate2048Actions, Game2048Engine } from "./games/game2048";
import { MEMORY_THEMES, themeSymbols, getTheme } from "./catalog/memoryThemes";
import { getCatalog, getProgression, ensureUserSetup, applyRunRewards, purchaseItem, equipItem, getPreferences, updatePreferences, getReplay, featuredReplay, weekKey, evaluateAchievements } from "./progression";

type DbUser = AuthUser & { password_hash: string };

class HttpError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
    public details?: unknown,
  ) {
    super(message);
  }
}

const asyncHandler = (fn: (req: Request, res: Response) => Promise<void> | void): RequestHandler =>
  (req, res, next) => {
    Promise.resolve(fn(req, res)).catch(next);
  };

function validate<T>(schema: z.ZodType<T>, value: unknown): T {
  const result = schema.safeParse(value);
  if (!result.success) {
    throw new HttpError(400, "VALIDATION_ERROR", "Please check the submitted fields.", result.error.flatten());
  }
  return result.data;
}

function publicUser(user: AuthUser & { coins?: number }) {
  return {
    id: user.id,
    username: user.username,
    displayName: user.display_name,
    avatar: user.avatar,
    xp: user.xp,
    level: user.level,
    coins: (user as { coins?: number }).coins ?? 0,
    createdAt: user.created_at,
  };
}

function privateUser(user: AuthUser & { coins?: number; streak_current?: number; streak_best?: number }) {
  return {
    ...publicUser(user),
    email: user.email,
    streak: { current: (user as { streak_current?: number }).streak_current ?? 0, best: (user as { streak_best?: number }).streak_best ?? 0 },
  };
}

function isoNow(): string {
  return new Date().toISOString();
}

function levelForXp(xp: number): number {
  return Math.floor(Math.sqrt(Math.max(0, xp) / 100)) + 1;
}

function scoreBest(db: DB, userId: number, game: GameKey) {
  const order = game === "memory" ? "moves ASC, duration_ms ASC" : "score DESC, moves ASC, duration_ms ASC";
  return db
    .prepare(`SELECT score, moves, duration_ms, challenge_date, created_at FROM scores WHERE user_id = ? AND game = ? ORDER BY ${order} LIMIT 1`)
    .get(userId, game) as { score: number; moves: number; duration_ms: number; challenge_date: string | null; created_at: string } | undefined;
}

function mapScore(row: Record<string, unknown>) {
  return {
    id: row.id,
    game: row.game,
    mode: row.mode,
    score: row.score,
    moves: row.moves,
    durationMs: row.duration_ms,
    challengeDate: row.challenge_date,
    createdAt: row.created_at,
  };
}

function rateLimiter(limit: number, windowMs: number): RequestHandler {
  const buckets = new Map<string, { count: number; resetAt: number }>();
  return (req, res, next) => {
    const key = `${req.ip}:${req.path}`;
    const now = Date.now();
    const bucket = buckets.get(key);
    if (!bucket || bucket.resetAt <= now) {
      buckets.set(key, { count: 1, resetAt: now + windowMs });
      next();
      return;
    }
    bucket.count += 1;
    if (bucket.count > limit) {
      res.status(429).json({ error: { code: "RATE_LIMITED", message: "Too many attempts. Please wait a little." } });
      return;
    }
    next();
  };
}

const avatarSchema = z.enum(["🦊", "🐰", "🐼", "🐸", "🐱", "🦄", "🐙", "🍓"]);
const registerSchema = z
  .object({
    displayName: z.string().trim().min(2).max(40),
    username: z.string().trim().min(3).max(20).regex(/^[A-Za-z0-9_]+$/, "Use letters, numbers and underscores only."),
    email: z.string().trim().email().max(160),
    password: z.string().min(8).max(72),
    avatar: avatarSchema.optional(),
  })
  .strict();

const loginSchema = z
  .object({
    identifier: z.string().trim().min(3).max(160),
    password: z.string().min(1).max(72),
  })
  .strict();

const updateMeSchema = z
  .object({
    displayName: z.string().trim().min(2).max(40).optional(),
    avatar: avatarSchema.optional(),
  })
  .strict();

const sessionSchema = z
  .object({
    game: z.enum(["memory", "2048"]),
    mode: z.enum(["daily", "classic"]).optional(),
    variant: z
      .enum(["daily", "classic", "practice", "timed", "moves", "perfect", "campaign", "endless", "target"])
      .optional(),
    levelId: z.string().max(80).optional(),
    themeId: z.string().max(80).optional(),
  })
  .strict();
const scoreSchema = z
  .object({
    sessionId: z.string().uuid(),
    score: z.number().int().min(0).max(5_000_000).optional(),
    moves: z.number().int().min(1).max(100_000),
    actions: z
      .array(z.union([z.enum(["left", "right", "up", "down"]), z.number().int().min(0).max(10_000)]))
      .max(20_000)
      .optional(),
    actionTimes: z.array(z.number().int().min(0).max(12 * 60 * 60 * 1000)).max(20_000).optional(),
    elapsedMs: z.number().int().min(0).max(12 * 60 * 60 * 1000).optional(),
    mismatches: z.number().int().min(0).max(10_000).optional(),
    perfect: z.boolean().optional(),
  })
  .strict();

export function createApp(db: DB) {
  const app = express();
  app.disable("x-powered-by");
  app.disable("etag");
  app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
  app.use(express.json({ limit: "64kb" }));
  app.use("/api", (_req, res, next) => {
    res.setHeader("Cache-Control", "no-store");
    next();
  });

  const authLimiter = rateLimiter(40, 15 * 60 * 1000);
  const writeLimiter = rateLimiter(180, 15 * 60 * 1000);

  app.get("/api/v1/health", (_req, res) => {
    res.json({ status: "ok", service: "puzzleport-api", time: isoNow() });
  });

  app.get("/api/v1/ready", (_req, res) => {
    try {
      db.prepare("SELECT 1").get();
      res.json({ status: "ready", database: "sqlite" });
    } catch {
      res.status(503).json({ error: { code: "DB_UNAVAILABLE", message: "Database is not ready." } });
    }
  });

  app.post(
    "/api/v1/auth/register",
    authLimiter,
    asyncHandler(async (req, res) => {
      const input = validate(registerSchema, req.body);
      const username = input.username;
      const email = input.email.toLowerCase();
      const existing = db
        .prepare("SELECT id, username, email FROM users WHERE username = ? COLLATE NOCASE OR email = ? COLLATE NOCASE")
        .get(username, email) as { username: string; email: string } | undefined;
      if (existing) {
        const isEmail = existing.email.toLowerCase() === email;
        throw new HttpError(409, isEmail ? "EMAIL_TAKEN" : "USERNAME_TAKEN", isEmail ? "That email is already registered." : "That username is already taken.");
      }
      const passwordHash = await bcrypt.hash(input.password, 12);
      let id: number;
      try {
        const result = db
          .prepare("INSERT INTO users (username, email, display_name, password_hash, avatar) VALUES (?, ?, ?, ?, ?)")
          .run(username, email, input.displayName, passwordHash, input.avatar ?? "🦊");
        id = Number(result.lastInsertRowid);
      } catch (error) {
        if (String(error).includes("UNIQUE")) {
          throw new HttpError(409, "ACCOUNT_TAKEN", "That username or email is already registered.");
        }
        throw error;
      }
      const user = db.prepare("SELECT * FROM users WHERE id = ?").get(id) as AuthUser;
      ensureUserSetup(db, user.id);
      res.status(201).json({ token: signToken(user), user: privateUser(user) });
    }),
  );

  app.post(
    "/api/v1/auth/login",
    authLimiter,
    asyncHandler(async (req, res) => {
      const input = validate(loginSchema, req.body);
      const user = db
        .prepare("SELECT * FROM users WHERE email = ? COLLATE NOCASE OR username = ? COLLATE NOCASE")
        .get(input.identifier, input.identifier) as DbUser | undefined;
      if (!user || !(await bcrypt.compare(input.password, user.password_hash))) {
        throw new HttpError(401, "INVALID_CREDENTIALS", "Email/username or password is incorrect.");
      }
      ensureUserSetup(db, user.id);
      res.json({ token: signToken(user), user: privateUser(user) });
    }),
  );

  app.get("/api/v1/auth/me", requireAuth(db), (req, res) => {
    res.json({ user: privateUser(req.user as AuthUser) });
  });

  app.patch(
    "/api/v1/auth/me",
    requireAuth(db),
    asyncHandler(async (req, res) => {
      const input = validate(updateMeSchema, req.body);
      const user = req.user as AuthUser;
      db.prepare(
        "UPDATE users SET display_name = COALESCE(?, display_name), avatar = COALESCE(?, avatar) WHERE id = ?",
      ).run(input.displayName ?? null, input.avatar ?? null, user.id);
      const updated = db.prepare("SELECT * FROM users WHERE id = ?").get(user.id) as AuthUser;
      ensureUserSetup(db, updated.id);
      res.json({ user: privateUser(updated) });
    }),
  );

  app.post("/api/v1/auth/logout", requireAuth(db), (_req, res) => {
    // JWTs are stateless in this emergency build. The client removes its token.
    res.status(204).end();
  });

  app.get("/api/v1/daily", optionalAuth(db), (req, res) => {
    const dateKey = istDateKey();
    const window = dailyWindow(dateKey);
    const games = (["memory", "2048"] as GameKey[]).map((game) => {
      const row = getOrCreateDaily(db, game, dateKey);
      let best: ReturnType<typeof scoreBest> = undefined;
      if (req.user) best = scoreBest(db, req.user.id, game);
      const order = game === "memory" ? "moves ASC, duration_ms ASC" : "score DESC, moves ASC, duration_ms ASC";
      const completedToday = req.user
        ? db
            .prepare(
              `SELECT id FROM scores WHERE user_id = ? AND game = ? AND mode = 'daily' AND challenge_date = ? ORDER BY ${order} LIMIT 1`,
            )
            .get(req.user.id, game, dateKey)
        : undefined;
      return {
        game,
        seed: row.seed,
        config: JSON.parse(row.config_json),
        dateKey,
        completed: Boolean(completedToday),
        best: best
          ? { score: best.score, moves: best.moves, durationMs: best.duration_ms, challengeDate: best.challenge_date }
          : null,
      };
    });
    res.json({ dateKey, timezone: IST_TIMEZONE, startsAt: window.startsAt, endsAt: window.endsAt, games });
  });

  app.post(
    "/api/v1/sessions",
    requireAuth(db),
    writeLimiter,
    (req, res) => {
      const input = validate(sessionSchema, req.body);
      const user = req.user as AuthUser;
      const variant = input.variant ?? (input.mode === "classic" ? "classic" : "daily");
      const mode = input.mode ?? (variant === "daily" ? "daily" : "classic");
      if (input.mode && input.mode !== mode) {
        throw new HttpError(400, "VALIDATION_ERROR", "Mode and variant do not agree.");
      }
      const dateKey = istDateKey();
      let seed: string;
      let challengeDate: string | null = null;
      if (variant === "daily") {
        const challenge = getOrCreateDaily(db, input.game, dateKey);
        seed = challenge.seed;
        challengeDate = dateKey;
      } else if (variant === "campaign") {
        if (!input.levelId) throw new HttpError(400, "VALIDATION_ERROR", "Campaign sessions require a level.");
        const level = db.prepare("SELECT * FROM campaign_levels WHERE id = ? AND game = ?").get(input.levelId, input.game) as Record<string, unknown> | undefined;
        if (!level) throw new HttpError(404, "LEVEL_NOT_FOUND", "That campaign level does not exist.");
        const progress = db.prepare("SELECT 1 FROM user_level_progress WHERE user_id = ? AND level_id = ?").get(user.id, input.levelId);
        const unlocked = level.unlock_level_id === null || progress || db.prepare("SELECT 1 FROM user_level_progress WHERE user_id = ? AND level_id = ?").get(user.id, level.unlock_level_id as string);
        if (!unlocked) throw new HttpError(403, "LEVEL_LOCKED", "Complete the previous level first.");
        seed = (JSON.parse(level.config_json as string).seed as string) ?? crypto.randomUUID();
        challengeDate = null;
      } else {
        seed = crypto.randomUUID();
      }
      const id = crypto.randomUUID();
      const startedAt = isoNow();
      let levelConfig: Record<string, unknown> | null = null;
      if (variant === "campaign") {
        levelConfig = JSON.parse((db.prepare("SELECT config_json FROM campaign_levels WHERE id = ?").get(input.levelId) as { config_json: string }).config_json);
      }
      const config =
        variant === "daily"
          ? (input.game === "memory"
              ? { ...dailyConfigs.memory, rows: 4, cols: 4, pairs: 8, themeId: "animals", symbols: themeSymbols("animals", 8) }
              : dailyConfigs["2048"])
          : variant === "campaign" && levelConfig
            ? (input.game === "memory"
                ? { ...levelConfig, symbols: themeSymbols(String(levelConfig.themeId ?? "animals"), Number(levelConfig.pairs ?? 8)) }
                : levelConfig)
            : input.game === "memory"
              ? (() => {
                  const themeId = input.themeId ?? (user as AuthUser & { equipped_theme?: string }).equipped_theme ?? "animals";
                  const pairs = 8;
                  return { gridSize: 4, rows: 4, cols: 4, pairs, themeId, symbols: themeSymbols(themeId, pairs) };
                })()
              : { size: 4, startTiles: 2 };
      db.prepare(
        "INSERT INTO game_sessions (id, user_id, game, mode, variant, seed, challenge_date, level_id, config_json, started_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
      ).run(id, user.id, input.game, mode, variant, seed, challengeDate, input.levelId ?? null, JSON.stringify(config), startedAt);
      res.status(201).json({
        session: { id, game: input.game, mode, variant, levelId: input.levelId ?? null, seed, config, challengeDate, startedAt },
      });
    },
  );

  app.post(
    "/api/v1/scores",
    requireAuth(db),
    writeLimiter,
    asyncHandler(async (req, res) => {
      const input = validate(scoreSchema, req.body);
      const user = req.user as AuthUser;
      const session = db
        .prepare("SELECT * FROM game_sessions WHERE id = ? AND user_id = ?")
        .get(input.sessionId, user.id) as
        | {
            id: string;
            user_id: number;
            game: "memory" | "2048";
            mode: "daily" | "classic";
            variant: string;
            status: string;
            seed: string;
            challenge_date: string | null;
            level_id: string | null;
            config_json: string;
            started_at: string;
          }
        | undefined;
      if (!session) throw new HttpError(404, "SESSION_NOT_FOUND", "That game session was not found.");
      if (session.status === "completed") {
        const existing = db.prepare("SELECT * FROM scores WHERE session_id = ?").get(session.id) as Record<string, unknown> | undefined;
        if (!existing) throw new HttpError(409, "SCORE_MISSING", "This session is closed but has no saved score.");
        const current = db.prepare("SELECT xp, level, coins FROM users WHERE id = ?").get(user.id) as { xp: number; level: number; coins: number };
        res.json({
          score: mapScore(existing),
          xpGain: 0,
          coinGain: 0,
          user: { xp: current.xp, level: current.level, coins: current.coins },
          alreadySaved: true,
          achievements: [],
          questsCompleted: [],
          stars: existing.stars,
          campaign: null,
          replayId: (db.prepare("SELECT id FROM replays WHERE score_id = ?").get(existing.id) as { id: number } | undefined)?.id ?? null,
        });
        return;
      }
      if (Date.now() - Date.parse(session.started_at) > 12 * 60 * 60 * 1000) {
        throw new HttpError(410, "SESSION_EXPIRED", "This game session has expired.");
      }
      if (input.moves > 100_000 || input.moves < 1) {
        throw new HttpError(422, "INVALID_MOVES", "Impossible move count.");
      }
      if (session.game === "memory" && (input.moves < 8 || input.moves > 200)) {
        throw new HttpError(422, "INVALID_MOVES", "A completed Memory game must have between 8 and 200 move attempts.");
      }
      if (session.variant === "daily" && session.challenge_date !== istDateKey()) {
        throw new HttpError(410, "DAILY_EXPIRED", "Today's daily challenge window has closed.");
      }
      const durationMs = Math.max(0, Date.now() - Date.parse(session.started_at));
      if (durationMs > 12 * 60 * 60 * 1000) {
        throw new HttpError(410, "SESSION_EXPIRED", "This game session has expired.");
      }

      const config = JSON.parse(session.config_json || "{}") as Record<string, unknown>;
      const actions = input.actions ?? [];
      let score = input.score ?? 0;
      let moves = input.moves;
      let completed = true;
      let stars = 0;
      let metadata: Record<string, unknown> = { ...config };
      let runXp = 0;
      let runCoins = 0;
      const isDaily = session.variant === "daily";
      const isCampaign = session.variant === "campaign";

      if (session.game === "memory") {
        const themeId = (config.themeId as string) ?? "animals";
        const pairs = Number(config.pairs ?? 8);
        const rows = Number(config.rows ?? 4);
        const cols = Number(config.cols ?? 4);
        const symbols = themeSymbols(themeId, pairs);
        if (actions.length > 0) {
          const validation = validateMemoryActions(session.seed, symbols, pairs, actions as number[], durationMs);
          if (!validation.ok || validation.moves !== moves) {
            throw new HttpError(422, "INVALID_RUN", "Memory run does not match the recorded actions.");
          }
          moves = validation.moves;
          metadata = { ...metadata, themeId, rows, cols, pairs, mismatches: validation.mismatches, perfect: validation.mismatches === 0, maxTile: null };
          completed = validation.completed;
        } else {
          metadata = { ...metadata, themeId, rows, cols, pairs, mismatches: input.mismatches ?? 0, perfect: (input.mismatches ?? 0) === 0 };
        }
        if (!completed) throw new HttpError(422, "GAME_NOT_COMPLETE", "Finish the board before saving.");
        const timeLimit = Number(config.timeLimitMs ?? 0);
        const moveLimit = Number(config.moveLimit ?? 0);
        if (timeLimit > 0 && durationMs > timeLimit + 5000) throw new HttpError(422, "TIME_LIMIT_EXCEEDED", "Time limit exceeded.");
        if (moveLimit > 0 && moves > moveLimit) throw new HttpError(422, "MOVE_LIMIT_EXCEEDED", "Move limit exceeded.");
        score = memoryScore(moves, durationMs, pairs);
        const perfect = (metadata.perfect as boolean) ?? false;
        if (isCampaign && session.level_id) {
          const level = db.prepare("SELECT star_rules_json FROM campaign_levels WHERE id = ?").get(session.level_id) as { star_rules_json: string };
          const rules = JSON.parse(level.star_rules_json) as { threeMoves: number; twoMoves: number; threeTimeMs: number; twoTimeMs: number };
          if (moves <= rules.threeMoves && durationMs <= rules.threeTimeMs) stars = 3;
          else if (moves <= rules.twoMoves && durationMs <= rules.twoTimeMs) stars = 2;
          else stars = 1;
        }
        runXp = 35 + Math.max(0, 80 - moves * 2);
        runCoins = 5 + stars * 5 + Math.min(10, Math.floor(score / 200));
        void perfect;
      } else {
        const size = Number(config.size ?? 4);
        const targetTile = Number(config.targetTile ?? 0);
        const moveLimit = Number(config.moveLimit ?? 0);
        const timeLimit = Number(config.timeLimitMs ?? 0);
        let engineScore = score;
        let engineMoves = moves;
        let maxTile = 0;
        let gameOver = false;
        if (actions.length > 0) {
          const validation = validate2048Actions(session.seed, size, actions as Array<"left" | "right" | "up" | "down">, score, moves);
          if (!validation.ok) {
            throw new HttpError(422, "INVALID_RUN", "2048 run does not match the recorded actions.");
          }
          engineScore = validation.score;
          engineMoves = validation.moves;
          maxTile = validation.maxTile;
          gameOver = validation.gameOver;
          score = engineScore;
          moves = engineMoves;
        }
        if (timeLimit > 0 && durationMs > timeLimit + 5000) throw new HttpError(422, "TIME_LIMIT_EXCEEDED", "Time limit exceeded.");
        if (moveLimit > 0 && moves > moveLimit) throw new HttpError(422, "MOVE_LIMIT_EXCEEDED", "Move limit exceeded.");
        metadata = { ...metadata, size, maxTile, targetTile, moveLimit, timeLimitMs: timeLimit, gameOver };
        if (isCampaign && targetTile > 0) {
          completed = maxTile >= targetTile && (moveLimit === 0 || moves <= moveLimit) && (timeLimit === 0 || durationMs <= timeLimit + 5000);
          if (completed) {
            const level = db.prepare("SELECT star_rules_json FROM campaign_levels WHERE id = ?").get(session.level_id) as { star_rules_json: string };
            const rules = JSON.parse(level.star_rules_json) as { threeMoves: number; twoMoves: number; threeTimeMs: number; twoTimeMs: number };
            if (moves <= rules.threeMoves && durationMs <= rules.threeTimeMs) stars = 3;
            else if (moves <= rules.twoMoves && durationMs <= rules.twoTimeMs) stars = 2;
            else stars = 1;
          }
        } else {
          completed = moves > 0;
        }
        if (score > 5_000_000) throw new HttpError(422, "INVALID_SCORE", "Score is outside the accepted range.");
        if (session.game === "2048" && actions.length === 0 && (input.score ?? 0) > 5_000_000) {
          throw new HttpError(422, "INVALID_SCORE", "Score is outside the accepted range.");
        }
        runXp = 20 + Math.min(150, Math.floor(score / 200));
        runCoins = 5 + stars * 5 + Math.min(15, Math.floor(score / 500));
      }

      if (score > 5_000_000) throw new HttpError(422, "INVALID_SCORE", "Score is outside the accepted range.");

      const xpGain = runXp;
      const completedAt = isoNow();
      const result = applyRunRewards(db, {
        userId: user.id,
        session,
        score,
        moves,
        durationMs,
        actions,
        actionTimes: input.actionTimes ?? null,
        metadata,
        stars,
        completed,
        runXp,
        runCoins,
        isDaily,
        isCampaign,
      });

      res.status(201).json({
        score: {
          id: result.scoreId,
          game: session.game,
          mode: session.mode,
          variant: session.variant,
          score,
          moves,
          durationMs,
          challengeDate: session.challenge_date,
          createdAt: completedAt,
          stars,
        },
        xpGain: result.xpGain,
        coinGain: result.coinGain,
        user: result.user,
        alreadySaved: false,
        achievements: result.achievements,
        questsCompleted: result.questsCompleted,
        stars: result.stars,
        campaign: result.campaign,
        replayId: result.replayId,
      });
    }),
  );

  app.get("/api/v1/leaderboards", optionalAuth(db), (req, res) => {
    const game = z.enum(["memory", "2048"]).safeParse(req.query.game);
    if (!game.success) throw new HttpError(400, "VALIDATION_ERROR", "Choose a valid game.");
    const periodRaw = String(req.query.period ?? "daily");
    const period = z.enum(["daily", "weekly", "all"]).safeParse(periodRaw);
    if (!period.success) throw new HttpError(400, "VALIDATION_ERROR", "Choose daily, weekly, or all-time.");
    const variant = req.query.variant ? String(req.query.variant) : undefined;
    const levelId = req.query.levelId ? String(req.query.levelId) : undefined;
    const limit = Math.min(50, Math.max(1, Number(req.query.limit ?? 25) || 25));
    const dateKey = istDateKey();
    const week = weekKey(dateKey);
    const order = game.data === "memory" ? "s.moves ASC, s.duration_ms ASC, s.created_at ASC" : "s.score DESC, s.moves ASC, s.duration_ms ASC, s.created_at ASC";

    let where = "WHERE s.game = ?";
    const params: unknown[] = [game.data];
    if (period.data === "daily") {
      where += " AND s.mode = 'daily' AND s.challenge_date = ?";
      params.push(dateKey);
      if (!variant || variant === "daily") where += " AND s.variant = 'daily'";
      else where += " AND s.variant = ?";
      if (variant && variant !== "daily") params.push(variant);
    } else if (period.data === "weekly") {
      where += " AND s.created_at >= ? AND s.created_at < ?";
      params.push(new Date(`${addDaysToKey(dateKey, -6)}T00:00:00+05:30`).toISOString());
      params.push(new Date(`${addDaysToKey(dateKey, 1)}T00:00:00+05:30`).toISOString());
      if (variant) {
        where += " AND s.variant = ?";
        params.push(variant);
      } else {
        where += " AND s.variant IN ('daily', 'classic') AND s.ranked = 1";
      }
    } else {
      if (variant) {
        where += " AND s.variant = ?";
        params.push(variant);
        if (levelId) {
          where += " AND s.level_id = ?";
          params.push(levelId);
        }
      } else {
        where += " AND s.variant IN ('daily', 'classic') AND s.ranked = 1 AND s.level_id IS NULL";
      }
    }
    if (levelId && period.data !== "all") {
      where += " AND s.level_id = ?";
      params.push(levelId);
    }

    const rows = db
      .prepare(
        `SELECT s.id AS score_id, s.user_id, u.username, u.display_name, u.avatar, u.level, s.score, s.moves, s.duration_ms, s.created_at, s.variant, s.level_id, CASE WHEN r.id IS NULL THEN 0 ELSE 1 END AS has_replay
         FROM scores s JOIN users u ON u.id = s.user_id
         LEFT JOIN replays r ON r.score_id = s.id
         ${where} ORDER BY ${order}`,
      )
      .all(...params) as Array<Record<string, unknown>>;

    const seen = new Set<number>();
    const unique = rows.filter((row) => {
      if (seen.has(row.user_id as number)) return false;
      seen.add(row.user_id as number);
      return true;
    });

    // Previous period for movement indicators.
    let previousMap = new Map<number, number>();
    if (period.data === "daily" || period.data === "weekly") {
      const prevDate = period.data === "daily" ? addDaysToKey(dateKey, -1) : addDaysToKey(dateKey, -7);
      let prevWhere = "WHERE s.game = ? AND s.mode = 'daily' AND s.challenge_date = ?";
      const prevParams: unknown[] = [game.data, prevDate];
      if (!variant || variant === "daily") prevWhere += " AND s.variant = 'daily'";
      else {
        prevWhere = "WHERE s.game = ? AND s.created_at >= ? AND s.created_at < ?";
        prevParams.length = 0;
        prevParams.push(game.data, new Date(`${addDaysToKey(prevDate, -6)}T00:00:00+05:30`).toISOString(), new Date(`${addDaysToKey(prevDate, 1)}T00:00:00+05:30`).toISOString());
        if (variant) {
          prevWhere += " AND s.variant = ?";
          prevParams.push(variant);
        } else {
          prevWhere += " AND s.variant IN ('daily', 'classic') AND s.ranked = 1";
        }
      }
      const prevRows = db
        .prepare(`SELECT s.user_id FROM scores s ${prevWhere} ORDER BY ${order}`)
        .all(...prevParams) as Array<{ user_id: number }>;
      const prevSeen = new Set<number>();
      let rank = 0;
      for (const row of prevRows) {
        if (prevSeen.has(row.user_id)) continue;
        prevSeen.add(row.user_id);
        rank += 1;
        if (!previousMap.has(row.user_id)) previousMap.set(row.user_id, rank);
      }
    }

    const entries = unique.slice(0, limit).map((row, index) => ({
      rank: index + 1,
      scoreId: row.score_id,
      username: row.username,
      displayName: row.display_name,
      avatar: row.avatar,
      level: row.level,
      game: game.data,
      variant: row.variant,
      levelId: row.level_id,
      score: row.score,
      moves: row.moves,
      durationMs: row.duration_ms,
      completedAt: row.created_at,
      hasReplay: Boolean(row.has_replay),
      movement: previousMap.has(row.user_id as number) ? (previousMap.get(row.user_id as number)! - (index + 1)) : null,
    }));

    const meIndex = req.user ? unique.findIndex((row) => row.user_id === (req.user as AuthUser).id) : -1;
    const meRow = meIndex >= 0 ? unique[meIndex] : null;
    const me = meRow
      ? {
          rank: meIndex + 1,
          scoreId: meRow.score_id,
          username: meRow.username,
          displayName: meRow.display_name,
          avatar: meRow.avatar,
          level: meRow.level,
          game: game.data,
          variant: meRow.variant,
          levelId: meRow.level_id,
          score: meRow.score,
          moves: meRow.moves,
          durationMs: meRow.duration_ms,
          completedAt: meRow.created_at,
          hasReplay: Boolean(meRow.has_replay),
          movement: previousMap.has(meRow.user_id as number) ? previousMap.get(meRow.user_id as number)! - (meIndex + 1) : null,
        }
      : null;

    res.json({
      game: game.data,
      period: period.data,
      variant: variant ?? null,
      levelId: levelId ?? null,
      dateKey: period.data === "daily" ? dateKey : period.data === "weekly" ? week : null,
      weekKey: period.data === "weekly" ? week : null,
      timezone: IST_TIMEZONE,
      entries,
      me,
    });
  });

  app.get("/api/v1/catalog", (_req, res) => {
    res.json(getCatalog(db));
  });

  app.get("/api/v1/progression", requireAuth(db), (req, res) => {
    ensureUserSetup(db, (req.user as AuthUser).id);
    res.json(getProgression(db, (req.user as AuthUser).id));
  });

  app.get("/api/v1/achievements", requireAuth(db), (req, res) => {
    ensureUserSetup(db, (req.user as AuthUser).id);
    const progression = getProgression(db, (req.user as AuthUser).id);
    res.json({ achievements: progression.achievements, quests: progression.quests });
  });

  app.get("/api/v1/quests", requireAuth(db), (req, res) => {
    ensureUserSetup(db, (req.user as AuthUser).id);
    const progression = getProgression(db, (req.user as AuthUser).id);
    res.json({ quests: progression.quests });
  });

  app.post("/api/v1/quests/:slug/claim", requireAuth(db), writeLimiter, asyncHandler(async (req, res) => {
    const user = req.user as AuthUser;
    ensureUserSetup(db, user.id);
    const slug = String(req.params.slug);
    const quest = (db.prepare("SELECT * FROM quests WHERE slug = ?").get(slug) as Record<string, unknown> | undefined);
    if (!quest) throw new HttpError(404, "QUEST_NOT_FOUND", "That quest does not exist.");
    const today = istDateKey();
    const week = weekKey(today);
    const periodKey = quest.scope === "daily" ? today : week;
    const row = db.prepare("SELECT * FROM user_quests WHERE user_id = ? AND quest_slug = ? AND period_key = ?").get(user.id, slug, periodKey) as Record<string, unknown> | undefined;
    if (!row || !row.completed_at) throw new HttpError(409, "QUEST_NOT_COMPLETE", "Complete the quest before claiming.");
    if (row.claimed_at) throw new HttpError(409, "QUEST_ALREADY_CLAIMED", "This quest reward was already claimed.");
    db.prepare("UPDATE user_quests SET claimed_at = ? WHERE user_id = ? AND quest_slug = ? AND period_key = ?").run(new Date().toISOString(), user.id, slug, periodKey);
    const xpReward = quest.xp_reward as number;
    const coinReward = quest.coin_reward as number;
    const u = db.prepare("SELECT xp, level FROM users WHERE id = ?").get(user.id) as { xp: number; level: number };
    db.prepare("UPDATE users SET xp = ?, level = ? WHERE id = ?").run(u.xp + xpReward, Math.floor(Math.sqrt(Math.max(0, u.xp + xpReward) / 100)) + 1, user.id);
    if (coinReward > 0) {
      const balance = (db.prepare("SELECT coins FROM users WHERE id = ?").get(user.id) as { coins: number }).coins + coinReward;
      db.prepare("UPDATE users SET coins = ? WHERE id = ?").run(balance, user.id);
      db.prepare("INSERT OR IGNORE INTO currency_transactions (user_id, amount, balance_after, reason, reference) VALUES (?, ?, ?, ?, ?)").run(user.id, coinReward, balance, "quest", `${slug}:${periodKey}`);
    }
    evaluateAchievements(db, user.id);
    const updated = db.prepare("SELECT xp, level, coins FROM users WHERE id = ?").get(user.id) as { xp: number; level: number; coins: number };
    res.json({ user: updated, xpGain: xpReward, coinGain: coinReward });
  }));

  app.post("/api/v1/shop/purchase", requireAuth(db), writeLimiter, asyncHandler(async (req, res) => {
    const user = req.user as AuthUser;
    const input = validate(z.object({ itemType: z.string(), itemId: z.string() }).strict(), req.body);
    try {
      const result = purchaseItem(db, user.id, input.itemType, input.itemId);
      res.json({ balance: result.balance, item: result.item });
    } catch (error) {
      throw new HttpError(400, "PURCHASE_FAILED", (error as Error).message);
    }
  }));

  app.post("/api/v1/inventory/equip", requireAuth(db), writeLimiter, asyncHandler(async (req, res) => {
    const user = req.user as AuthUser;
    const input = validate(z.object({ slot: z.string(), itemId: z.string() }).strict(), req.body);
    try {
      equipItem(db, user.id, input.slot, input.itemId);
    } catch (error) {
      throw new HttpError(400, "EQUIP_FAILED", (error as Error).message);
    }
    res.status(204).end();
  }));

  app.get("/api/v1/preferences", requireAuth(db), (req, res) => {
    res.json({ preferences: getPreferences(db, (req.user as AuthUser).id) });
  });

  app.patch("/api/v1/preferences", requireAuth(db), writeLimiter, asyncHandler(async (req, res) => {
    const user = req.user as AuthUser;
    const input = validate(z.object({
      highContrast: z.boolean().optional(),
      colorblindPatterns: z.boolean().optional(),
      reducedMotion: z.boolean().optional(),
      soundEnabled: z.boolean().optional(),
      sfxEnabled: z.boolean().optional(),
      masterVolume: z.number().min(0).max(1).optional(),
    }).strict(), req.body);
    const preferences = updatePreferences(db, user.id, input);
    res.json({ preferences });
  }));

  app.get("/api/v1/replays/:scoreId", (req, res) => {
    const scoreId = Number(req.params.scoreId);
    if (!Number.isInteger(scoreId)) throw new HttpError(400, "VALIDATION_ERROR", "Invalid replay id.");
    const replay = getReplay(db, scoreId);
    if (!replay) throw new HttpError(404, "REPLAY_NOT_FOUND", "That replay is not available.");
    res.json({ replay });
  });

  app.get("/api/v1/replays/featured", (req, res) => {
    const game = z.enum(["memory", "2048"]).safeParse(req.query.game ?? "2048");
    if (!game.success) throw new HttpError(400, "VALIDATION_ERROR", "Choose a valid game.");
    const period = z.enum(["daily", "all"]).safeParse(req.query.period ?? "daily");
    if (!period.success) throw new HttpError(400, "VALIDATION_ERROR", "Choose a valid period.");
    const replay = featuredReplay(db, game.data, period.data);
    if (!replay) throw new HttpError(404, "REPLAY_NOT_FOUND", "No replay is available for that board.");
    res.json({ replay });
  });

  app.get("/api/v1/stats/me", requireAuth(db), (req, res) => {
    const user = req.user as AuthUser;
    const stats = db.prepare("SELECT * FROM user_stats WHERE user_id = ?").all(user.id) as Array<Record<string, unknown>>;
    const totals = db
      .prepare("SELECT COUNT(*) AS games, COALESCE(SUM(score), 0) AS total_score FROM scores WHERE user_id = ?")
      .get(user.id) as { games: number; total_score: number };
    const recent = db
      .prepare("SELECT * FROM scores WHERE user_id = ? ORDER BY created_at DESC LIMIT 10")
      .all(user.id) as Array<Record<string, unknown>>;
    const best: Record<
      string,
      {
        gamesPlayed: number;
        bestScore: number | null;
        bestMoves: number | null;
        bestTimeMs: number | null;
        totalScore: number;
      }
    > = {};
    for (const row of stats) {
      best[row.game as string] = {
        gamesPlayed: row.games_played as number,
        bestScore: row.best_score as number | null,
        bestMoves: row.best_moves as number | null,
        bestTimeMs: row.best_time_ms as number | null,
        totalScore: row.total_score as number,
      };
    }
    res.json({
      user: privateUser(user),
      totals: { games: totals.games, totalScore: totals.total_score },
      best,
      recent: recent.map(mapScore),
    });
  });

  app.get("/api/v1/history", requireAuth(db), (req, res) => {
    const limit = Math.min(50, Math.max(1, Number(req.query.limit ?? 20) || 20));
    const rows = db
      .prepare("SELECT * FROM scores WHERE user_id = ? ORDER BY created_at DESC LIMIT ?")
      .all((req.user as AuthUser).id, limit) as Array<Record<string, unknown>>;
    res.json({ history: rows.map(mapScore) });
  });

  const webDist = path.resolve(process.cwd(), "client/dist");
  if (fs.existsSync(webDist)) {
    app.use(express.static(webDist));
    app.use((req, res, next) => {
      if (req.method === "GET" && !req.path.startsWith("/api/")) {
        res.sendFile(path.join(webDist, "index.html"));
        return;
      }
      next();
    });
  }

  app.use((req, res) => {
    res.status(404).json({ error: { code: "NOT_FOUND", message: `No route for ${req.method} ${req.path}.` } });
  });

  app.use((error: unknown, _req: Request, res: Response, _next: NextFunction) => {
    if (error instanceof HttpError) {
      res.status(error.status).json({ error: { code: error.code, message: error.message, details: error.details } });
      return;
    }
    if (error instanceof SyntaxError && "body" in error) {
      res.status(400).json({ error: { code: "INVALID_JSON", message: "Request body is not valid JSON." } });
      return;
    }
    console.error(error);
    res.status(500).json({ error: { code: "INTERNAL_ERROR", message: "Something went wrong. Please try again." } });
  });

  return app;
}
