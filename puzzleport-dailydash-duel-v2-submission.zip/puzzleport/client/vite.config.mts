import { fileURLToPath } from "node:url";
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "node:path";

const clientRoot = fileURLToPath(new URL(".", import.meta.url));
const projectRoot = path.resolve(clientRoot, "..");

export default defineConfig({
  root: clientRoot,
  plugins: [react()],
  server: {
    port: 5173,
    strictPort: true,
    fs: { allow: [projectRoot] },
    proxy: {
      "/api": { target: "http://localhost:4000", changeOrigin: true },
    },
  },
  build: {
    outDir: path.resolve(clientRoot, "dist"),
    emptyOutDir: true,
  },
});
