import type { ReactNode } from "react";
import { Link } from "react-router-dom";
import { Sparkles } from "lucide-react";
import { Mascot } from "./ui";

export default function AuthShell({
  eyebrow,
  title,
  subtitle,
  children,
  footer,
}: {
  eyebrow: string;
  title: string;
  subtitle: string;
  children: ReactNode;
  footer: ReactNode;
}) {
  return (
    <div className="auth-shell">
      <section className="auth-promo glass-strong" aria-label="Welcome to PuzzlePort">
        <Link to="/" className="brand auth-brand">
          <span className="brand-mark" aria-hidden="true">
            🧩
          </span>
          <span className="brand-text">
            <strong>PuzzlePort</strong>
            <small>DailyDash Duel</small>
          </span>
        </Link>
        <div>
          <p className="eyebrow">
            <Sparkles size={14} aria-hidden="true" />
            A little daily ritual
          </p>
          <h2>
            Cozy puzzles.
            <br />
            Real competition.
          </h2>
          <p>
            Play today&apos;s shared Memory Match and 2048 puzzles, then watch your name climb a
            leaderboard built from real, saved runs.
          </p>
        </div>
        <div className="auth-art" aria-hidden="true">
          <span className="auth-card auth-card-a">🍓</span>
          <span className="auth-card auth-card-b">2</span>
          <span className="auth-card auth-card-c">4</span>
          <span className="auth-card auth-card-d">🌷</span>
          <Mascot size={102} className="auth-pip" />
        </div>
        <ul className="auth-points">
          <li>Free account, no email verification in this build</li>
          <li>Persistent SQLite scores and history</li>
          <li>New daily seed at midnight IST</li>
        </ul>
      </section>

      <section className="auth-form-panel glass">
        <div className="auth-form-head">
          <p className="eyebrow">{eyebrow}</p>
          <h1>{title}</h1>
          <p>{subtitle}</p>
        </div>
        {children}
        <div className="auth-footer">{footer}</div>
      </section>
    </div>
  );
}
