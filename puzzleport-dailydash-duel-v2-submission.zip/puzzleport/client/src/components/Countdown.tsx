import { useEffect, useRef, useState } from "react";
import { Timer } from "lucide-react";
import { formatCountdown } from "../lib/format";

export function Countdown({
  endsAt,
  onExpire,
  className = "",
}: {
  endsAt: string;
  onExpire?: () => void;
  className?: string;
}) {
  const [remaining, setRemaining] = useState(() => Math.max(0, Date.parse(endsAt) - Date.now()));
  const expiredRef = useRef(false);
  const onExpireRef = useRef(onExpire);
  onExpireRef.current = onExpire;

  useEffect(() => {
    expiredRef.current = false;
    const tick = () => {
      const next = Math.max(0, Date.parse(endsAt) - Date.now());
      setRemaining(next);
      if (next === 0 && !expiredRef.current) {
        expiredRef.current = true;
        onExpireRef.current?.();
      }
    };
    tick();
    const interval = window.setInterval(tick, 1000);
    return () => window.clearInterval(interval);
  }, [endsAt]);

  return (
    <span className={`countdown ${className}`.trim()}>
      <Timer size={15} aria-hidden="true" />
      <span>{remaining === 0 ? "New challenge soon" : formatCountdown(remaining)}</span>
      <span className="countdown-zone">IST</span>
    </span>
  );
}
