import { useEffect } from "react";
import { Link, NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import {
  Award,
  Coins,
  Compass,
  Flame,
  Gamepad2,
  Home,
  LogIn,
  LogOut,
  Palette,
  Settings,
  Trophy,
  UserRound,
  Volume2,
  VolumeX,
} from "lucide-react";
import { useAuth } from "../lib/auth";
import { usePreferences } from "../lib/preferences";
import { useToast } from "../components/Toast";
import { Avatar, Spinner } from "./ui";
import { playSound, unlockAudio } from "../lib/audio";

const primaryNav = [
  { to: "/", label: "Home", icon: Home, end: true },
  { to: "/play", label: "Play", icon: Gamepad2 },
  { to: "/campaign", label: "Campaign", icon: Compass },
  { to: "/achievements", label: "Quests", icon: Award },
  { to: "/collection", label: "Collection", icon: Palette },
  { to: "/leaderboards", label: "Ranks", icon: Trophy },
];

function navClass({ isActive }: { isActive: boolean }): string {
  return `nav-link${isActive ? " is-active" : ""}`;
}

export default function Layout() {
  const { user, loading, signOut } = useAuth();
  const { preferences, setPreferences } = usePreferences();
  const toast = useToast();
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "auto" });
  }, [location.pathname]);

  useEffect(() => {
    document.body.classList.toggle("high-contrast", preferences.highContrast);
    document.body.classList.toggle("colorblind", preferences.colorblindPatterns);
    document.body.classList.toggle("reduced-motion", preferences.reducedMotion);
  }, [preferences]);

  useEffect(() => {
    const unlock = () => unlockAudio();
    window.addEventListener("pointerdown", unlock, { once: true });
    window.addEventListener("keydown", unlock, { once: true });
    return () => {
      window.removeEventListener("pointerdown", unlock);
      window.removeEventListener("keydown", unlock);
    };
  }, []);

  const handleSignOut = async () => {
    await signOut();
    navigate("/");
  };

  const toggleSound = async () => {
    unlockAudio();
    await setPreferences({ soundEnabled: !preferences.soundEnabled });
    playSound("click", { soundEnabled: !preferences.soundEnabled, sfxEnabled: preferences.sfxEnabled, volume: preferences.masterVolume });
  };

  return (
    <div className="app-shell">
      <a className="skip-link" href="#main-content">
        Skip to content
      </a>
      <div className="aurora" aria-hidden="true">
        <span className="blob blob-one" />
        <span className="blob blob-two" />
        <span className="blob blob-three" />
        <span className="sky-shape sky-shape-one">✦</span>
        <span className="sky-shape sky-shape-two">♡</span>
        <span className="sky-shape sky-shape-three">✿</span>
        <span className="sky-shape sky-shape-four">✦</span>
      </div>

      <header className="site-header">
        <div className="container header-inner">
          <Link to="/" className="brand" aria-label="PuzzlePort home">
            <span className="brand-mark" aria-hidden="true">
              🧩
            </span>
            <span className="brand-text">
              <strong>PuzzlePort</strong>
              <small>DailyDash Duel</small>
            </span>
          </Link>

          <nav className="desktop-nav" aria-label="Primary navigation">
            {primaryNav.map((item) => {
              const Icon = item.icon;
              return (
                <NavLink key={item.to} to={item.to} end={item.end} className={navClass}>
                  <Icon size={16} aria-hidden="true" />
                  <span>{item.label}</span>
                </NavLink>
              );
            })}
          </nav>

          <div className="header-actions">
            {user && (
              <>
                <div className="coin-pill" title="Coins">
                  <Coins size={15} aria-hidden="true" />
                  <strong>{user.coins ?? 0}</strong>
                </div>
                <div className="streak-pill" title="Daily streak">
                  <Flame size={15} aria-hidden="true" />
                  <strong>{user.streak?.current ?? 0}</strong>
                </div>
                <button type="button" className="icon-btn sound-toggle" onClick={toggleSound} aria-label={preferences.soundEnabled ? "Mute sound" : "Unmute sound"}>
                  {preferences.soundEnabled ? <Volume2 size={17} /> : <VolumeX size={17} />}
                </button>
              </>
            )}
            {loading ? (
              <Spinner label="Checking your session" />
            ) : user ? (
              <>
                <Link to="/profile" className="user-chip" aria-label={`Open ${user.displayName}'s profile`}>
                  <Avatar avatar={user.avatar} size="sm" />
                  <span className="user-chip-text">
                    <strong>{user.displayName}</strong>
                    <small>Level {user.level}</small>
                  </span>
                </Link>
                <Link to="/settings" className="icon-btn" aria-label="Settings">
                  <Settings size={17} aria-hidden="true" />
                </Link>
                <button type="button" className="icon-btn" onClick={handleSignOut} aria-label="Sign out" title="Sign out">
                  <LogOut size={17} aria-hidden="true" />
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="btn btn-ghost btn-small">
                  <LogIn size={16} aria-hidden="true" />
                  Sign in
                </Link>
                <Link to="/signup" className="btn btn-primary btn-small">
                  Join free
                </Link>
              </>
            )}
          </div>
        </div>
      </header>

      <main id="main-content" className="site-main">
        <div className="container">
          <Outlet />
        </div>
      </main>

      <footer className="site-footer">
        <div className="container footer-inner">
          <div>
            <p className="footer-brand">🧩 PuzzlePort · DailyDash Duel</p>
            <p className="footer-note">
              A cozy daily puzzle parlour for tiny breaks, real records, and happy little wins.
            </p>
          </div>
          <nav className="footer-links" aria-label="Footer navigation">
            <Link to="/rules">Rules & fair play</Link>
            <Link to="/achievements">Quests</Link>
            <Link to="/leaderboards">Leaderboards</Link>
            <Link to="/play">Games</Link>
            <Link to="/duel">Local duel</Link>
          </nav>
        </div>
      </footer>

      <nav className="mobile-nav" aria-label="Mobile navigation">
        {[primaryNav[0], primaryNav[1], primaryNav[2], primaryNav[4]].map((item) => {
          const Icon = item.icon;
          return (
            <NavLink key={item.to} to={item.to} end={item.end} className={navClass}>
              <Icon size={19} aria-hidden="true" />
              <span>{item.label}</span>
            </NavLink>
          );
        })}
        <NavLink to={user ? "/profile" : "/login"} className={navClass}>
          <UserRound size={19} aria-hidden="true" />
          <span>{user ? "Profile" : "Sign in"}</span>
        </NavLink>
      </nav>
    </div>
  );
}
