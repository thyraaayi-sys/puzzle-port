import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { CheckCircle2, CircleAlert, Info, Sparkles, X } from "lucide-react";

type ToastKind = "success" | "error" | "reward" | "info";

type ToastItem = {
  id: number;
  kind: ToastKind;
  title: string;
  message?: string;
};

type ToastContextValue = {
  toast: (item: Omit<ToastItem, "id">) => void;
  success: (title: string, message?: string) => void;
  error: (title: string, message?: string) => void;
  reward: (title: string, message?: string) => void;
};

const ToastContext = createContext<ToastContextValue | null>(null);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);

  const remove = useCallback((id: number) => {
    setItems((current) => current.filter((item) => item.id !== id));
  }, []);

  const toast = useCallback((item: Omit<ToastItem, "id">) => {
    const id = Date.now() + Math.floor(Math.random() * 1000);
    setItems((current) => [...current, { ...item, id }]);
    window.setTimeout(() => remove(id), item.kind === "error" ? 5000 : 3200);
  }, [remove]);

  const value = useMemo<ToastContextValue>(
    () => ({
      toast,
      success: (title, message) => toast({ kind: "success", title, message }),
      error: (title, message) => toast({ kind: "error", title, message }),
      reward: (title, message) => toast({ kind: "reward", title, message }),
    }),
    [toast],
  );

  return (
    <ToastContext.Provider value={value}>
      {children}
      <div className="toast-stack" aria-live="polite" aria-atomic="false">
        {items.map((item) => (
          <div key={item.id} className={`toast toast-${item.kind}`}>
            <span className="toast-icon" aria-hidden="true">
              {item.kind === "success" ? <CheckCircle2 size={18} /> : item.kind === "reward" ? <Sparkles size={18} /> : item.kind === "error" ? <CircleAlert size={18} /> : <Info size={18} />}
            </span>
            <div className="toast-copy">
              <strong>{item.title}</strong>
              {item.message && <p>{item.message}</p>}
            </div>
            <button type="button" className="toast-close" onClick={() => remove(item.id)} aria-label="Dismiss notification">
              <X size={14} />
            </button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast(): ToastContextValue {
  const context = useContext(ToastContext);
  if (!context) throw new Error("useToast must be used inside ToastProvider");
  return context;
}
