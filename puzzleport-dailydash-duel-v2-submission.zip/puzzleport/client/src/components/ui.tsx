import { useEffect, useId, useRef, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { X } from "lucide-react";
import { levelInfo } from "../lib/format";

export function Avatar({
  avatar,
  level,
  size = "md",
  className = "",
}: {
  avatar: string;
  level?: number;
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
}) {
  return (
    <span className={`avatar avatar-${size} ${className}`.trim()}>
      <span className="avatar-emoji" aria-hidden="true">
        {avatar}
      </span>
      {level !== undefined && <span className="avatar-level">Lv {level}</span>}
    </span>
  );
}

export function XPBar({ xp, showLabel = false }: { xp: number; showLabel?: boolean }) {
  const info = levelInfo(xp);
  return (
    <div className="xp-wrap">
      <div className="xp-labels">
        <span>Level {info.level}</span>
        <span>{showLabel ? `${info.remaining} XP to level ${info.level + 1}` : `${Math.round(info.progress)}%`}</span>
      </div>
      <div
        className="xp-track"
        role="progressbar"
        aria-label={`Level ${info.level} progress`}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={Math.round(info.progress)}
      >
        <div className="xp-fill" style={{ width: `${info.progress}%` }} />
      </div>
    </div>
  );
}

export function Spinner({ label = "Loading" }: { label?: string }) {
  return (
    <span className="spinner-wrap" role="status">
      <span className="spinner" aria-hidden="true" />
      <span className="sr-only">{label}</span>
    </span>
  );
}

export function Mascot({ size = 96, className = "" }: { size?: number; className?: string }) {
  const uid = useId().replace(/:/g, "");
  return (
    <svg
      className={`mascot ${className}`.trim()}
      width={size}
      height={size}
      viewBox="0 0 120 120"
      fill="none"
      aria-hidden="true"
      focusable="false"
    >
      <defs>
        <linearGradient id={`pip-body-${uid}`} x1="20" y1="11" x2="101" y2="111" gradientUnits="userSpaceOnUse">
          <stop stopColor="#ffd4e4" />
          <stop offset="0.52" stopColor="#fff0cd" />
          <stop offset="1" stopColor="#d6ecff" />
        </linearGradient>
        <linearGradient id={`pip-shine-${uid}`} x1="38" y1="28" x2="69" y2="77" gradientUnits="userSpaceOnUse">
          <stop stopColor="#ffffff" stopOpacity="0.92" />
          <stop offset="1" stopColor="#ffffff" stopOpacity="0" />
        </linearGradient>
      </defs>
      <ellipse cx="60" cy="110" rx="31" ry="6" fill="#a04a6d" opacity="0.12" />
      <path
        d="M60 7c9.4 0 17 7.2 17 16.1V32h16.5C103.3 32 111 39.9 111 49.7v42.6c0 9.8-7.7 17.7-17.5 17.7h-67C16.7 110 9 102.1 9 92.3V49.7C9 39.9 16.7 32 26.5 32H43v-8.9C43 14.2 50.6 7 60 7Z"
        fill={`url(#pip-body-${uid})`}
        stroke="#ffffff"
        strokeWidth="3.5"
      />
      <path
        d="M31 54c4-13 15-20 29-21"
        stroke={`url(#pip-shine-${uid})`}
        strokeWidth="7"
        strokeLinecap="round"
      />
      <ellipse cx="45" cy="67" rx="4.7" ry="5.2" fill="#3b3145" />
      <ellipse cx="75" cy="67" rx="4.7" ry="5.2" fill="#3b3145" />
      <circle cx="46.6" cy="65.2" r="1.6" fill="#ffffff" />
      <circle cx="76.6" cy="65.2" r="1.6" fill="#ffffff" />
      <ellipse cx="33" cy="78" rx="7" ry="4.5" fill="#f25c8b" opacity="0.25" />
      <ellipse cx="87" cy="78" rx="7" ry="4.5" fill="#f25c8b" opacity="0.25" />
      <path d="M49 78c5.2 7 16.8 7 22 0" stroke="#3b3145" strokeWidth="3.4" strokeLinecap="round" />
      <path d="M100 22v9M95.5 26.5h9" stroke="#d94372" strokeWidth="2.4" strokeLinecap="round" opacity="0.5" />
      <path d="M21 24v7M17.5 27.5h7" stroke="#326f9f" strokeWidth="2.2" strokeLinecap="round" opacity="0.38" />
    </svg>
  );
}

export function LoadingBlock({ label = "Loading your puzzle parlour…" }: { label?: string }) {
  return (
    <div className="loading-block glass">
      <Spinner label={label} />
      <p>{label}</p>
    </div>
  );
}

export function ErrorNotice({
  message,
  onRetry,
}: {
  message: string;
  onRetry?: () => void;
}) {
  return (
    <div className="error-notice" role="alert">
      <span aria-hidden="true">🌧️</span>
      <div>
        <strong>Something went sideways.</strong>
        <p>{message}</p>
      </div>
      {onRetry && (
        <button type="button" className="btn btn-ghost btn-small" onClick={onRetry}>
          Try again
        </button>
      )}
    </div>
  );
}

export function PageHeader({
  eyebrow,
  title,
  subtitle,
  actions,
}: {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  actions?: ReactNode;
}) {
  return (
    <header className="page-header">
      <div>
        {eyebrow && <p className="eyebrow">{eyebrow}</p>}
        <h1>{title}</h1>
        {subtitle && <p className="page-subtitle">{subtitle}</p>}
      </div>
      {actions && <div className="page-actions">{actions}</div>}
    </header>
  );
}

export function EmptyState({
  emoji = "🌱",
  title,
  description,
  action,
}: {
  emoji?: string;
  title: string;
  description: string;
  action?: ReactNode;
}) {
  return (
    <div className="empty-state">
      <span className="empty-emoji" aria-hidden="true">
        {emoji}
      </span>
      <h3>{title}</h3>
      <p>{description}</p>
      {action}
    </div>
  );
}

export function Modal({
  open,
  title,
  onClose,
  children,
  footer,
  size = "md",
}: {
  open: boolean;
  title: string;
  onClose: () => void;
  children: ReactNode;
  footer?: ReactNode;
  size?: "sm" | "md" | "lg";
}) {
  const titleId = useId();
  const panelRef = useRef<HTMLDivElement>(null);
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;

  useEffect(() => {
    if (!open) return;
    const previousFocus = document.activeElement as HTMLElement | null;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    const handleKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        onCloseRef.current();
        return;
      }
      if (event.key !== "Tab" || !panelRef.current) return;
      const focusable = Array.from(
        panelRef.current.querySelectorAll<HTMLElement>(
          'button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])',
        ),
      ).filter((element) => element.offsetParent !== null);
      if (focusable.length === 0) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };

    document.addEventListener("keydown", handleKey);
    const frame = window.requestAnimationFrame(() => {
      const focusTarget = panelRef.current?.querySelector<HTMLElement>("[data-autofocus]") ?? panelRef.current;
      focusTarget?.focus();
    });

    return () => {
      document.removeEventListener("keydown", handleKey);
      window.cancelAnimationFrame(frame);
      document.body.style.overflow = previousOverflow;
      previousFocus?.focus();
    };
  }, [open]);

  if (!open) return null;

  return createPortal(
    <div
      className="modal-backdrop"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <div
        className={`modal-panel modal-${size}`}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        ref={panelRef}
        tabIndex={-1}
      >
        <div className="modal-head">
          <h2 id={titleId}>{title}</h2>
          <button type="button" className="icon-btn" onClick={onClose} aria-label="Close dialog" data-autofocus>
            <X size={18} aria-hidden="true" />
          </button>
        </div>
        <div className="modal-body">{children}</div>
        {footer && <div className="modal-footer">{footer}</div>}
      </div>
    </div>,
    document.body,
  );
}

export function StatTile({
  label,
  value,
  hint,
  emoji,
}: {
  label: string;
  value: ReactNode;
  hint?: string;
  emoji?: string;
}) {
  return (
    <div className="stat-tile glass">
      {emoji && (
        <span className="stat-emoji" aria-hidden="true">
          {emoji}
        </span>
      )}
      <span className="stat-label">{label}</span>
      <strong className="stat-value">{value}</strong>
      {hint && <span className="stat-hint">{hint}</span>}
    </div>
  );
}
