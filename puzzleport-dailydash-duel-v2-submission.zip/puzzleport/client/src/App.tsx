import { Navigate, Route, Routes, useLocation } from "react-router-dom";
import type { ReactNode } from "react";
import Layout from "./components/Layout";
import { Spinner } from "./components/ui";
import { useAuth } from "./lib/auth";
import HomePage from "./pages/HomePage";
import LoginPage from "./pages/LoginPage";
import SignupPage from "./pages/SignupPage";
import PlayPage from "./pages/PlayPage";
import MemoryPage from "./pages/MemoryPage";
import Game2048Page from "./pages/Game2048Page";
import LeaderboardsPage from "./pages/LeaderboardsPage";
import ProfilePage from "./pages/ProfilePage";
import RulesPage from "./pages/RulesPage";
import NotFoundPage from "./pages/NotFoundPage";
import CollectionPage from "./pages/CollectionPage";
import AchievementsPage from "./pages/AchievementsPage";
import CampaignPage from "./pages/CampaignPage";
import ReplayPage from "./pages/ReplayPage";
import DuelPage from "./pages/DuelPage";
import DuelMemoryPage from "./pages/DuelMemoryPage";
import Duel2048Page from "./pages/Duel2048Page";
import SettingsPage from "./pages/SettingsPage";

function RequireAuth({ children }: { children: ReactNode }) {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="route-loading">
        <Spinner label="Checking your session" />
      </div>
    );
  }
  if (!user) {
    const next = `${location.pathname}${location.search}`;
    return <Navigate to={`/login?next=${encodeURIComponent(next)}`} replace />;
  }
  return <>{children}</>;
}

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<HomePage />} />
        <Route path="login" element={<LoginPage />} />
        <Route path="signup" element={<SignupPage />} />
        <Route path="play" element={<PlayPage />} />
        <Route
          path="play/memory"
          element={
            <RequireAuth>
              <MemoryPage />
            </RequireAuth>
          }
        />
        <Route
          path="play/2048"
          element={
            <RequireAuth>
              <Game2048Page />
            </RequireAuth>
          }
        />
        <Route
          path="campaign"
          element={
            <RequireAuth>
              <CampaignPage />
            </RequireAuth>
          }
        />
        <Route
          path="collection"
          element={
            <RequireAuth>
              <CollectionPage />
            </RequireAuth>
          }
        />
        <Route
          path="achievements"
          element={
            <RequireAuth>
              <AchievementsPage />
            </RequireAuth>
          }
        />
        <Route path="leaderboards" element={<LeaderboardsPage />} />
        <Route path="replay/:scoreId" element={<ReplayPage />} />
        <Route path="duel" element={<DuelPage />} />
        <Route path="duel/memory" element={<DuelMemoryPage />} />
        <Route path="duel/2048" element={<Duel2048Page />} />
        <Route path="rules" element={<RulesPage />} />
        <Route
          path="profile"
          element={
            <RequireAuth>
              <ProfilePage />
            </RequireAuth>
          }
        />
        <Route
          path="settings"
          element={
            <RequireAuth>
              <SettingsPage />
            </RequireAuth>
          }
        />
        <Route path="*" element={<NotFoundPage />} />
      </Route>
    </Routes>
  );
}
