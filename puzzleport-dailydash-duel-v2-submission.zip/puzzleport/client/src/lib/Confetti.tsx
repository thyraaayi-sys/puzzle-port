import { useEffect, useMemo, useState } from "react";

export function Confetti({ active, onDone }: { active: boolean; onDone?: () => void }) {
  const [visible, setVisible] = useState(active);
  const particles = useMemo(
    () =>
      Array.from({ length: 90 }, (_, index) => ({
        id: index,
        left: Math.random() * 100,
        delay: Math.random() * 0.35,
        duration: 1.4 + Math.random() * 1.1,
        size: 6 + Math.random() * 8,
        hue: Math.floor(Math.random() * 360),
        drift: -80 + Math.random() * 160,
        rotation: Math.random() * 360,
      })),
    [active],
  );

  useEffect(() => {
    if (!active) return;
    setVisible(true);
    const timer = window.setTimeout(() => {
      setVisible(false);
      onDone?.();
    }, 2600);
    return () => window.clearTimeout(timer);
  }, [active, onDone]);

  if (!visible) return null;

  return (
    <div className="confetti-layer" aria-hidden="true">
      {particles.map((particle) => (
        <span
          key={particle.id}
          className="confetti-piece"
          style={{
            left: `${particle.left}%`,
            animationDelay: `${particle.delay}s`,
            animationDuration: `${particle.duration}s`,
            width: `${particle.size}px`,
            height: `${particle.size * 0.6}px`,
            background: `hsl(${particle.hue} 85% 62%)`,
            ["--drift" as string]: `${particle.drift}px`,
            ["--rotation" as string]: `${particle.rotation}deg`,
          }}
        />
      ))}
    </div>
  );
}
