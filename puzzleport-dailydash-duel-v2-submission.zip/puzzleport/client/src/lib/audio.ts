type SoundName =
  | "flip"
  | "match"
  | "mismatch"
  | "move"
  | "merge"
  | "mergeBig"
  | "victory"
  | "gameOver"
  | "achievement"
  | "levelUp"
  | "reward"
  | "click";

let audioContext: AudioContext | null = null;
let unlocked = false;

function getContext(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!audioContext) {
    const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return null;
    audioContext = new Ctor();
  }
  return audioContext;
}

export function unlockAudio(): void {
  const context = getContext();
  if (!context || unlocked) return;
  if (context.state === "suspended") void context.resume();
  unlocked = true;
}

export function isAudioUnlocked(): boolean {
  return unlocked;
}

function tone(frequency: number, duration: number, type: OscillatorType = "sine", gain = 0.08, delay = 0) {
  const context = getContext();
  if (!context || context.state !== "running") return;
  const now = context.currentTime + delay;
  const oscillator = context.createOscillator();
  const envelope = context.createGain();
  oscillator.type = type;
  oscillator.frequency.setValueAtTime(frequency, now);
  envelope.gain.setValueAtTime(0.0001, now);
  envelope.gain.exponentialRampToValueAtTime(gain, now + 0.01);
  envelope.gain.exponentialRampToValueAtTime(0.0001, now + duration);
  oscillator.connect(envelope);
  envelope.connect(context.destination);
  oscillator.start(now);
  oscillator.stop(now + duration + 0.02);
}

export function playSound(name: SoundName, settings: { soundEnabled: boolean; sfxEnabled: boolean; volume: number }): void {
  if (!settings.soundEnabled || !settings.sfxEnabled) return;
  const volume = Math.max(0, Math.min(1, settings.volume));
  const gain = 0.09 * volume;
  switch (name) {
    case "flip":
      tone(520, 0.08, "triangle", gain);
      break;
    case "match":
      tone(660, 0.1, "sine", gain);
      tone(880, 0.12, "sine", gain * 0.8, 0.08);
      break;
    case "mismatch":
      tone(220, 0.12, "sawtooth", gain * 0.7);
      tone(180, 0.14, "sawtooth", gain * 0.6, 0.08);
      break;
    case "move":
      tone(320, 0.05, "square", gain * 0.5);
      break;
    case "merge":
      tone(440, 0.08, "triangle", gain);
      tone(660, 0.08, "triangle", gain * 0.7, 0.04);
      break;
    case "mergeBig":
      tone(523, 0.1, "sawtooth", gain);
      tone(784, 0.12, "sawtooth", gain * 0.8, 0.05);
      tone(1046, 0.14, "sawtooth", gain * 0.6, 0.1);
      break;
    case "victory":
      [523, 659, 784, 1046].forEach((freq, index) => tone(freq, 0.16, "triangle", gain, index * 0.1));
      break;
    case "gameOver":
      [392, 330, 262].forEach((freq, index) => tone(freq, 0.18, "sawtooth", gain * 0.7, index * 0.12));
      break;
    case "achievement":
      [784, 988, 1175].forEach((freq, index) => tone(freq, 0.12, "sine", gain, index * 0.08));
      break;
    case "levelUp":
      [659, 784, 988, 1318].forEach((freq, index) => tone(freq, 0.14, "triangle", gain, index * 0.09));
      break;
    case "reward":
      tone(880, 0.08, "sine", gain);
      tone(1175, 0.1, "sine", gain * 0.8, 0.07);
      break;
    case "click":
      tone(480, 0.04, "square", gain * 0.4);
      break;
  }
}
