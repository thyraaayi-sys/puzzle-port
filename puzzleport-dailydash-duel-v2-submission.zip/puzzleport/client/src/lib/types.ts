export type GameKey = "memory" | "2048";
export type PlayMode = "daily" | "classic";
export type PlayVariant =
  | "daily"
  | "classic"
  | "practice"
  | "timed"
  | "moves"
  | "perfect"
  | "campaign"
  | "endless"
  | "target";

export interface User {
  id: number;
  username: string;
  displayName: string;
  avatar: string;
  xp: number;
  level: number;
  coins?: number;
  streak?: { current: number; best: number };
  createdAt: string;
  email?: string;
}

export interface DailyBest {
  score: number;
  moves: number;
  durationMs: number;
  challengeDate: string | null;
}

export interface DailyGame {
  game: GameKey;
  seed: string;
  config: Record<string, unknown>;
  dateKey: string;
  completed: boolean;
  best: DailyBest | null;
}

export interface DailyResponse {
  dateKey: string;
  timezone: string;
  startsAt: string;
  endsAt: string;
  games: DailyGame[];
}

export interface Session {
  id: string;
  game: GameKey;
  mode: PlayMode;
  variant?: string;
  levelId?: string | null;
  seed: string;
  config: Record<string, unknown>;
  challengeDate: string | null;
  startedAt: string;
}

export interface SessionResponse {
  session: Session;
}

export interface ScoreRecord {
  id: number;
  game: GameKey;
  mode: PlayMode;
  variant?: string;
  score: number;
  moves: number;
  durationMs: number;
  challengeDate: string | null;
  createdAt: string;
  stars?: number;
  hasReplay?: boolean;
}

export interface SaveScoreResponse {
  score: ScoreRecord;
  xpGain: number;
  coinGain?: number;
  user: { xp: number; level: number; coins?: number };
  alreadySaved: boolean;
  achievements?: string[];
  questsCompleted?: string[];
  stars?: number;
  campaign?: {
    levelId: string | null;
    completed: boolean;
    bestStars: number;
    unlockedNext: string | null;
  } | null;
  replayId?: number | null;
}

export interface LeaderboardEntry {
  rank: number;
  scoreId?: number;
  username: string;
  displayName: string;
  avatar: string;
  level: number;
  game: GameKey;
  variant?: string;
  levelId?: string | null;
  score: number;
  moves: number;
  durationMs: number;
  completedAt: string;
  hasReplay?: boolean;
  movement?: number | null;
}

export interface LeaderboardResponse {
  game: GameKey;
  period: "daily" | "weekly" | "all";
  variant?: string | null;
  levelId?: string | null;
  dateKey: string | null;
  weekKey?: string | null;
  timezone: string;
  entries: LeaderboardEntry[];
  me: LeaderboardEntry | null;
}

export interface GameBest {
  gamesPlayed: number;
  bestScore: number | null;
  bestMoves: number | null;
  bestTimeMs: number | null;
  totalScore: number;
}

export interface StatsResponse {
  user: User;
  totals: { games: number; totalScore: number };
  best: Partial<Record<GameKey, GameBest>>;
  recent: ScoreRecord[];
}

export interface HistoryResponse {
  history: ScoreRecord[];
}

export interface ProgressionResponse {
  user: {
    id: number;
    username: string;
    displayName: string;
    avatar: string;
    xp: number;
    level: number;
    coins: number;
    createdAt: string;
    email?: string;
    equipped: {
      theme: string;
      cardBack: string;
      border: string;
      flip: string;
      matchEffect: string;
      victoryEffect: string;
    };
    streak: {
      current: number;
      best: number;
      lastDate: string | null;
      weekly: number;
      weeklyBest: number;
      lastWeek: string | null;
    };
  };
  preferences: {
    highContrast: boolean;
    colorblindPatterns: boolean;
    reducedMotion: boolean;
    soundEnabled: boolean;
    sfxEnabled: boolean;
    masterVolume: number;
  };
  inventory: Record<string, string[]>;
  achievements: Array<{
    slug: string;
    title: string;
    description: string;
    emoji: string;
    xpReward: number;
    coinReward: number;
    unlocked: boolean;
    unlockedAt: string | null;
    seen: boolean;
  }>;
  quests: {
    daily: Array<{
      slug: string;
      scope: string;
      title: string;
      description: string;
      emoji: string;
      metric: string;
      target: number;
      progress: number;
      completed: boolean;
      claimed: boolean;
      xpReward: number;
      coinReward: number;
    }>;
    weekly: Array<{
      slug: string;
      scope: string;
      title: string;
      description: string;
      emoji: string;
      metric: string;
      target: number;
      progress: number;
      completed: boolean;
      claimed: boolean;
      xpReward: number;
      coinReward: number;
    }>;
    dailyPeriodKey: string;
    weeklyPeriodKey: string;
  };
  campaign: {
    memory: Array<CampaignLevelProgress>;
    "2048": Array<CampaignLevelProgress>;
  };
  seasonalEvents: Array<{
    id: string;
    name: string;
    description: string;
    emoji: string;
    startsOn: string;
    endsOn: string;
    themeId: string;
    banner: string;
    sortOrder: number;
    active: boolean;
  }>;
}

export interface CampaignLevelProgress {
  id: string;
  game: GameKey;
  levelNumber: number;
  world: number;
  worldName: string;
  name: string;
  config: Record<string, unknown>;
  stars: { threeMoves: number; twoMoves: number; threeTimeMs: number; twoTimeMs: number };
  xpReward: number;
  coinReward: number;
  unlockLevelId: string | null;
  unlocked: boolean;
  progress: {
    bestStars: number;
    bestScore: number | null;
    bestMoves: number | null;
    bestTimeMs: number | null;
    completedAt: string | null;
  } | null;
}

export interface CatalogResponse {
  themes: Array<{
    id: string;
    name: string;
    description: string;
    emoji: string;
    palette: string[];
    symbols: string[];
    unlockType: string;
    cost: number;
    achievementSlug: string | null;
    eventId: string | null;
    sortOrder: number;
    active: boolean;
  }>;
  cosmetics: Array<{
    id: string;
    type: string;
    name: string;
    description: string;
    style: string;
    unlockType: string;
    cost: number;
    achievementSlug: string | null;
    eventId: string | null;
    sortOrder: number;
    active: boolean;
  }>;
  achievements: Array<{
    slug: string;
    title: string;
    description: string;
    emoji: string;
    xpReward: number;
    coinReward: number;
    criteriaKind: string;
    criteriaValue: number;
    secret: boolean;
    sortOrder: number;
  }>;
  quests: Array<{
    slug: string;
    scope: string;
    title: string;
    description: string;
    metric: string;
    target: number;
    xpReward: number;
    coinReward: number;
    emoji: string;
    sortOrder: number;
  }>;
  campaignLevels: Array<{
    id: string;
    game: GameKey;
    levelNumber: number;
    world: number;
    worldName: string;
    name: string;
    config: Record<string, unknown>;
    stars: { threeMoves: number; twoMoves: number; threeTimeMs: number; twoTimeMs: number };
    xpReward: number;
    coinReward: number;
    unlockLevelId: string | null;
    sortOrder: number;
  }>;
  seasonalEvents: Array<{
    id: string;
    name: string;
    description: string;
    emoji: string;
    startsOn: string;
    endsOn: string;
    themeId: string;
    banner: string;
    sortOrder: number;
    active: boolean;
  }>;
}

export interface ReplayResponse {
  replay: {
    scoreId: number;
    game: GameKey;
    mode: string;
    variant: string;
    levelId: string | null;
    score: number;
    moves: number;
    durationMs: number;
    completedAt: string;
    displayName: string;
    avatar: string;
    level: number;
    seed: string;
    sessionSeed: string;
    config: Record<string, unknown>;
    actions: Array<string | number>;
    actionTimes: number[] | null;
    verified: boolean;
  };
}
