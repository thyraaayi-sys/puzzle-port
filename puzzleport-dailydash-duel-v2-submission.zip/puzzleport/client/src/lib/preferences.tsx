import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { api } from "./api";
import type { ProgressionResponse } from "./types";

type Preferences = ProgressionResponse["preferences"];

const defaultPreferences: Preferences = {
  highContrast: false,
  colorblindPatterns: false,
  reducedMotion: false,
  soundEnabled: true,
  sfxEnabled: true,
  masterVolume: 0.7,
};

type PreferencesContextValue = {
  preferences: Preferences;
  setPreferences: (patch: Partial<Preferences>) => Promise<void>;
  loading: boolean;
};

const PreferencesContext = createContext<PreferencesContextValue | null>(null);

export function PreferencesProvider({ children, token }: { children: ReactNode; token: string | null }) {
  const [preferences, setPreferencesState] = useState<Preferences>(defaultPreferences);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let active = true;
    if (!token) {
      setPreferencesState(defaultPreferences);
      return;
    }
    setLoading(true);
    api<{ preferences: Preferences }>("/preferences")
      .then((response) => {
        if (active) setPreferencesState(response.preferences);
      })
      .catch(() => {
        if (active) setPreferencesState(defaultPreferences);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [token]);

  const setPreferences = useCallback(async (patch: Partial<Preferences>) => {
    const next = { ...preferences, ...patch };
    setPreferencesState(next);
    if (token) {
      try {
        const response = await api<{ preferences: Preferences }>("/preferences", {
          method: "PATCH",
          body: patch,
        });
        setPreferencesState(response.preferences);
      } catch {
        setPreferencesState(preferences);
      }
    }
  }, [preferences, token]);

  const value = useMemo(() => ({ preferences, setPreferences, loading }), [preferences, setPreferences, loading]);

  return <PreferencesContext.Provider value={value}>{children}</PreferencesContext.Provider>;
}

export function usePreferences(): PreferencesContextValue {
  const context = useContext(PreferencesContext);
  if (!context) throw new Error("usePreferences must be used inside PreferencesProvider");
  return context;
}
