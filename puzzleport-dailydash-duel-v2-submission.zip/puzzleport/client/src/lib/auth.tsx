import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { ApiError, api, clearToken, errorMessage, getToken, setToken } from "./api";
import type { User } from "./types";

type RegisterInput = {
  displayName: string;
  username: string;
  email: string;
  password: string;
  avatar: string;
};

type AuthContextValue = {
  user: User | null;
  loading: boolean;
  signIn: (identifier: string, password: string) => Promise<User>;
  signUp: (input: RegisterInput) => Promise<User>;
  signOut: () => Promise<void>;
  refresh: () => Promise<void>;
  updateProfile: (input: { displayName?: string; avatar?: string }) => Promise<User>;
};

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    if (!getToken()) {
      setLoading(false);
      return;
    }
    api<{ user: User }>("/auth/me")
      .then((response) => {
        if (active) setUser(response.user);
      })
      .catch((error) => {
        // A network blip should not silently log the player out; only a rejected token does.
        if (error instanceof ApiError && error.status === 401) clearToken();
        if (active) setUser(null);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    const handleUnauthorized = () => {
      clearToken();
      setUser(null);
    };
    window.addEventListener("puzzleport:unauthorized", handleUnauthorized);
    return () => window.removeEventListener("puzzleport:unauthorized", handleUnauthorized);
  }, []);

  const signIn = useCallback(async (identifier: string, password: string) => {
    const response = await api<{ token: string; user: User }>("/auth/login", {
      method: "POST",
      body: { identifier, password },
    });
    setToken(response.token);
    setUser(response.user);
    return response.user;
  }, []);

  const signUp = useCallback(async (input: RegisterInput) => {
    const response = await api<{ token: string; user: User }>("/auth/register", {
      method: "POST",
      body: input,
    });
    setToken(response.token);
    setUser(response.user);
    return response.user;
  }, []);

  const signOut = useCallback(async () => {
    try {
      await api("/auth/logout", { method: "POST" });
    } catch (error) {
      if (import.meta.env.DEV) console.warn("Logout request failed:", errorMessage(error));
    } finally {
      clearToken();
      setUser(null);
    }
  }, []);

  const refresh = useCallback(async () => {
    if (!getToken()) {
      setUser(null);
      return;
    }
    const response = await api<{ user: User }>("/auth/me");
    setUser(response.user);
  }, []);

  const updateProfile = useCallback(async (input: { displayName?: string; avatar?: string }) => {
    const response = await api<{ user: User }>("/auth/me", { method: "PATCH", body: input });
    setUser(response.user);
    return response.user;
  }, []);

  const value = useMemo(
    () => ({ user, loading, signIn, signUp, signOut, refresh, updateProfile }),
    [user, loading, signIn, signUp, signOut, refresh, updateProfile],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used inside AuthProvider");
  return context;
}
