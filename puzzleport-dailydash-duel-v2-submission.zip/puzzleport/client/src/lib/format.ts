import type { GameKey } from "./types";

export const AVATARS = ["🦊", "🐰", "🐼", "🐸", "🐱", "🦄", "🐙", "🍓"] as const;

export const GAME_META: Record<
  GameKey,
  { label: string; short: string; emoji: string; tagline: string; accent: string }
> = {
  memory: {
    label: "Memory Match",
    short: "Memory",
    emoji: "🃏",
    tagline: "Find all eight sweet pairs",
    accent: "mint",
  },
  "2048": {
    label: "2048",
    short: "2048",
    emoji: "🔢",
    tagline: "Slide, merge, and reach 2048",
    accent: "sky",
  },
};

export function formatDuration(ms: number): string {
  const total = Math.max(0, Math.floor(ms / 1000));
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const seconds = total % 60;
  if (hours > 0) return `${hours}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
  return `${minutes}:${String(seconds).padStart(2, "0")}`;
}

export function formatCountdown(ms: number): string {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const seconds = total % 60;
  return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

export function formatNumber(value: number): string {
  return new Intl.NumberFormat("en-IN").format(value);
}

export function formatDate(iso: string | null): string {
  if (!iso) return "—";
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "—";
  return new Intl.DateTimeFormat("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  }).format(date);
}

export function formatDateTime(iso: string | null): string {
  if (!iso) return "—";
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "—";
  return new Intl.DateTimeFormat("en-IN", {
    day: "numeric",
    month: "short",
    hour: "numeric",
    minute: "2-digit",
  }).format(date);
}

export function formatDailyLabel(dateKey: string): string {
  const date = new Date(`${dateKey}T12:00:00+05:30`);
  if (Number.isNaN(date.getTime())) return dateKey;
  return new Intl.DateTimeFormat("en-IN", {
    weekday: "short",
    day: "numeric",
    month: "short",
    timeZone: "Asia/Kolkata",
  }).format(date);
}

export function levelInfo(xp: number): {
  level: number;
  floor: number;
  nextAt: number;
  progress: number;
  remaining: number;
} {
  const safeXp = Math.max(0, xp);
  const level = Math.floor(Math.sqrt(safeXp / 100)) + 1;
  const floor = 100 * (level - 1) ** 2;
  const nextAt = 100 * level ** 2;
  const span = Math.max(1, nextAt - floor);
  const progress = Math.min(100, Math.max(0, ((safeXp - floor) / span) * 100));
  return { level, floor, nextAt, progress, remaining: Math.max(0, nextAt - safeXp) };
}

export function metricFor(game: GameKey, entry: { score: number; moves: number; durationMs: number }): string {
  if (game === "memory") return `${entry.moves} moves`;
  return `${formatNumber(entry.score)} pts`;
}
