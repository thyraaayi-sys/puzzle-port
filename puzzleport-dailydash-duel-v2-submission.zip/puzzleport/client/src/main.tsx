import "@fontsource/fredoka/500.css";
import "@fontsource/fredoka/600.css";
import "@fontsource-variable/nunito";
import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App";
import { AuthProvider, useAuth } from "./lib/auth";
import { ToastProvider } from "./components/Toast";
import { PreferencesProvider } from "./lib/preferences";
import "./styles/base.css";
import "./styles/components.css";
import "./styles/pages.css";
import "./styles/games.css";
import "./styles/responsive.css";

function AppWithProviders() {
  const { user } = useAuth();
  const token = user ? window.localStorage.getItem("puzzleport.token") : null;
  return (
    <PreferencesProvider token={token}>
      <ToastProvider>
        <App />
      </ToastProvider>
    </PreferencesProvider>
  );
}

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <BrowserRouter>
      <AuthProvider>
        <AppWithProviders />
      </AuthProvider>
    </BrowserRouter>
  </React.StrictMode>,
);
