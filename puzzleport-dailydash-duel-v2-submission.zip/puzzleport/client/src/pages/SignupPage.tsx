import { useState, type FormEvent } from "react";
import { Link, Navigate, useNavigate, useSearchParams } from "react-router-dom";
import { Eye, EyeOff, Sparkles } from "lucide-react";
import AuthShell from "../components/AuthShell";
import { Avatar } from "../components/ui";
import { useAuth } from "../lib/auth";
import { errorMessage, ApiError } from "../lib/api";
import { AVATARS } from "../lib/format";

function safeNext(value: string | null): string {
  if (!value || !value.startsWith("/") || value.startsWith("//")) return "/";
  return value;
}

export default function SignupPage() {
  const { user, signUp } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const next = safeNext(searchParams.get("next"));
  const [displayName, setDisplayName] = useState("");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [avatar, setAvatar] = useState<string>(AVATARS[0]);
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  if (user) return <Navigate to={next} replace />;

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);

    if (displayName.trim().length < 2) {
      setError("Display name needs at least 2 characters.");
      return;
    }
    if (!/^[A-Za-z0-9_]{3,20}$/.test(username.trim())) {
      setError("Username must be 3–20 characters using letters, numbers, or underscores.");
      return;
    }
    if (password.length < 8) {
      setError("Password needs at least 8 characters.");
      return;
    }

    setPending(true);
    try {
      await signUp({
        displayName: displayName.trim(),
        username: username.trim(),
        email: email.trim(),
        password,
        avatar,
      });
      navigate(next, { replace: true });
    } catch (err) {
      if (err instanceof ApiError && err.code === "USERNAME_TAKEN") {
        setError("That username is already taken. Try another one.");
      } else if (err instanceof ApiError && err.code === "EMAIL_TAKEN") {
        setError("An account with that email already exists. Try signing in.");
      } else {
        setError(errorMessage(err));
      }
    } finally {
      setPending(false);
    }
  };

  return (
    <AuthShell
      eyebrow="Join the parlour"
      title="Create your player"
      subtitle="Choose a little avatar, pick a name, and start today's dash."
      footer={
        <>
          Already have an account?{" "}
          <Link to={`/login${next !== "/" ? `?next=${encodeURIComponent(next)}` : ""}`}>Sign in</Link>
        </>
      }
    >
      <form className="form-stack" onSubmit={handleSubmit} noValidate>
        {error && (
          <div className="form-alert" role="alert">
            {error}
          </div>
        )}

        <fieldset className="avatar-field">
          <legend>Pick your avatar</legend>
          <div className="avatar-options">
            {AVATARS.map((option) => (
              <button
                type="button"
                key={option}
                className={`avatar-option${avatar === option ? " is-selected" : ""}`}
                onClick={() => setAvatar(option)}
                aria-pressed={avatar === option}
                aria-label={`Choose ${option} avatar`}
              >
                <Avatar avatar={option} size="sm" />
              </button>
            ))}
          </div>
        </fieldset>

        <div className="form-grid-two">
          <label className="field">
            <span>Display name</span>
            <input
              type="text"
              value={displayName}
              onChange={(event) => setDisplayName(event.target.value)}
              autoComplete="name"
              placeholder="Strawberry Fox"
              required
              minLength={2}
              maxLength={40}
              disabled={pending}
            />
          </label>
          <label className="field">
            <span>Username</span>
            <input
              type="text"
              value={username}
              onChange={(event) => setUsername(event.target.value)}
              autoComplete="username"
              placeholder="strawberryfox"
              required
              minLength={3}
              maxLength={20}
              pattern="[A-Za-z0-9_]+"
              disabled={pending}
            />
          </label>
        </div>

        <label className="field">
          <span>Email</span>
          <input
            type="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            autoComplete="email"
            placeholder="you@example.com"
            required
            maxLength={160}
            disabled={pending}
          />
        </label>

        <label className="field">
          <span>Password</span>
          <span className="password-wrap">
            <input
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              autoComplete="new-password"
              placeholder="At least 8 characters"
              required
              minLength={8}
              maxLength={72}
              disabled={pending}
            />
            <button
              type="button"
              className="password-toggle"
              onClick={() => setShowPassword((value) => !value)}
              aria-label={showPassword ? "Hide password" : "Show password"}
              aria-pressed={showPassword}
            >
              {showPassword ? <EyeOff size={18} aria-hidden="true" /> : <Eye size={18} aria-hidden="true" />}
            </button>
          </span>
        </label>

        <button type="submit" className="btn btn-primary btn-wide" disabled={pending}>
          <Sparkles size={17} aria-hidden="true" />
          {pending ? "Creating your player…" : "Create account"}
        </button>
        <p className="form-note">
          Passwords are hashed with bcrypt on the server. Email verification is intentionally not
          simulated in this emergency build.
        </p>
      </form>
    </AuthShell>
  );
}
