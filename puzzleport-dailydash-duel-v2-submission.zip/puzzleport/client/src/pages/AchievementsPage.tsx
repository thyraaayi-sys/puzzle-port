import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Award, CheckCircle2, Gift, Lock, Sparkles } from "lucide-react";
import { PageHeader, EmptyState, LoadingBlock } from "../components/ui";
import { useAuth } from "../lib/auth";
import { useToast } from "../components/Toast";
import { usePreferences } from "../lib/preferences";
import { api, errorMessage } from "../lib/api";
import { playSound } from "../lib/audio";
import type { ProgressionResponse } from "../lib/types";

export default function AchievementsPage() {
  const { refresh } = useAuth();
  const toast = useToast();
  const preferences = usePreferences().preferences;
  const [data, setData] = useState<ProgressionResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [claiming, setClaiming] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      setData(await api<ProgressionResponse>("/progression"));
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
  }, []);

  const claim = async (slug: string) => {
    setClaiming(slug);
    try {
      const response = await api<{ xpGain: number; coinGain: number }>("/quests/" + slug + "/claim", { method: "POST" });
      playSound("reward", { soundEnabled: preferences.soundEnabled, sfxEnabled: preferences.sfxEnabled, volume: preferences.masterVolume });
      toast.reward("Quest claimed", `+${response.xpGain} XP · +${response.coinGain} coins`);
      await load();
      await refresh();
    } catch (err) {
      toast.error("Claim failed", errorMessage(err));
    } finally {
      setClaiming(null);
    }
  };

  if (loading) return <div className="page"><LoadingBlock label="Opening your trophy case…" /></div>;
  if (error || !data) return <div className="page"><PageHeader title="Achievements" subtitle={error ?? "Unavailable"} /></div>;

  return (
    <div className="page achievements-page">
      <PageHeader eyebrow="Progression" title="Achievements & quests" subtitle="Earn XP, coins, and bragging rights." />

      <section className="profile-panel glass" aria-labelledby="quests-heading">
        <div className="panel-head">
          <div>
            <p className="eyebrow">Daily quests</p>
            <h2 id="quests-heading">Today's challenges</h2>
          </div>
        </div>
        <div className="grid-auto">
          {data.quests.daily.map((quest) => (
            <article key={quest.slug} className={`glass quest-card${quest.completed ? " is-complete" : ""}`}>
              <span className="quest-emoji" aria-hidden="true">{quest.emoji}</span>
              <div className="quest-copy">
                <h3>{quest.title}</h3>
                <p>{quest.description}</p>
                <div className="xp-track" style={{ marginTop: 8 }}>
                  <div className="xp-fill" style={{ width: `${Math.min(100, (quest.progress / quest.target) * 100)}%` }} />
                </div>
                <small>{quest.progress}/{quest.target}</small>
              </div>
              {quest.completed && !quest.claimed ? (
                <button type="button" className="btn btn-primary btn-small" disabled={claiming === quest.slug} onClick={() => claim(quest.slug)}>
                  <Gift size={14} /> Claim
                </button>
              ) : quest.claimed ? (
                <span className="status-pill is-done"><CheckCircle2 size={13} /> Claimed</span>
              ) : (
                <span className="status-pill">In progress</span>
              )}
            </article>
          ))}
        </div>
      </section>

      <section className="profile-panel glass" aria-labelledby="weekly-quests">
        <div className="panel-head">
          <div>
            <p className="eyebrow">Weekly quests</p>
            <h2 id="weekly-quests">This week</h2>
          </div>
        </div>
        <div className="grid-auto">
          {data.quests.weekly.map((quest) => (
            <article key={quest.slug} className={`glass quest-card${quest.completed ? " is-complete" : ""}`}>
              <span className="quest-emoji" aria-hidden="true">{quest.emoji}</span>
              <div className="quest-copy">
                <h3>{quest.title}</h3>
                <p>{quest.description}</p>
                <div className="xp-track" style={{ marginTop: 8 }}>
                  <div className="xp-fill" style={{ width: `${Math.min(100, (quest.progress / quest.target) * 100)}%` }} />
                </div>
                <small>{quest.progress}/{quest.target}</small>
              </div>
              {quest.completed && !quest.claimed ? (
                <button type="button" className="btn btn-primary btn-small" disabled={claiming === quest.slug} onClick={() => claim(quest.slug)}>
                  <Gift size={14} /> Claim
                </button>
              ) : quest.claimed ? (
                <span className="status-pill is-done"><CheckCircle2 size={13} /> Claimed</span>
              ) : (
                <span className="status-pill">In progress</span>
              )}
            </article>
          ))}
        </div>
      </section>

      <section className="profile-panel glass" aria-labelledby="achievements-heading">
        <div className="panel-head">
          <div>
            <p className="eyebrow">Achievements</p>
            <h2 id="achievements-heading">Trophy case</h2>
          </div>
          <Sparkles size={18} aria-hidden="true" className="panel-sparkle" />
        </div>
        <div className="grid-auto">
          {data.achievements.map((achievement) => (
            <article key={achievement.slug} className={`glass achievement-card${achievement.unlocked ? " is-unlocked" : ""}`}>
              <span className="achievement-emoji" aria-hidden="true">{achievement.unlocked ? achievement.emoji : "🔒"}</span>
              <div className="achievement-copy">
                <h3>{achievement.title}</h3>
                <p>{achievement.description}</p>
                <small>+{achievement.xpReward} XP · +{achievement.coinReward} coins</small>
              </div>
              {achievement.unlocked ? (
                <span className="status-pill is-done"><CheckCircle2 size={13} /> Unlocked</span>
              ) : (
                <span className="status-pill"><Lock size={12} /> Locked</span>
              )}
            </article>
          ))}
        </div>
      </section>

      <div className="page-actions" style={{ marginTop: 24 }}>
        <Link to="/profile" className="btn btn-ghost">Profile</Link>
        <Link to="/collection" className="btn btn-primary">Collection</Link>
      </div>
    </div>
  );
}

