import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Settings as SettingsIcon, Volume2 } from "lucide-react";
import { PageHeader, LoadingBlock } from "../components/ui";
import { useAuth } from "../lib/auth";
import { usePreferences } from "../lib/preferences";
import { useToast } from "../components/Toast";
import { api, errorMessage } from "../lib/api";
import { playSound } from "../lib/audio";
import type { ProgressionResponse } from "../lib/types";

export default function SettingsPage() {
  const { user } = useAuth();
  const toast = useToast();
  const { preferences, setPreferences } = usePreferences();
  const [progression, setProgression] = useState<ProgressionResponse | null>(null);

  useEffect(() => {
    if (!user) return;
    api<ProgressionResponse>("/progression").then(setProgression).catch(() => undefined);
  }, [user]);

  if (!user) return null;

  const toggle = async (patch: Partial<typeof preferences>) => {
    await setPreferences(patch);
    playSound("click", { soundEnabled: preferences.soundEnabled, sfxEnabled: preferences.sfxEnabled, volume: preferences.masterVolume });
    toast.success("Saved", "Your preferences were updated.");
  };

  return (
    <div className="page settings-page">
      <PageHeader eyebrow="Settings" title="Tune your port" subtitle="Audio, accessibility, and visual preferences." />

      <section className="profile-panel glass">
        <div className="panel-head">
          <div>
            <p className="eyebrow">Audio</p>
            <h2>Sound</h2>
          </div>
          <Volume2 size={18} aria-hidden="true" />
        </div>
        <div className="settings-list">
          <label className="setting-row">
            <span>Master sound</span>
            <span className="switch">
              <input type="checkbox" checked={preferences.soundEnabled} onChange={(e) => toggle({ soundEnabled: e.target.checked })} />
              <span className="switch-track" aria-hidden="true" />
            </span>
          </label>
          <label className="setting-row">
            <span>Game effects</span>
            <span className="switch">
              <input type="checkbox" checked={preferences.sfxEnabled} onChange={(e) => toggle({ sfxEnabled: e.target.checked })} />
              <span className="switch-track" aria-hidden="true" />
            </span>
          </label>
          <label className="setting-row">
            <span>Volume</span>
            <input className="volume-slider" type="range" min={0} max={1} step={0.05} value={preferences.masterVolume} onChange={(e) => toggle({ masterVolume: Number(e.target.value) })} />
          </label>
        </div>
      </section>

      <section className="profile-panel glass">
        <div className="panel-head">
          <div>
            <p className="eyebrow">Accessibility</p>
            <h2>Visuals</h2>
          </div>
          <SettingsIcon size={18} aria-hidden="true" />
        </div>
        <div className="settings-list">
          <label className="setting-row">
            <span>High contrast</span>
            <span className="switch">
              <input type="checkbox" checked={preferences.highContrast} onChange={(e) => toggle({ highContrast: e.target.checked })} />
              <span className="switch-track" aria-hidden="true" />
            </span>
          </label>
          <label className="setting-row">
            <span>Colorblind patterns</span>
            <span className="switch">
              <input type="checkbox" checked={preferences.colorblindPatterns} onChange={(e) => toggle({ colorblindPatterns: e.target.checked })} />
              <span className="switch-track" aria-hidden="true" />
            </span>
          </label>
          <label className="setting-row">
            <span>Reduced motion</span>
            <span className="switch">
              <input type="checkbox" checked={preferences.reducedMotion} onChange={(e) => toggle({ reducedMotion: e.target.checked })} />
              <span className="switch-track" aria-hidden="true" />
            </span>
          </label>
        </div>
      </section>

      {progression && (
        <section className="profile-panel glass">
          <div className="panel-head">
            <div>
              <p className="eyebrow">Equipped</p>
              <h2>Your loadout</h2>
            </div>
          </div>
          <div className="loadout-grid">
            {Object.entries(progression.user.equipped).map(([slot, value]) => (
              <span key={slot} className="loadout-chip">
                <small>{slot.replace(/([A-Z])/g, " $1")}</small>
                <strong>{value}</strong>
              </span>
            ))}
          </div>
        </section>
      )}

      <div className="page-actions" style={{ marginTop: 24 }}>
        <Link to="/collection" className="btn btn-primary">Open collection</Link>
        <Link to="/profile" className="btn btn-ghost">Profile</Link>
      </div>
    </div>
  );
}

