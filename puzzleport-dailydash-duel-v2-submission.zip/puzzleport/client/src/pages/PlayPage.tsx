import { Link } from "react-router-dom";
import { ArrowRight, CheckCircle2, Flame, Gamepad2, Sparkles, Trophy } from "lucide-react";
import { Countdown } from "../components/Countdown";
import { ErrorNotice } from "../components/ui";
import { useAuth } from "../lib/auth";
import { useDaily } from "../hooks/useDaily";
import { formatDailyLabel, GAME_META } from "../lib/format";
import type { GameKey } from "../lib/types";

function howManyPairs(game: GameKey) {
  return game === "memory" ? "8 pairs · 16 cards" : "4×4 board · merge to 2048";
}

export default function PlayPage() {
  const { user } = useAuth();
  const { data: daily, loading, error, reload } = useDaily();

  return (
    <div className="page play-page">
      <header className="page-header play-header">
        <div>
          <p className="eyebrow">
            <Gamepad2 size={14} aria-hidden="true" /> The game room
          </p>
          <h1>Pick a puzzle, find your flow.</h1>
          <p className="page-subtitle">
            Daily runs use today&apos;s shared seed and feed the daily leaderboard. Practice runs get
            a fresh seed and still count toward personal bests.
          </p>
        </div>
        {daily && (
          <div className="play-countdown glass">
            <span className="countdown-label">
              <Flame size={14} aria-hidden="true" /> Daily closes in
            </span>
            <Countdown endsAt={daily.endsAt} onExpire={reload} />
            <small>{formatDailyLabel(daily.dateKey)} · Asia/Kolkata</small>
          </div>
        )}
      </header>

      {error && <ErrorNotice message={error} onRetry={reload} />}

      <div className="play-grid">
        {(["memory", "2048"] as GameKey[]).map((game) => {
          const meta = GAME_META[game];
          const dailyState = daily?.games.find((item) => item.game === game);
          const targetBase = `/play/${game === "memory" ? "memory" : "2048"}`;
          const dailyTarget = `${targetBase}?mode=daily`;
          const practiceTarget = `${targetBase}?mode=classic`;
          const withAuth = (target: string) =>
            user ? target : `/login?next=${encodeURIComponent(target)}`;

          return (
            <article key={game} className={`play-card play-${meta.accent} glass`}>
              <div className="play-card-art" aria-hidden="true">
                {game === "memory" ? (
                  <div className="play-memory-preview">
                    <span className="preview-card is-up">🍓</span>
                    <span className="preview-card">✦</span>
                    <span className="preview-card is-up">🍓</span>
                    <span className="preview-card">✦</span>
                  </div>
                ) : (
                  <div className="play-2048-preview">
                    <span className="tile tile-2">2</span>
                    <span className="tile tile-4">4</span>
                    <span className="tile tile-8">8</span>
                    <span className="tile tile-16">16</span>
                    <span className="tile tile-32">32</span>
                    <span className="tile tile-64">64</span>
                  </div>
                )}
              </div>

              <div className="play-card-body">
                <div className="play-card-title">
                  <span className="play-emoji" aria-hidden="true">
                    {meta.emoji}
                  </span>
                  <div>
                    <h2>{meta.label}</h2>
                    <p>{meta.tagline}</p>
                  </div>
                </div>

                <div className="play-card-facts">
                  <span>{howManyPairs(game)}</span>
                  <span>{game === "memory" ? "Moves + time ranked" : "Score ranked"}</span>
                </div>

                {loading ? (
                  <span className="loading-line" aria-label="Loading daily status" />
                ) : dailyState?.completed ? (
                  <p className="completion-note">
                    <CheckCircle2 size={16} aria-hidden="true" /> You completed today&apos;s daily —
                    replays can improve your best.
                  </p>
                ) : (
                  <p className="completion-note is-pending">
                    <Sparkles size={16} aria-hidden="true" /> Today&apos;s daily is ready for its
                    first run.
                  </p>
                )}

                <div className="play-card-actions">
                  <Link to={withAuth(dailyTarget)} className="btn btn-primary">
                    {user ? "Play daily" : "Sign in to play daily"}
                    <ArrowRight size={16} aria-hidden="true" />
                  </Link>
                  <Link to={withAuth(practiceTarget)} className="btn btn-glass">
                    Practice
                  </Link>
                </div>
              </div>
            </article>
          );
        })}
      </div>

      <section className="play-bottom glass">
        <div>
          <p className="eyebrow">
            <Trophy size={14} aria-hidden="true" /> Keep it fair
          </p>
          <h2>Daily scores, practice scores, and personal bests</h2>
        </div>
        <div className="play-notes">
          <p>
            <strong>Daily:</strong> the layout is deterministic from today&apos;s server seed, so
            every player sees the same puzzle. Only your best daily run occupies your leaderboard
            spot.
          </p>
          <p>
            <strong>Practice:</strong> a random seed keeps things fresh. Practice results count
            toward profile stats and all-time bests, but not the daily board.
          </p>
          <p>
            <strong>Saved runs:</strong> results are stored with your account and survive a
            server restart. This MVP uses basic score validation; full replay-based anti-cheat is
            documented as future work.
          </p>
        </div>
      </section>
    </div>
  );
}
