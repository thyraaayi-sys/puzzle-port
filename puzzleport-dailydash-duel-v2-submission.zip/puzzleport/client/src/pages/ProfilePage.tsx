import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  Award,
  Check,
  ChevronRight,
  Gamepad2,
  Lock,
  Pencil,
  Sparkles,
  Trophy,
} from "lucide-react";
import { Avatar, EmptyState, ErrorNotice, LoadingBlock, Modal, XPBar } from "../components/ui";
import { useAuth } from "../lib/auth";
import { api, errorMessage } from "../lib/api";
import {
  AVATARS,
  formatDate,
  formatDateTime,
  formatDuration,
  formatNumber,
  GAME_META,
  levelInfo,
} from "../lib/format";
import type { GameKey, HistoryResponse, ProgressionResponse, StatsResponse, User } from "../lib/types";

function bestLabel(game: GameKey, best: StatsResponse["best"][GameKey] | undefined): string {
  if (!best || best.bestScore == null) return "—";
  return game === "memory"
    ? `${best.bestMoves ?? "—"} moves`
    : `${formatNumber(best.bestScore)} pts`;
}

export default function ProfilePage() {
  const { user, updateProfile, signOut } = useAuth();
  const [stats, setStats] = useState<StatsResponse | null>(null);
  const [history, setHistory] = useState<HistoryResponse["history"]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [version, setVersion] = useState(0);
  const [editing, setEditing] = useState(false);
  const [progression, setProgression] = useState<ProgressionResponse | null>(null);
  const [editName, setEditName] = useState("");
  const [editAvatar, setEditAvatar] = useState("");
  const [saving, setSaving] = useState(false);
  const [editError, setEditError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError(null);
    Promise.all([api<StatsResponse>("/stats/me"), api<HistoryResponse>("/history?limit=20"), api<ProgressionResponse>("/progression")])
      .then(([statsResponse, historyResponse, progressionResponse]) => {
        if (!active) return;
        setStats(statsResponse);
        setHistory(historyResponse.history);
        setProgression(progressionResponse);
      })
      .catch((err) => {
        if (active) setError(errorMessage(err));
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [version]);

  const openEditor = () => {
    if (!user) return;
    setEditName(user.displayName);
    setEditAvatar(user.avatar);
    setEditError(null);
    setEditing(true);
  };

  const saveProfile = async () => {
    if (editName.trim().length < 2) {
      setEditError("Display name needs at least 2 characters.");
      return;
    }
    setSaving(true);
    setEditError(null);
    try {
      const updated: User = await updateProfile({ displayName: editName.trim(), avatar: editAvatar });
      setStats((current) => (current ? { ...current, user: { ...current.user, ...updated } } : current));
      setEditing(false);
    } catch (err) {
      setEditError(errorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  if (!user) return null;
  if (loading) {
    return (
      <div className="page profile-page">
        <LoadingBlock label="Opening your player card…" />
      </div>
    );
  }

  const xpInfo = levelInfo(stats?.user.xp ?? user.xp);
  const totalGames = stats?.totals.games ?? 0;
  const memoryBest = stats?.best.memory;
  const game2048Best = stats?.best["2048"];
  const dailyGames = history.filter((row) => row.mode === "daily").length;

  const milestones = [
    {
      key: "first",
      label: "First finish",
      detail: "Complete any game",
      done: totalGames >= 1,
    },
    {
      key: "regular",
      label: "Puzzle regular",
      detail: "Complete 10 games",
      done: totalGames >= 10,
    },
    {
      key: "memory-ace",
      label: "Memory ace",
      detail: "Finish Memory in 20 moves or fewer",
      done: memoryBest?.bestMoves != null && memoryBest.bestMoves <= 20,
    },
    {
      key: "2048-club",
      label: "2048 club",
      detail: "Score 2,048 points or more",
      done: game2048Best?.bestScore != null && game2048Best.bestScore >= 2048,
    },
    {
      key: "level-five",
      label: "Port regular",
      detail: "Reach level 5",
      done: (stats?.user.level ?? user.level) >= 5,
    },
    {
      key: "daily-bird",
      label: "Daily habit",
      detail: "Complete 5 daily runs (recent history)",
      done: dailyGames >= 5,
    },
  ];

  return (
    <div className="page profile-page">
      {error && <ErrorNotice message={error} onRetry={() => setVersion((value) => value + 1)} />}

      <section className="profile-hero glass">
        <Avatar avatar={user.avatar} level={user.level} size="xl" />
        <div className="profile-copy">
          <p className="eyebrow">Player card</p>
          <h1>{user.displayName}</h1>
          <p className="profile-handle">
            @{user.username} · Joined {formatDate(user.createdAt)}
          </p>
          <p className="profile-email">{user.email}</p>
          <XPBar xp={stats?.user.xp ?? user.xp} showLabel />
          <p className="xp-footnote">
            {formatNumber(stats?.user.xp ?? user.xp)} XP · {xpInfo.remaining} XP to level{" "}
            {xpInfo.level + 1}
          </p>
        </div>
        <div className="profile-actions">
          <button type="button" className="btn btn-glass" onClick={openEditor}>
            <Pencil size={16} aria-hidden="true" /> Edit player
          </button>
          <Link to="/play" className="btn btn-primary">
            <Gamepad2 size={16} aria-hidden="true" /> Play a game
          </Link>
          <button
            type="button"
            className="btn btn-ghost"
            onClick={() => {
              void signOut();
            }}
          >
            Sign out
          </button>
        </div>
      </section>

      <section className="profile-stats" aria-label="Player statistics">
        <div className="profile-stat glass">
          <span>Total games</span>
          <strong>{formatNumber(totalGames)}</strong>
          <small>Saved completions</small>
        </div>
        <div className="profile-stat glass">
          <span>Total points</span>
          <strong>{formatNumber(stats?.totals.totalScore ?? 0)}</strong>
          <small>Across both games</small>
        </div>
        <div className="profile-stat glass">
          <span>Coins</span>
          <strong>{formatNumber(progression?.user.coins ?? user.coins ?? 0)}</strong>
          <small>Persistent currency</small>
        </div>
        <div className="profile-stat glass">
          <span>Daily streak</span>
          <strong>{progression?.user.streak.current ?? user.streak?.current ?? 0}</strong>
          <small>Best {progression?.user.streak.best ?? user.streak?.best ?? 0}</small>
        </div>
        <div className="profile-stat glass">
          <span>Memory best</span>
          <strong>{memoryBest?.bestMoves != null ? `${memoryBest.bestMoves} moves` : "—"}</strong>
          <small>
            {memoryBest?.bestTimeMs != null
              ? `${formatDuration(memoryBest.bestTimeMs)} best time`
              : "No saved run"}
          </small>
        </div>
        <div className="profile-stat glass">
          <span>2048 best</span>
          <strong>{game2048Best?.bestScore != null ? formatNumber(game2048Best.bestScore) : "—"}</strong>
          <small>
            {game2048Best?.bestMoves != null
              ? `${formatNumber(game2048Best.bestMoves)} moves`
              : "No saved run"}
          </small>
        </div>
      </section>

      <div className="profile-grid">
        <section className="profile-panel glass" aria-labelledby="game-bests">
          <div className="panel-head">
            <div>
              <p className="eyebrow">
                <Trophy size={14} aria-hidden="true" /> Personal bests
              </p>
              <h2 id="game-bests">Your two games</h2>
            </div>
          </div>
          <div className="best-game-list">
            {(["memory", "2048"] as GameKey[]).map((game) => {
              const best = stats?.best[game];
              const meta = GAME_META[game];
              return (
                <article key={game} className={`best-game best-${meta.accent}`}>
                  <span className="best-game-emoji" aria-hidden="true">
                    {meta.emoji}
                  </span>
                  <div className="best-game-copy">
                    <h3>{meta.label}</h3>
                    <p>
                      {best
                        ? `${best.gamesPlayed} completed · ${formatNumber(best.totalScore)} total points`
                        : "No completed games yet"}
                    </p>
                  </div>
                  <div className="best-game-metric">
                    <strong>{bestLabel(game, best)}</strong>
                    <span>personal best</span>
                  </div>
                  <Link to={`/play/${game === "memory" ? "memory" : "2048"}`} className="icon-btn" aria-label={`Play ${meta.label}`}>
                    <ChevronRight size={18} aria-hidden="true" />
                  </Link>
                </article>
              );
            })}
          </div>
        </section>

        <section className="profile-panel glass" aria-labelledby="milestones-heading">
          <div className="panel-head">
            <div>
              <p className="eyebrow">
                <Award size={14} aria-hidden="true" /> Milestones
              </p>
              <h2 id="milestones-heading">Little wins</h2>
            </div>
            <Sparkles size={18} aria-hidden="true" className="panel-sparkle" />
          </div>
          <ul className="milestone-list">
            {milestones.map((milestone) => (
              <li key={milestone.key} className={milestone.done ? "is-done" : ""}>
                <span className="milestone-icon" aria-hidden="true">
                  {milestone.done ? <Check size={15} /> : <Lock size={14} />}
                </span>
                <span>
                  <strong>{milestone.label}</strong>
                  <small>{milestone.detail}</small>
                </span>
                <span className="milestone-state">{milestone.done ? "Unlocked" : "Locked"}</span>
              </li>
            ))}
          </ul>
          <p className="panel-note">
            These milestones are derived from your saved stats. A persistent achievements table is
            future work.
          </p>
        </section>
      </div>

      <section className="profile-panel glass history-panel" aria-labelledby="history-heading">
        <div className="panel-head">
          <div>
            <p className="eyebrow">Recent runs</p>
            <h2 id="history-heading">Puzzle history</h2>
          </div>
          <Link to="/leaderboards" className="text-link">
            Leaderboards <ChevronRight size={14} aria-hidden="true" />
          </Link>
        </div>
        {history.length === 0 ? (
          <EmptyState
            emoji="🫧"
            title="No runs yet"
            description="Finish a Memory Match or 2048 game and it will appear here, saved to your account."
            action={
              <Link to="/play" className="btn btn-primary">
                Play your first game
              </Link>
            }
          />
        ) : (
          <div className="history-list">
            <div className="history-head" aria-hidden="true">
              <span>Game</span>
              <span>Mode</span>
              <span>Score</span>
              <span>Moves</span>
              <span>Time</span>
              <span>When</span>
            </div>
            {history.map((row) => (
              <div key={row.id} className="history-row">
                <span className="history-game">
                  <span aria-hidden="true">{GAME_META[row.game].emoji}</span>
                  {GAME_META[row.game].label}
                </span>
                <span>
                  <span className={`mode-chip ${row.mode === "daily" ? "is-daily" : ""}`}>
                    {row.mode === "daily" ? "Daily" : "Practice"}
                  </span>
                </span>
                <span className="history-score">{formatNumber(row.score)}</span>
                <span>{formatNumber(row.moves)}</span>
                <span>{formatDuration(row.durationMs)}</span>
                <span className="history-when">{formatDateTime(row.createdAt)}</span>
              </div>
            ))}
          </div>
        )}
      </section>

      {progression && (
        <section className="profile-panel glass" aria-labelledby="achievements-preview">
          <div className="panel-head">
            <div>
              <p className="eyebrow">Progression</p>
              <h2 id="achievements-preview">Achievements & quests</h2>
            </div>
            <Link to="/achievements" className="text-link">View all <ChevronRight size={14} aria-hidden="true" /></Link>
          </div>
          <p>{progression.achievements.filter((a) => a.unlocked).length}/{progression.achievements.length} achievements unlocked · {progression.quests.daily.filter((q) => q.completed).length} daily quests complete</p>
          <div className="best-game-list">
            {progression.campaign.memory.filter((level) => level.progress?.completedAt).slice(-3).map((level) => (
              <span key={level.id} className="status-pill is-done">Memory {level.levelNumber} · {level.progress?.bestStars}★</span>
            ))}
            {progression.campaign["2048"].filter((level) => level.progress?.completedAt).slice(-3).map((level) => (
              <span key={level.id} className="status-pill is-done">2048 {level.levelNumber} · {level.progress?.bestStars}★</span>
            ))}
          </div>
        </section>
      )}

      <Modal
        open={editing}
        title="Edit your player"
        onClose={() => setEditing(false)}
        size="sm"
        footer={
          <>
            <button type="button" className="btn btn-ghost" onClick={() => setEditing(false)}>
              Cancel
            </button>
            <button type="button" className="btn btn-primary" onClick={saveProfile} disabled={saving}>
              {saving ? "Saving…" : "Save changes"}
            </button>
          </>
        }
      >
        <div className="form-stack">
          {editError && (
            <div className="form-alert" role="alert">
              {editError}
            </div>
          )}
          <label className="field">
            <span>Display name</span>
            <input
              type="text"
              value={editName}
              onChange={(event) => setEditName(event.target.value)}
              minLength={2}
              maxLength={40}
              disabled={saving}
            />
          </label>
          <fieldset className="avatar-field">
            <legend>Avatar</legend>
            <div className="avatar-options">
              {AVATARS.map((option) => (
                <button
                  type="button"
                  key={option}
                  className={`avatar-option${editAvatar === option ? " is-selected" : ""}`}
                  onClick={() => setEditAvatar(option)}
                  aria-pressed={editAvatar === option}
                  aria-label={`Choose ${option} avatar`}
                >
                  <Avatar avatar={option} size="sm" />
                </button>
              ))}
            </div>
          </fieldset>
        </div>
      </Modal>
    </div>
  );
}
