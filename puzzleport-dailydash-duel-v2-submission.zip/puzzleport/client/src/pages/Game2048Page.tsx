import { useEffect, useRef, useState, type TouchEvent as ReactTouchEvent } from "react";
import { Link, useSearchParams } from "react-router-dom";
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  CheckCircle2,
  Clock3,
  Flag,
  Gauge,
  Hand,
  Keyboard,
  Play,
  RefreshCw,
  RotateCcw,
  Sparkles,
  Trophy,
} from "lucide-react";
import {
  applyMove,
  createGame,
  emptyBoard,
  maxTile,
  type Board,
  type Direction,
  type Rng,
} from "../../../server/src/games/game2048";
import { ErrorNotice, Modal, PageHeader, Spinner } from "../components/ui";
import { Confetti } from "../lib/Confetti";
import { useAuth } from "../lib/auth";
import { useDaily } from "../hooks/useDaily";
import { useToast } from "../components/Toast";
import { usePreferences } from "../lib/preferences";
import { api, errorMessage } from "../lib/api";
import { playSound } from "../lib/audio";
import { formatDailyLabel, formatDuration, formatNumber } from "../lib/format";
import type {
  PlayMode,
  SaveScoreResponse,
  Session,
  SessionResponse,
  StatsResponse,
} from "../lib/types";

type Phase = "setup" | "loading" | "playing" | "over";

function boardDescription(board: Board): string {
  return board.map((row, index) => `Row ${index + 1}: ${row.map((value) => (value === 0 ? "empty" : String(value))).join(", ")}.`).join(" ");
}

function directionFromKey(key: string): Direction | null {
  const normalized = key.toLowerCase();
  if (normalized === "arrowleft" || normalized === "a") return "left";
  if (normalized === "arrowright" || normalized === "d") return "right";
  if (normalized === "arrowup" || normalized === "w") return "up";
  if (normalized === "arrowdown" || normalized === "s") return "down";
  return null;
}

export default function Game2048Page() {
  const { refresh } = useAuth();
  const toast = useToast();
  const preferences = usePreferences().preferences;
  const [searchParams] = useSearchParams();
  const initialVariant = searchParams.get("variant") ?? searchParams.get("mode") ?? "daily";
  const levelId = searchParams.get("level");
  const { data: daily, reload: reloadDaily } = useDaily();

  const [variant, setVariant] = useState(initialVariant);
  const [phase, setPhase] = useState<Phase>("setup");
  const [session, setSession] = useState<Session | null>(null);
  const [board, setBoard] = useState<Board>(emptyBoard());
  const [score, setScore] = useState(0);
  const [moves, setMoves] = useState(0);
  const [best, setBest] = useState<number | null>(null);
  const [reached2048, setReached2048] = useState(false);
  const [startedAt, setStartedAt] = useState<number | null>(null);
  const [elapsed, setElapsed] = useState(0);
  const [announcement, setAnnouncement] = useState("Use the arrow keys, WASD, or swipe to move tiles.");
  const [error, setError] = useState<string | null>(null);
  const [gain, setGain] = useState<{ value: number; key: number } | null>(null);
  const [showWin, setShowWin] = useState(false);
  const [showResult, setShowResult] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [confirmRestart, setConfirmRestart] = useState(false);
  const [confirmFinish, setConfirmFinish] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [result, setResult] = useState<SaveScoreResponse | null>(null);
  const [confetti, setConfetti] = useState(false);
  const [actions, setActions] = useState<Direction[]>([]);

  const rngRef = useRef<Rng | null>(null);
  const gameRef = useRef({ board: emptyBoard(), score: 0, moves: 0, reached: false });
  const startedAtRef = useRef<number | null>(null);
  const submittedRef = useRef(false);
  const gainTimeoutRef = useRef<number | null>(null);
  const touchStartRef = useRef<{ x: number; y: number } | null>(null);
  const undoStackRef = useRef<Array<{ board: Board; score: number; moves: number; reached: boolean; rngState: number; actions: Direction[] }>>([]);

  const dailyState = daily?.games.find((game: { game: string }) => game.game === "2048");
  const config = session?.config ?? {};
  const size = Number(config.size ?? 4);
  const targetTile = Number(config.targetTile ?? 0);
  const moveLimit = Number(config.moveLimit ?? 0);
  const timeLimit = Number(config.timeLimitMs ?? 0);

  useEffect(() => {
    let active = true;
    api<StatsResponse>("/stats/me")
      .then((response) => {
        if (active) setBest(response.best["2048"]?.bestScore ?? null);
      })
      .catch(() => undefined);
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    return () => {
      if (gainTimeoutRef.current !== null) window.clearTimeout(gainTimeoutRef.current);
    };
  }, []);

  useEffect(() => {
    if (phase !== "playing" || startedAt === null) return;
    const tick = () => setElapsed(Date.now() - startedAt);
    tick();
    const interval = window.setInterval(tick, 250);
    return () => window.clearInterval(interval);
  }, [phase, startedAt]);

  const startGame = async (nextVariant: string = variant) => {
    setVariant(nextVariant);
    setPhase("loading");
    setError(null);
    setSaveError(null);
    setResult(null);
    setShowWin(false);
    setShowResult(false);
    setGameOver(false);
    setConfirmRestart(false);
    setConfirmFinish(false);
    setGain(null);
    setConfetti(false);
    setActions([]);
    setAnnouncement("Setting up your board…");
    try {
      const response = await api<SessionResponse>("/sessions", {
        method: "POST",
        body: {
          game: "2048",
          variant: nextVariant,
          levelId: nextVariant === "campaign" ? levelId : undefined,
        },
      });
      const initial = createGame(response.session.seed, Number(response.session.config.size ?? 4));
      rngRef.current = initial.rng;
      gameRef.current = { board: initial.board, score: 0, moves: 0, reached: false };
      submittedRef.current = false;
      undoStackRef.current = [];
      setSession(response.session);
      setBoard(initial.board);
      setScore(0);
      setMoves(0);
      setReached2048(false);
      setStartedAt(Date.now());
      startedAtRef.current = Date.now();
      setElapsed(0);
      setPhase("playing");
      setAnnouncement("New board ready. Slide a tile to begin.");
      window.scrollTo({ top: 0, behavior: "auto" });
    } catch (err) {
      setError(errorMessage(err));
      setPhase("setup");
    }
  };

  const submitScore = async (
    finalScore: number,
    finalMoves: number,
    finalElapsed: number,
    activeSession: Session | null,
  ) => {
    if (!activeSession) {
      setSaveError("The game session is missing. Please start a new run.");
      return;
    }
    if (submittedRef.current) return;
    submittedRef.current = true;
    setSaving(true);
    setSaveError(null);
    try {
      const response = await api<SaveScoreResponse>("/scores", {
        method: "POST",
        body: {
          sessionId: activeSession.id,
          score: finalScore,
          moves: finalMoves,
          actions,
        },
      });
      setResult(response);
      setBest((current) => Math.max(current ?? 0, response.score.score));
      reloadDaily();
      refresh().catch(() => undefined);
      setAnnouncement(`Run saved with ${formatNumber(response.score.score)} points in ${formatDuration(response.score.durationMs)}.`);
      if (response.achievements?.length) toast.reward("Achievement unlocked", response.achievements.join(", "));
      if (response.xpGain) playSound("reward", { soundEnabled: preferences.soundEnabled, sfxEnabled: preferences.sfxEnabled, volume: preferences.masterVolume });
      void finalElapsed;
    } catch (err) {
      submittedRef.current = false;
      setSaveError(errorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const endRun = (finalScore: number, finalMoves: number) => {
    const start = startedAtRef.current;
    const finalElapsed = start === null ? elapsed : Date.now() - start;
    setElapsed(finalElapsed);
    setPhase("over");
    setShowWin(false);
    setShowResult(true);
    setAnnouncement(`Run finished with ${formatNumber(finalScore)} points and ${finalMoves} moves. Saving your result.`);
    void submitScore(finalScore, finalMoves, finalElapsed, session);
  };

  const doMove = (direction: Direction) => {
    if (phase !== "playing" || showWin || showResult || confirmFinish || saving) return;
    const rng = rngRef.current;
    if (!rng) return;
    const current = gameRef.current;
    const outcome = applyMove(current.board, direction, rng);

    if (!outcome.moved) {
      if (outcome.gameOver) {
        endRun(current.score, current.moves);
      } else {
        setAnnouncement("That direction does not move anything. Try another way.");
      }
      return;
    }

    undoStackRef.current.push({
      board: current.board.map((row) => [...row]),
      score: current.score,
      moves: current.moves,
      reached: current.reached,
      rngState: rng.getState(),
      actions: [...actions],
    });
    if (undoStackRef.current.length > 100) undoStackRef.current.shift();

    const nextScore = current.score + outcome.gained;
    const nextMoves = current.moves + 1;
    const reachedNow = maxTile(outcome.board) >= 2048;
    const nextReached = current.reached || reachedNow;
    gameRef.current = { board: outcome.board, score: nextScore, moves: nextMoves, reached: nextReached };
    setBoard(outcome.board);
    setScore(nextScore);
    setMoves(nextMoves);
    setReached2048(nextReached);
    setActions((currentActions) => [...currentActions, direction]);

    if (outcome.gained > 0) {
      const nextGain = { value: outcome.gained, key: Date.now() };
      setGain(nextGain);
      if (gainTimeoutRef.current !== null) window.clearTimeout(gainTimeoutRef.current);
      gainTimeoutRef.current = window.setTimeout(() => setGain(null), 700);
      playSound(outcome.gained >= 128 ? "mergeBig" : "merge", { soundEnabled: preferences.soundEnabled, sfxEnabled: preferences.sfxEnabled, volume: preferences.masterVolume });
    } else {
      playSound("move", { soundEnabled: preferences.soundEnabled, sfxEnabled: preferences.sfxEnabled, volume: preferences.masterVolume });
    }

    if (outcome.gameOver) {
      endRun(nextScore, nextMoves);
      return;
    }

    if (reachedNow && !current.reached) {
      setShowWin(true);
      setConfetti(true);
      playSound("victory", { soundEnabled: preferences.soundEnabled, sfxEnabled: preferences.sfxEnabled, volume: preferences.masterVolume });
      setAnnouncement("You reached 2048! Keep going, or finish and save this run.");
      return;
    }

    if (targetTile > 0 && maxTile(outcome.board) >= targetTile && !current.reached) {
      setAnnouncement(`Target ${targetTile} reached! Finish to save this run.`);
    } else {
      setAnnouncement(`Moved ${direction}. Score ${formatNumber(nextScore)}. ${outcome.gained > 0 ? `Merged for ${outcome.gained} points.` : "A new tile appeared."}`);
    }
  };

  const undo = () => {
    const snapshot = undoStackRef.current.pop();
    if (!snapshot) return;
    gameRef.current = { board: snapshot.board, score: snapshot.score, moves: snapshot.moves, reached: snapshot.reached };
    rngRef.current?.setState(snapshot.rngState);
    setBoard(snapshot.board);
    setScore(snapshot.score);
    setMoves(snapshot.moves);
    setReached2048(snapshot.reached);
    setActions(snapshot.actions);
    playSound("click", { soundEnabled: preferences.soundEnabled, sfxEnabled: preferences.sfxEnabled, volume: preferences.masterVolume });
  };

  useEffect(() => {
    if (phase !== "playing" || showWin || showResult || confirmFinish) return;
    const handleKey = (event: KeyboardEvent) => {
      const direction = directionFromKey(event.key);
      if (!direction) return;
      event.preventDefault();
      doMove(direction);
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  });

  const handleTouchStart = (event: ReactTouchEvent<HTMLDivElement>) => {
    const touch = event.changedTouches[0];
    touchStartRef.current = { x: touch.clientX, y: touch.clientY };
  };

  const handleTouchEnd = (event: ReactTouchEvent<HTMLDivElement>) => {
    const start = touchStartRef.current;
    touchStartRef.current = null;
    if (!start || phase !== "playing") return;
    const touch = event.changedTouches[0];
    const dx = touch.clientX - start.x;
    const dy = touch.clientY - start.y;
    if (Math.max(Math.abs(dx), Math.abs(dy)) < 24) return;
    if (Math.abs(dx) > Math.abs(dy)) {
      doMove(dx > 0 ? "right" : "left");
    } else {
      doMove(dy > 0 ? "down" : "up");
    }
  };

  const finishRun = () => {
    setConfirmFinish(false);
    if (moves === 0) return;
    endRun(score, moves);
  };

  const retrySave = () => {
    if (session) void submitScore(score, moves, elapsed, session);
  };

  const displayBest = Math.max(best ?? 0, score);

  return (
    <div className="page game2048-page">
      <Confetti active={confetti} />
      <PageHeader
        eyebrow="2048"
        title={phase === "setup" ? "Slide. Merge. Breathe." : variant === "daily" ? "Daily challenge" : variant === "campaign" ? "Campaign level" : "Practice run"}
        subtitle={
          phase === "setup"
            ? "Choose a mode and start merging."
            : daily && variant === "daily"
              ? `Shared daily seed for ${formatDailyLabel(daily.dateKey)} · Asia/Kolkata`
              : variant === "campaign"
                ? `Campaign level ${levelId}`
                : "Practice seed · counts toward your personal bests"
        }
        actions={
          phase === "playing" ? (
            <>
              <button type="button" className="btn btn-ghost btn-small" onClick={() => setConfirmFinish(true)} disabled={moves === 0}>
                <Flag size={16} aria-hidden="true" /> Finish & save
              </button>
              <button type="button" className="btn btn-ghost btn-small" onClick={() => setConfirmRestart(true)}>
                <RotateCcw size={16} aria-hidden="true" /> Restart
              </button>
              {variant !== "daily" && variant !== "campaign" && (
                <button type="button" className="btn btn-ghost btn-small" onClick={undo} disabled={undoStackRef.current.length === 0}>
                  Undo
                </button>
              )}
            </>
          ) : phase === "over" ? (
            <button type="button" className="btn btn-primary btn-small" onClick={() => startGame(variant)}>
              <Play size={16} aria-hidden="true" /> New game
            </button>
          ) : (
            <Link to="/play" className="btn btn-ghost btn-small">
              <ArrowLeft size={16} aria-hidden="true" /> Game room
            </Link>
          )
        }
      />

      {error && <ErrorNotice message={error} onRetry={() => startGame(variant)} />}

      {phase === "setup" && (
        <section className="setup-2048 glass">
          <div className="setup-2048-copy">
            <p className="eyebrow"><Sparkles size={14} aria-hidden="true" /> Choose a mode</p>
            <h2>One board, many ways to play.</h2>
            <div className="mode-toggle" role="group" aria-label="Game mode">
              {[
                ["daily", "Daily", "The shared board of the day"],
                ["classic", "Classic", "A fresh board, cozy pace"],
                ["practice", "Practice", "Warm up your little tiles"],
                ["timed", "Timed", "Race the clock for points"],
                ["moves", "Move limit", "Make every slide count"],
                ["target", "Target tile", "Chase one shiny goal"],
                ["campaign", "Campaign", "Twenty tiny levels await"],
                ["endless", "Endless", "No finish line, just flow"],
              ].map(([value, label, description]) => (
                <button
                  key={value}
                  type="button"
                  className={`mode-option${variant === value ? " is-selected" : ""}`}
                  onClick={() => setVariant(value)}
                  aria-pressed={variant === value}
                >
                  <strong>{label}</strong>
                  <span>{description}</span>
                </button>
              ))}
            </div>
            <div className="setup-actions" style={{ marginTop: 16 }}>
              <button type="button" className="btn btn-primary btn-large" onClick={() => startGame(variant)}>
                <Play size={18} aria-hidden="true" /> Start
              </button>
              <span className="personal-best">
                <Trophy size={15} aria-hidden="true" /> Personal best: {best != null ? `${formatNumber(best)} pts` : "no saved run yet"}
              </span>
            </div>
          </div>
          <div className="setup-2048-art" aria-hidden="true">
            <div className="demo-2048">
              {[2, 4, 8, 16, 32, 64, 128, 256, 0, 2, 4, 8, 0, 0, 2, 4].map((value, index) => (
                <span key={index} className={`tile tile-${value || "empty"}`}>{value || ""}</span>
              ))}
            </div>
            <span className="setup-float setup-float-a">slide & merge</span>
            <span className="setup-float setup-float-b">tiny dopamine</span>
          </div>
        </section>
      )}

      {phase === "loading" && (
        <div className="game-loading glass">
          <Spinner label="Preparing the board" />
          <p>Folding a fresh board…</p>
        </div>
      )}

      {(phase === "playing" || phase === "over") && (
        <section className="game2048-game" aria-label="2048 game">
          <div className="game-layout">
            <div className="board-column">
              <div className="game-hud glass">
                <div className="hud-mode">
                  <span className={`mode-chip ${variant === "daily" ? "is-daily" : ""}`}>{variant}</span>
                  <div>
                    <span>Score</span>
                    <strong>{formatNumber(score)}</strong>
                  </div>
                </div>
                <div className="hud-stats">
                  <div>
                    <span><Trophy size={14} aria-hidden="true" /> Best</span>
                    <strong>{formatNumber(displayBest)}</strong>
                  </div>
                  <div>
                    <span><RefreshCw size={14} aria-hidden="true" /> Moves</span>
                    <strong>{moves}{moveLimit ? `/${moveLimit}` : ""}</strong>
                  </div>
                  <div>
                    <span><Clock3 size={14} aria-hidden="true" /> Time</span>
                    <strong>{formatDuration(elapsed)}{timeLimit ? `/${formatDuration(timeLimit)}` : ""}</strong>
                  </div>
                  {targetTile > 0 && (
                    <div>
                      <span><Gauge size={14} aria-hidden="true" /> Target</span>
                      <strong>{targetTile}</strong>
                    </div>
                  )}
                </div>
              </div>

              <div className="board-stage">
                {gain && !showResult && (
                  <span key={gain.key} className="score-gain" aria-hidden="true">+{gain.value}</span>
                )}
                <div
                  className={`board-2048${reached2048 ? " has-2048" : ""}`}
                  role="img"
                  aria-label={`2048 board. ${boardDescription(board)} Score ${score}.`}
                  onTouchStart={handleTouchStart}
                  onTouchEnd={handleTouchEnd}
                >
                  {board.map((row, rowIndex) =>
                    row.map((value, colIndex) => (
                      <div key={`${rowIndex}-${colIndex}`} className={`tile tile-${value === 0 ? "empty" : value}`} aria-hidden="true">
                        {value === 0 ? "" : value}
                      </div>
                    )),
                  )}
                </div>
                <p className="board-hint">
                  <Keyboard size={14} aria-hidden="true" /> Arrows / WASD
                  <span>·</span>
                  <Hand size={14} aria-hidden="true" /> Swipe on touch
                </p>
              </div>

              <p className="game-status" aria-live="polite">{announcement}</p>

              {phase === "over" && !showResult && (
                <div className="result-banner glass">
                  <div>
                    <strong>Run finished</strong>
                    <span>{formatNumber(score)} pts · {moves} moves · {formatDuration(elapsed)}</span>
                  </div>
                  <button type="button" className="btn btn-ghost btn-small" onClick={() => setShowResult(true)}>View result</button>
                </div>
              )}
            </div>

            <aside className="board-sidebar">
              <div className="dpad glass" aria-label="On-screen direction controls">
                <p className="eyebrow">D-pad</p>
                <div className="dpad-grid">
                  <button type="button" className="dpad-btn dpad-up" onClick={() => doMove("up")} disabled={phase !== "playing"} aria-label="Move up"><ArrowUp size={20} aria-hidden="true" /></button>
                  <button type="button" className="dpad-btn dpad-left" onClick={() => doMove("left")} disabled={phase !== "playing"} aria-label="Move left"><ArrowLeft size={20} aria-hidden="true" /></button>
                  <button type="button" className="dpad-btn dpad-down" onClick={() => doMove("down")} disabled={phase !== "playing"} aria-label="Move down"><ArrowDown size={20} aria-hidden="true" /></button>
                  <button type="button" className="dpad-btn dpad-right" onClick={() => doMove("right")} disabled={phase !== "playing"} aria-label="Move right"><ArrowRight size={20} aria-hidden="true" /></button>
                </div>
              </div>

              <div className="game-tip glass">
                <p className="eyebrow">A tiny strategy note</p>
                <p>Keep your biggest tile in a corner, and build rows in one direction. Merges only happen once per tile per move.</p>
              </div>

              {phase === "over" && (
                <div className="game-tip glass">
                  <p className="eyebrow">Saved run</p>
                  {saving ? (
                    <p><Spinner label="Saving run" /> Saving to SQLite…</p>
                  ) : result ? (
                    <p className="save-state is-success"><CheckCircle2 size={16} aria-hidden="true" /> Saved · +{result.xpGain} XP · +{result.coinGain ?? 0} coins</p>
                  ) : saveError ? (
                    <p className="save-state is-error">{saveError}</p>
                  ) : (
                    <p>Waiting for the save response…</p>
                  )}
                </div>
              )}
            </aside>
          </div>
        </section>
      )}

      <Modal open={showWin && phase === "playing"} title="You made 2048!" onClose={() => setShowWin(false)} footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={() => setShowWin(false)}>Keep going</button>
          <button type="button" className="btn btn-primary" onClick={finishRun}><Flag size={16} aria-hidden="true" /> Finish & save</button>
        </>
      }>
        <div className="result-hero" aria-hidden="true">✨</div>
        <p className="result-lede">The famous tile is on your board. Continue for a higher score, or bank this run now.</p>
        <div className="result-stats">
          <div><span>Score</span><strong>{formatNumber(score)}</strong></div>
          <div><span>Moves</span><strong>{moves}</strong></div>
          <div><span>Time</span><strong>{formatDuration(elapsed)}</strong></div>
        </div>
      </Modal>

      <Modal open={showResult} title={gameOver ? "No more moves" : "Run complete"} onClose={() => setShowResult(false)} footer={
        <>
          <button type="button" className="btn btn-primary" onClick={() => startGame(variant)}><RotateCcw size={16} aria-hidden="true" /> Play again</button>
          {result?.replayId && <Link to={`/replay/${result.replayId}`} className="btn btn-ghost"><Play size={16} aria-hidden="true" /> Watch replay</Link>}
          <Link to="/leaderboards?game=2048&period=daily" className="btn btn-ghost"><Trophy size={16} aria-hidden="true" /> Leaderboard</Link>
          <Link to="/play" className="btn btn-ghost">Game room</Link>
        </>
      }>
        <div className="result-hero" aria-hidden="true">{reached2048 ? "🌟" : "🧩"}</div>
        <p className="result-lede">
          {saving ? "Saving your score to SQLite…" : result ? "Saved. Your best daily run holds your place on the board." : saveError ? "Your score is not saved yet." : "Counting your tiles…"}
        </p>
        <div className="result-stats">
          <div><span>Score</span><strong>{formatNumber(score)}</strong></div>
          <div><span>Moves</span><strong>{moves}</strong></div>
          <div><span>Time</span><strong>{formatDuration(elapsed)}</strong></div>
          <div><span>Stars</span><strong>{result?.stars ?? 0}/3</strong></div>
        </div>
        {result && (
          <p className="save-state is-success">
            <CheckCircle2 size={16} aria-hidden="true" /> +{result.xpGain} XP · +{result.coinGain ?? 0} coins · Level {result.user.level}
            {result.achievements?.length ? ` · ${result.achievements.join(", ")}` : ""}
          </p>
        )}
        {saveError && <div className="form-alert" role="alert">{saveError} <button type="button" className="text-link" onClick={retrySave}>Retry saving</button></div>}
      </Modal>

      <Modal open={confirmFinish} title="Finish and save this run?" onClose={() => setConfirmFinish(false)} size="sm" footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={() => setConfirmFinish(false)}>Keep playing</button>
          <button type="button" className="btn btn-primary" onClick={finishRun}>Save & finish</button>
        </>
      }>
        <p>Your current score of {formatNumber(score)} points will be saved. This board will close and cannot be resumed.</p>
      </Modal>

      <Modal open={confirmRestart} title="Start a fresh board?" onClose={() => setConfirmRestart(false)} size="sm" footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={() => setConfirmRestart(false)}>Keep playing</button>
          <button type="button" className="btn btn-primary" onClick={() => startGame(variant)}>Restart</button>
        </>
      }>
        <p>Your current run will be abandoned and will not be saved. This cannot be undone.</p>
      </Modal>
    </div>
  );
}

