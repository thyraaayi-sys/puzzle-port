import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, RotateCcw, Trophy, Users } from "lucide-react";
import { PageHeader } from "../components/ui";
import { createMemoryDeck, type MemoryCard } from "../../../server/src/games/memory";

type Player = 1 | 2;

export default function DuelMemoryPage() {
  const [seed] = useState(() => crypto.randomUUID());
  const [deck, setDeck] = useState<MemoryCard[]>(() => createMemoryDeck(crypto.randomUUID()));
  const [firstIndex, setFirstIndex] = useState<number | null>(null);
  const [locked, setLocked] = useState(false);
  const [scores, setScores] = useState<[number, number]>([0, 0]);
  const [turn, setTurn] = useState<Player>(1);
  const [matched, setMatched] = useState(0);
  const [winner, setWinner] = useState<Player | null>(null);
  const timeoutRef = useRef<number | null>(null);

  const reset = () => {
    const newSeed = crypto.randomUUID();
    setDeck(createMemoryDeck(newSeed));
    setFirstIndex(null);
    setLocked(false);
    setScores([0, 0]);
    setTurn(1);
    setMatched(0);
    setWinner(null);
    void newSeed;
  };

  useEffect(() => {
    return () => {
      if (timeoutRef.current !== null) window.clearTimeout(timeoutRef.current);
    };
  }, []);

  const flip = (index: number) => {
    if (locked || winner) return;
    const card = deck[index];
    if (!card || card.matched || card.flipped) return;
    if (firstIndex === null) {
      setDeck((current) => current.map((item, i) => (i === index ? { ...item, flipped: true } : item)));
      setFirstIndex(index);
      return;
    }
    if (index === firstIndex) return;
    const first = deck[firstIndex];
    const revealed = deck.map((item, i) => (i === index || i === firstIndex ? { ...item, flipped: true } : item));
    setDeck(revealed);
    if (first.pairId === card.pairId) {
      const matchedDeck = revealed.map((item, i) => (i === index || i === firstIndex ? { ...item, matched: true } : item));
      setDeck(matchedDeck);
      setScores((current) => {
        const next: [number, number] = [...current];
        next[turn - 1] += 1;
        return next;
      });
      setMatched((value) => value + 1);
      setFirstIndex(null);
      if (matched + 1 === 8) {
        setWinner(scores[0] + (turn === 1 ? 1 : 0) > scores[1] + (turn === 2 ? 1 : 0) ? 1 : 2);
      }
    } else {
      setLocked(true);
      timeoutRef.current = window.setTimeout(() => {
        setDeck((current) => current.map((item, i) => (i === index || i === firstIndex ? { ...item, flipped: false } : item)));
        setFirstIndex(null);
        setLocked(false);
        setTurn((value) => (value === 1 ? 2 : 1));
      }, 900);
    }
  };

  return (
    <div className="page duel-memory-page">
      <PageHeader eyebrow="Local duel" title="Memory Match duel" subtitle="Alternate turns. A match keeps your turn." />
      <div className="duel-scoreboard glass">
        <div className={`duel-player${turn === 1 ? " is-active" : ""}`}>
          <strong>Player 1</strong>
          <span>{scores[0]} pairs</span>
        </div>
        <div className="duel-divider">VS</div>
        <div className={`duel-player${turn === 2 ? " is-active" : ""}`}>
          <strong>Player 2</strong>
          <span>{scores[1]} pairs</span>
        </div>
      </div>
      <p className="duel-turn">Player {turn}'s turn · {matched}/8 pairs found</p>
      <div className="memory-grid">
        {deck.map((card, index) => {
          const revealed = card.flipped || card.matched;
          return (
            <button key={card.id} type="button" className={`memory-card${revealed ? " is-flipped" : ""}${card.matched ? " is-matched" : ""}`} onClick={() => flip(index)} disabled={card.matched}>
              <span className="memory-card-inner">
                <span className="memory-face memory-back" aria-hidden="true"><span className="card-spark">✦</span></span>
                <span className="memory-face memory-front" aria-hidden="true"><span className="card-symbol">{card.symbol}</span></span>
              </span>
            </button>
          );
        })}
      </div>
      {winner && (
        <div className="glass duel-result">
          <Trophy size={24} aria-hidden="true" />
          <h2>Player {winner} wins!</h2>
          <p>{scores[0]} to {scores[1]}</p>
          <button type="button" className="btn btn-primary" onClick={reset}><RotateCcw size={16} /> Rematch</button>
        </div>
      )}
      <div className="page-actions" style={{ marginTop: 20 }}>
        <button type="button" className="btn btn-ghost" onClick={reset}><RotateCcw size={16} /> New deck</button>
        <Link to="/duel" className="btn btn-ghost"><ArrowLeft size={16} /> Back</Link>
      </div>
    </div>
  );
}

