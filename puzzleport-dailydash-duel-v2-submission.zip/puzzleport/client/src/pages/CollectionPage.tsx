import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Coins, Lock, Sparkles, Wand2 } from "lucide-react";
import { PageHeader } from "../components/ui";
import { Modal } from "../components/ui";
import { useAuth } from "../lib/auth";
import { useToast } from "../components/Toast";
import { usePreferences } from "../lib/preferences";
import { api, errorMessage } from "../lib/api";
import { playSound } from "../lib/audio";
import type { CatalogResponse, ProgressionResponse } from "../lib/types";

type Tab = "theme" | "card_back" | "border" | "flip" | "match_effect" | "victory_effect";

const TABS: Array<{ key: Tab; label: string }> = [
  { key: "theme", label: "Themes" },
  { key: "card_back", label: "Card backs" },
  { key: "border", label: "Borders" },
  { key: "flip", label: "Flip styles" },
  { key: "match_effect", label: "Match effects" },
  { key: "victory_effect", label: "Victory effects" },
];

const TAB_EMOJI: Record<Tab, string> = {
  theme: "🎨",
  card_back: "🃏",
  border: "🖼️",
  flip: "🔄",
  match_effect: "✨",
  victory_effect: "🎉",
};

export default function CollectionPage() {
  const { user, refresh } = useAuth();
  const toast = useToast();
  const preferences = usePreferences().preferences;
  const [catalog, setCatalog] = useState<CatalogResponse | null>(null);
  const [progression, setProgression] = useState<ProgressionResponse | null>(null);
  const [tab, setTab] = useState<Tab>("theme");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [preview, setPreview] = useState<{ type: string; id: string } | null>(null);
  const [buying, setBuying] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const [catalogResponse, progressionResponse] = await Promise.all([
        api<CatalogResponse>("/catalog"),
        api<ProgressionResponse>("/progression"),
      ]);
      setCatalog(catalogResponse);
      setProgression(progressionResponse);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
  }, []);

  const owned = (type: string, id: string) => Boolean(progression?.inventory[type]?.includes(id));

  const equip = async (slot: string, itemId: string) => {
    try {
      await api("/inventory/equip", { method: "POST", body: { slot, itemId } });
      playSound("click", { soundEnabled: preferences.soundEnabled, sfxEnabled: preferences.sfxEnabled, volume: preferences.masterVolume });
      toast.success("Equipped", `${itemId} is now active.`);
      await load();
      await refresh();
    } catch (err) {
      toast.error("Could not equip", errorMessage(err));
    }
  };

  const buy = async (type: string, id: string) => {
    setBuying(id);
    try {
      await api("/shop/purchase", { method: "POST", body: { itemType: type, itemId: id } });
      playSound("reward", { soundEnabled: preferences.soundEnabled, sfxEnabled: preferences.sfxEnabled, volume: preferences.masterVolume });
      toast.reward("Unlocked!", "New cosmetic added to your collection.");
      await load();
      await refresh();
    } catch (err) {
      toast.error("Purchase failed", errorMessage(err));
    } finally {
      setBuying(null);
    }
  };

  if (loading) return <div className="page"><PageHeader title="Collection" subtitle="Loading your cosmetics…" /></div>;
  if (error || !catalog || !progression) return <div className="page"><PageHeader title="Collection" subtitle={error ?? "Unavailable"} /></div>;

  const items = (tab === "theme" ? catalog.themes : catalog.cosmetics.filter((item) => item.type === tab)) as any[];
  const slotMap: Record<Tab, string> = {
    theme: "theme",
    card_back: "cardBack",
    border: "border",
    flip: "flip",
    match_effect: "matchEffect",
    victory_effect: "victoryEffect",
  };
  const equippedId = progression.user.equipped[slotMap[tab] as keyof ProgressionResponse["user"]["equipped"]];

  return (
    <div className="page collection-page">
      <PageHeader
        eyebrow="Collection"
        title="Your little dress-up chest"
        subtitle="Spend coins, unlock sweet themes, and dress your puzzle parlour however you like."
        actions={
          <div className="coin-pill">
            <Coins size={16} aria-hidden="true" /> <strong>{progression.user.coins}</strong>
          </div>
        }
      />

      <div className="tabs" role="tablist" aria-label="Cosmetic categories">
        {TABS.map((item) => (
          <button
            key={item.key}
            type="button"
            role="tab"
            aria-selected={tab === item.key}
            className={`tab-btn${tab === item.key ? " is-active" : ""}`}
            onClick={() => setTab(item.key)}
          >
            {item.label}
          </button>
        ))}
      </div>

      <div className="grid-auto">
        {items.map((item) => {
          const isOwned = owned(tab === "theme" ? "theme" : item.type, item.id);
          const isEquipped = equippedId === item.id;
          const locked = !isOwned && item.unlockType === "achievement";
          const available = item.active;
          return (
            <article key={item.id} className={`glass collection-card${isEquipped ? " is-equipped" : ""}`}>
              <div className="collection-preview" aria-hidden="true">
                {tab === "theme" ? (
                  <span className="theme-preview">
                    <span className="theme-preview-emoji">{(item as { emoji: string }).emoji}</span>
                    <span className="palette-dots">
                      {((item as { palette?: string[] }).palette ?? []).slice(0, 3).map((color) => (
                        <span key={color} className="palette-dot" style={{ background: color }} />
                      ))}
                    </span>
                  </span>
                ) : (
                  <span className="cosmetic-preview">
                    <span className="cosmetic-preview-emoji">{TAB_EMOJI[tab]}</span>
                    <small>{String(item.style).replace(/[-_]/g, " ")}</small>
                  </span>
                )}
              </div>
              <div className="collection-copy">
                <h3>{item.name}</h3>
                <p>{item.description}</p>
                <div className="collection-meta">
                  {item.unlockType === "default" && <span className="status-pill">Starter</span>}
                  {item.unlockType === "coins" && <span className="status-pill">{item.cost} coins</span>}
                  {item.unlockType === "achievement" && <span className="status-pill">Achievement</span>}
                  {item.unlockType === "event" && <span className="status-pill">{available ? "Event" : "Coming soon"}</span>}
                </div>
              </div>
              <div className="collection-actions">
                <button type="button" className="btn btn-ghost btn-small" onClick={() => setPreview({ type: tab === "theme" ? "theme" : item.type, id: item.id })}>
                  Preview
                </button>
                {isEquipped ? (
                  <span className="status-pill is-done">Equipped</span>
                ) : isOwned ? (
                  <button type="button" className="btn btn-primary btn-small" onClick={() => equip(slotMap[tab], item.id)}>
                    Equip
                  </button>
                ) : locked ? (
                  <span className="status-pill"><Lock size={12} /> Locked</span>
                ) : (
                  <button
                    type="button"
                    className="btn btn-primary btn-small"
                    disabled={buying === item.id || !available}
                    onClick={() => buy(tab === "theme" ? "theme" : item.type, item.id)}
                  >
                    {buying === item.id ? "Buying…" : `Buy ${item.cost}`}
                  </button>
                )}
              </div>
            </article>
          );
        })}
      </div>

      <Modal open={Boolean(preview)} title="Preview" onClose={() => setPreview(null)} size="sm">
        {preview && (
          <div className="preview-stage">
            <p>Previewing {preview.id}. Equip it to see it in game.</p>
          </div>
        )}
      </Modal>

      <div className="page-actions" style={{ marginTop: 24 }}>
        <Link to="/play" className="btn btn-ghost">Back to games</Link>
      </div>
    </div>
  );
}

