import { useEffect, useMemo, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import { ArrowLeft, Pause, Play, RotateCcw, SkipForward } from "lucide-react";
import { Link } from "react-router-dom";
import { PageHeader, LoadingBlock } from "../components/ui";
import { api, errorMessage } from "../lib/api";
import { formatDuration, formatNumber } from "../lib/format";
import { Game2048Engine } from "../../../server/src/games/game2048";
import { MemoryGame, createMemoryDeck } from "../../../server/src/games/memory";
import type { ReplayResponse } from "../lib/types";

export default function ReplayPage() {
  const { scoreId } = useParams();
  const [data, setData] = useState<ReplayResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [step, setStep] = useState(0);
  const [playing, setPlaying] = useState(false);
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    let active = true;
    if (!scoreId) return;
    api<ReplayResponse>(`/replays/${scoreId}`)
      .then((response) => {
        if (active) setData(response);
      })
      .catch((err) => {
        if (active) setError(errorMessage(err));
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [scoreId]);

  const isMemory = data?.replay.game === "memory";

  const frames = useMemo(() => {
    if (!data) return [];
    const replay = data.replay;
    if (replay.game === "2048") {
      const engine = new Game2048Engine(replay.seed, Number(replay.config.size ?? 4));
      const result = [cloneBoard(engine.board)];
      const scoreFrames = [0];
      for (const action of replay.actions) {
        engine.apply(action as "left" | "right" | "up" | "down", false);
        result.push(cloneBoard(engine.board));
        scoreFrames.push(engine.score);
      }
      return result.map((board, index) => ({ board, score: scoreFrames[index], label: index === 0 ? "Start" : `Move ${index}` }));
    }
    const config = replay.config as { pairs?: number; themeId?: string };
    const pairs = Number(config.pairs ?? 8);
    const symbols = (replay.config as { symbols?: string[] }).symbols ?? [];
    const deckSymbols = Array.isArray(symbols) && symbols.length >= pairs ? symbols : undefined;
    // Fallback symbols from catalog not available; use memory defaults by importing not needed.
    const deck = createMemoryDeck(replay.seed, deckSymbols ?? ["🍓", "🫐", "🍋", "🍑", "🍡", "🧁", "🌷", "⭐", "💎", "🚀", "🌊", "🐾", "🎨", "🪔", "❄️", "🌸", "🧩", "🎯"], pairs);
    const game = new (MemoryGame as any)(replay.seed, deckSymbols ?? ["🍓", "🫐", "🍋", "🍑", "🍡", "🧁", "🌷", "⭐", "💎", "🚀", "🌊", "🐾", "🎨", "🪔", "❄️", "🌸", "🧩", "🎯"], pairs);
    const states: Array<{ cards: typeof game.deck; moves: number; matched: number; label: string }> = [
      { cards: game.deck.map((card: any) => ({ ...card })), moves: 0, matched: 0, label: "Start" },
    ];
    for (let i = 0; i < replay.actions.length; i += 1) {
      if (game.locked) game.resolve();
      game.flip(replay.actions[i] as number);
      if (game.locked) {
        // keep mismatch visible for this frame; resolve next action
      }
      states.push({
        cards: game.deck.map((card: any) => ({ ...card })),
        moves: game.moves,
        matched: game.matchedPairs,
        label: `Flip ${i + 1}`,
      });
    }
    return states;
  }, [data]);

  useEffect(() => {
    if (!playing) {
      if (timerRef.current !== null) window.clearInterval(timerRef.current);
      timerRef.current = null;
      return;
    }
    timerRef.current = window.setInterval(() => {
      setStep((current) => {
        if (current >= frames.length - 1) {
          setPlaying(false);
          return current;
        }
        return current + 1;
      });
    }, 650);
    return () => {
      if (timerRef.current !== null) window.clearInterval(timerRef.current);
    };
  }, [playing, frames.length]);

  if (loading) return <div className="page"><LoadingBlock label="Loading replay…" /></div>;
  if (error || !data) return <div className="page"><PageHeader title="Replay" subtitle={error ?? "Unavailable"} /></div>;

  const replay = data.replay;
  const frame = frames[step] ?? frames[0];

  return (
    <div className="page replay-page">
      <PageHeader
        eyebrow="Ghost replay"
        title={`${replay.displayName}'s ${replay.game === "memory" ? "Memory" : "2048"} run`}
        subtitle={`${replay.moves} moves · ${formatNumber(replay.score)} pts · ${formatDuration(replay.durationMs)}`}
        actions={
          <Link to="/leaderboards" className="btn btn-ghost btn-small">
            <ArrowLeft size={16} aria-hidden="true" /> Leaderboards
          </Link>
        }
      />

      <section className="replay-layout">
        <div className="replay-board glass">
          {replay.game === "2048" ? (
            <div className="board-2048">
              {(frame as { board: number[][] }).board.map((row, rowIndex) =>
                row.map((value, colIndex) => (
                  <div key={`${rowIndex}-${colIndex}`} className={`tile tile-${value === 0 ? "empty" : value}`}>
                    {value === 0 ? "" : value}
                  </div>
                )),
              )}
            </div>
          ) : (
            <div className="memory-grid">
              {(frame as { cards: Array<{ id: number; symbol: string; flipped: boolean; matched: boolean }> }).cards.map((card) => (
                <div key={card.id} className={`memory-card${card.flipped || card.matched ? " is-flipped" : ""}${card.matched ? " is-matched" : ""}`}>
                  <span className="memory-card-inner">
                    <span className="memory-face memory-back" aria-hidden="true"><span className="card-spark">✦</span></span>
                    <span className="memory-face memory-front" aria-hidden="true"><span className="card-symbol">{card.symbol}</span></span>
                  </span>
                </div>
              ))}
            </div>
          )}
          <p className="replay-status">{frame?.label}</p>
        </div>

        <aside className="replay-controls glass">
          <div className="replay-meta">
            <span><strong>{replay.displayName}</strong> · Lv {replay.level}</span>
            <span>{replay.verified ? "Verified run" : "Basic validation"}</span>
          </div>
          <div className="replay-buttons">
            <button type="button" className="btn btn-ghost btn-small" onClick={() => setStep(0)}><RotateCcw size={14} /> Restart</button>
            <button type="button" className="btn btn-primary btn-small" onClick={() => setPlaying((value) => !value)}>
              {playing ? <Pause size={14} /> : <Play size={14} />} {playing ? "Pause" : "Play"}
            </button>
            <button type="button" className="btn btn-ghost btn-small" onClick={() => setStep((value) => Math.min(frames.length - 1, value + 1))}>
              <SkipForward size={14} /> Step
            </button>
          </div>
          <input
            type="range"
            min={0}
            max={Math.max(0, frames.length - 1)}
            value={step}
            onChange={(event) => setStep(Number(event.target.value))}
            aria-label="Replay progress"
          />
          <small>Step {step} of {Math.max(0, frames.length - 1)}</small>
          {replay.game === "2048" && <p className="replay-score">Score: {formatNumber((frame as { score: number }).score ?? 0)}</p>}
          {replay.game === "memory" && <p className="replay-score">Moves: {(frame as { moves: number }).moves ?? 0} · Pairs: {(frame as { matched: number }).matched ?? 0}</p>}
        </aside>
      </section>
    </div>
  );
}

function cloneBoard(board: number[][]): number[][] {
  return board.map((row) => [...row]);
}

