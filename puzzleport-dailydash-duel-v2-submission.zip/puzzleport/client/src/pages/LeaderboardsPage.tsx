import { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import {
  ArrowDown,
  ArrowUp,
  Award,
  Crown,
  Medal,
  Minus,
  RefreshCw,
  Sparkles,
  Trophy,
} from "lucide-react";
import { Avatar, EmptyState, ErrorNotice } from "../components/ui";
import { Countdown } from "../components/Countdown";
import { useAuth } from "../lib/auth";
import { useDaily } from "../hooks/useDaily";
import { api, errorMessage } from "../lib/api";
import {
  formatDailyLabel,
  formatDuration,
  formatNumber,
  GAME_META,
} from "../lib/format";
import type { GameKey, LeaderboardEntry, LeaderboardResponse } from "../lib/types";

type Period = "daily" | "weekly" | "all";

export default function LeaderboardsPage() {
  const { user } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const initialGame = searchParams.get("game") === "2048" ? "2048" : "memory";
  const initialPeriod: Period = searchParams.get("period") === "all" ? "all" : searchParams.get("period") === "weekly" ? "weekly" : "daily";
  const [game, setGame] = useState<GameKey>(initialGame);
  const [period, setPeriod] = useState<Period>(initialPeriod);
  const [data, setData] = useState<LeaderboardResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [version, setVersion] = useState(0);
  const { data: daily } = useDaily();

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError(null);
    api<LeaderboardResponse>(`/leaderboards?game=${game}&period=${period}&limit=50`)
      .then((response) => {
        if (active) setData(response);
      })
      .catch((err) => {
        if (active) setError(errorMessage(err));
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [game, period, version]);

  const updateFilters = (nextGame: GameKey, nextPeriod: Period) => {
    setGame(nextGame);
    setPeriod(nextPeriod);
    setSearchParams({ game: nextGame, period: nextPeriod });
  };

  const entries = data?.entries ?? [];
  const podium = entries.slice(0, 3);
  const rest = entries.slice(3);
  const meta = GAME_META[game];
  const dailyDateKey = period === "daily" ? (data?.dateKey ?? daily?.dateKey) : null;

  function Movement({ value }: { value?: number | null }) {
    if (value === null || value === undefined) return <Minus size={12} />;
    if (value > 0) return <span className="move-up"><ArrowUp size={12} /> {value}</span>;
    if (value < 0) return <span className="move-down"><ArrowDown size={12} /> {Math.abs(value)}</span>;
    return <Minus size={12} />;
  }

  return (
    <div className="page leaderboards-page">
      <header className="page-header leaderboard-header">
        <div>
          <p className="eyebrow"><Trophy size={14} aria-hidden="true" /> The podium</p>
          <h1>Real names. Real scores.</h1>
          <p className="page-subtitle">Every place here comes from a saved, authenticated run in SQLite.</p>
        </div>
        {period === "daily" && daily && (
          <div className="play-countdown glass">
            <span className="countdown-label"><Sparkles size={14} aria-hidden="true" /> Daily board closes in</span>
            <Countdown endsAt={daily.endsAt} />
            <small>{formatDailyLabel(daily.dateKey)} · Asia/Kolkata</small>
          </div>
        )}
      </header>

      <div className="leaderboard-filters glass">
        <div className="filter-group" role="group" aria-label="Game">
          {(["memory", "2048"] as GameKey[]).map((option) => (
            <button key={option} type="button" className={`filter-btn${game === option ? " is-active" : ""}`} onClick={() => updateFilters(option, period)} aria-pressed={game === option}>
              <span aria-hidden="true">{GAME_META[option].emoji}</span> {GAME_META[option].label}
            </button>
          ))}
        </div>
        <div className="filter-group" role="group" aria-label="Period">
          {(["daily", "weekly", "all"] as Period[]).map((option) => (
            <button key={option} type="button" className={`filter-btn${period === option ? " is-active" : ""}`} onClick={() => updateFilters(game, option)} aria-pressed={period === option}>
              {option === "all" ? "All-time" : option.charAt(0).toUpperCase() + option.slice(1)}
            </button>
          ))}
        </div>
        <button type="button" className="btn btn-ghost btn-small refresh-btn" onClick={() => setVersion((value) => value + 1)} disabled={loading}>
          <RefreshCw size={15} aria-hidden="true" /> Refresh
        </button>
      </div>

      <div className="leaderboard-meta">
        <span><strong>{meta.label}</strong> · {period === "daily" && dailyDateKey ? `${formatDailyLabel(dailyDateKey)} daily board` : period === "weekly" ? "This week" : "All-time best saved runs"}</span>
        <span>{period === "daily" ? "Fewest moves / highest score wins, then time." : "One best run per player."}</span>
      </div>

      {error && <ErrorNotice message={error} onRetry={() => setVersion((value) => value + 1)} />}

      {loading ? (
        <div className="leaderboard-loading"><div className="podium-skeleton" /><div className="list-skeleton" /></div>
      ) : entries.length === 0 ? (
        <div className="glass leaderboard-empty">
          <EmptyState emoji="🏅" title="No runs yet" description="Play a game and your name will appear here." action={<Link to={user ? "/play" : "/signup"} className="btn btn-primary">{user ? "Play" : "Create an account"}</Link>} />
        </div>
      ) : (
        <>
          <section className="podium" aria-label="Top three players">
            {podium.length > 1 && <PodiumCard entry={podium[1]} game={game} movement={<Movement value={podium[1].movement} />} />}
            {podium.length > 0 && <PodiumCard entry={podium[0]} game={game} movement={<Movement value={podium[0].movement} />} />}
            {podium.length > 2 && <PodiumCard entry={podium[2]} game={game} movement={<Movement value={podium[2].movement} />} />}
          </section>

          {data?.me && (
            <div className="your-rank glass">
              <span className="your-rank-label">Your place</span>
              <span className="your-rank-number">#{data.me.rank}</span>
              <Avatar avatar={data.me.avatar} size="sm" />
              <span className="your-rank-name">{data.me.displayName}</span>
              <span className="your-rank-metric">{game === "memory" ? `${data.me.moves} moves` : `${formatNumber(data.me.score)} pts`}</span>
              <span className="your-rank-time">{formatDuration(data.me.durationMs)}</span>
              {data.me.hasReplay && data.me.scoreId && <Link to={`/replay/${data.me.scoreId}`} className="text-link">Watch replay</Link>}
            </div>
          )}

          {rest.length > 0 && (
            <section className="rank-list glass" aria-label="Remaining leaderboard">
              <div className="rank-head" aria-hidden="true">
                <span>Rank</span>
                <span>Move</span>
                <span>Player</span>
                <span>Score</span>
                <span>Moves</span>
                <span>Time</span>
                <span>Replay</span>
              </div>
              {rest.map((entry) => (
                <div key={entry.username} className="rank-row">
                  <span className="rank-number">{entry.rank}</span>
                  <span><Movement value={entry.movement} /></span>
                  <span className="rank-player">
                    <Avatar avatar={entry.avatar} size="sm" />
                    <span><strong>{entry.displayName}</strong><small>@{entry.username} · Lv {entry.level}</small></span>
                  </span>
                  <span className="rank-score">{formatNumber(entry.score)}</span>
                  <span>{formatNumber(entry.moves)}</span>
                  <span>{formatDuration(entry.durationMs)}</span>
                  <span>{entry.hasReplay && entry.scoreId ? <Link to={`/replay/${entry.scoreId}`} className="text-link">Watch</Link> : "—"}</span>
                </div>
              ))}
            </section>
          )}
        </>
      )}
    </div>
  );
}

function PodiumCard({ entry, game, movement }: { entry: LeaderboardEntry; game: GameKey; movement: React.ReactNode }) {
  return (
    <article className={`podium-card podium-${entry.rank}`}>
      <span className="podium-rank" aria-label={`Rank ${entry.rank}`}>
        {entry.rank === 1 ? <Crown size={18} aria-hidden="true" /> : entry.rank === 2 ? <Medal size={18} aria-hidden="true" /> : entry.rank === 3 ? <Award size={18} aria-hidden="true" /> : entry.rank}
      </span>
      <Avatar avatar={entry.avatar} level={entry.level} size="lg" />
      <h3>{entry.displayName}</h3>
      <p className="podium-handle">@{entry.username}</p>
      <strong className="podium-metric">{game === "memory" ? `${entry.moves} moves` : `${formatNumber(entry.score)} pts`}</strong>
      <span className="podium-sub">{game === "memory" ? `${formatNumber(entry.score)} pts` : `${formatNumber(entry.moves)} moves`} · {formatDuration(entry.durationMs)}</span>
      <span className="podium-move">{movement}</span>
      {entry.hasReplay && entry.scoreId && <Link to={`/replay/${entry.scoreId}`} className="text-link">Watch replay</Link>}
    </article>
  );
}

