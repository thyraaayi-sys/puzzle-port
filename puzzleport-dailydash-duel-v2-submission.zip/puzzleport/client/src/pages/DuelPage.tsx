import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, RotateCcw, Trophy, Users } from "lucide-react";
import { PageHeader } from "../components/ui";
import { createMemoryDeck, type MemoryCard } from "../../../server/src/games/memory";
import { emptyBoard, createGame, applyMove, maxTile, type Board, type Direction } from "../../../server/src/games/game2048";

export default function DuelPage() {
  return (
    <div className="page duel-page">
      <PageHeader eyebrow="Local duel" title="Same device, two players" subtitle="Pass-and-play duels. No ranked leaderboard entries." />
      <div className="play-grid">
        <article className="play-card play-mint glass">
          <div className="play-card-body">
            <h2>Memory Duel</h2>
            <p>Two players, one shared deck, alternating turns.</p>
            <Link to="/duel/memory" className="btn btn-primary">Start Memory duel</Link>
          </div>
        </article>
        <article className="play-card play-sky glass">
          <div className="play-card-body">
            <h2>2048 Duel</h2>
            <p>Same starting board, separate scores, one winner.</p>
            <Link to="/duel/2048" className="btn btn-primary">Start 2048 duel</Link>
          </div>
        </article>
      </div>
      <Link to="/play" className="btn btn-ghost" style={{ marginTop: 20 }}><ArrowLeft size={16} /> Back to games</Link>
    </div>
  );
}

