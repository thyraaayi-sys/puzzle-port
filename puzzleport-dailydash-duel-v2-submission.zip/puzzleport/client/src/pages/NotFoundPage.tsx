import { Link } from "react-router-dom";
import { ArrowLeft, Compass } from "lucide-react";
import { Mascot } from "../components/ui";

export default function NotFoundPage() {
  return (
    <div className="page notfound-page">
      <div className="notfound-card glass">
        <Mascot size={118} className="notfound-mascot" />
        <p className="eyebrow">
          <Compass size={14} aria-hidden="true" /> Wrong dock
        </p>
        <h1>This puzzle piece doesn&apos;t fit.</h1>
        <p>
          The page you were looking for is not in this port. The daily games, leaderboards, and
          your profile are all a click away.
        </p>
        <div className="hero-actions">
          <Link to="/" className="btn btn-primary">
            <ArrowLeft size={16} aria-hidden="true" /> Back home
          </Link>
          <Link to="/play" className="btn btn-glass">
            Open the game room
          </Link>
        </div>
      </div>
    </div>
  );
}
