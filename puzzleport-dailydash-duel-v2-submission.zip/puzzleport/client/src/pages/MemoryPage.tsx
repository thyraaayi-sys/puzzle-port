import { useEffect, useRef, useState, type CSSProperties } from "react";
import { Link, useSearchParams } from "react-router-dom";
import {
  ArrowLeft,
  CheckCircle2,
  Clock3,
  Move,
  Play,
  RefreshCw,
  RotateCcw,
  Sparkles,
  Timer,
  Trophy,
} from "lucide-react";
import {
  createMemoryDeck,
  memoryScore,
  type MemoryCard,
} from "../../../server/src/games/memory";
import { ErrorNotice, Modal, PageHeader, Spinner } from "../components/ui";
import { Confetti } from "../lib/Confetti";
import { useAuth } from "../lib/auth";
import { useDaily } from "../hooks/useDaily";
import { useToast } from "../components/Toast";
import { usePreferences } from "../lib/preferences";
import { api, errorMessage } from "../lib/api";
import { playSound } from "../lib/audio";
import { formatDailyLabel, formatDuration, formatNumber } from "../lib/format";
import type { PlayMode, SaveScoreResponse, Session, SessionResponse } from "../lib/types";

type Phase = "setup" | "loading" | "playing" | "won";

export default function MemoryPage() {
  const { user, refresh } = useAuth();
  const toast = useToast();
  const preferences = usePreferences().preferences;
  const [searchParams] = useSearchParams();
  const initialVariant = searchParams.get("variant") ?? searchParams.get("mode") ?? "daily";
  const levelId = searchParams.get("level");
  const { data: daily, reload: reloadDaily } = useDaily();

  const [variant, setVariant] = useState(initialVariant);
  const [phase, setPhase] = useState<Phase>("setup");
  const [session, setSession] = useState<Session | null>(null);
  const [deck, setDeck] = useState<MemoryCard[]>([]);
  const [firstIndex, setFirstIndex] = useState<number | null>(null);
  const [moves, setMoves] = useState(0);
  const [matchedPairs, setMatchedPairs] = useState(0);
  const [locked, setLocked] = useState(false);
  const [startedAt, setStartedAt] = useState<number | null>(null);
  const [elapsed, setElapsed] = useState(0);
  const [announcement, setAnnouncement] = useState("Pick two cards to find a matching pair.");
  const [error, setError] = useState<string | null>(null);
  const [showWin, setShowWin] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [result, setResult] = useState<SaveScoreResponse | null>(null);
  const [confirmRestart, setConfirmRestart] = useState(false);
  const [confetti, setConfetti] = useState(false);
  const [actions, setActions] = useState<number[]>([]);
  const [mismatches, setMismatches] = useState(0);

  const busyRef = useRef(false);
  const timeoutRef = useRef<number | null>(null);
  const sawWinRef = useRef(false);

  const config = session?.config ?? {};
  const pairs = Number(config.pairs ?? 8);
  const rows = Number(config.rows ?? 4);
  const cols = Number(config.cols ?? 4);
  const symbols = (config.symbols as string[]) ?? [];
  const themeId = String(config.themeId ?? "animals");
  const moveLimit = Number(config.moveLimit ?? 0);
  const timeLimit = Number(config.timeLimitMs ?? 0);

  const dailyState = daily?.games.find((game) => game.game === "memory");

  useEffect(() => {
    return () => {
      if (timeoutRef.current !== null) window.clearTimeout(timeoutRef.current);
    };
  }, []);

  useEffect(() => {
    if (phase !== "playing" || startedAt === null) return;
    const tick = () => setElapsed(Date.now() - startedAt);
    tick();
    const interval = window.setInterval(tick, 250);
    return () => window.clearInterval(interval);
  }, [phase, startedAt]);

  const startGame = async (nextVariant: string = variant) => {
    setVariant(nextVariant);
    setPhase("loading");
    setError(null);
    setSaveError(null);
    setResult(null);
    setShowWin(false);
    setConfetti(false);
    setConfirmRestart(false);
    setAnnouncement("Shuffling the cards…");
    if (timeoutRef.current !== null) {
      window.clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    try {
      const response = await api<SessionResponse>("/sessions", {
        method: "POST",
        body: {
          game: "memory",
          variant: nextVariant,
          levelId: nextVariant === "campaign" ? levelId : undefined,
          themeId: nextVariant === "classic" ? undefined : undefined,
        },
      });
      busyRef.current = false;
      sawWinRef.current = false;
      setSession(response.session);
      const nextConfig = response.session.config;
      const nextPairs = Number(nextConfig.pairs ?? 8);
      const nextSymbols = (nextConfig.symbols as string[]) ?? symbols;
      setDeck(createMemoryDeck(response.session.seed, nextSymbols, nextPairs));
      setFirstIndex(null);
      setMoves(0);
      setMatchedPairs(0);
      setLocked(false);
      setElapsed(0);
      setStartedAt(Date.now());
      setActions([]);
      setMismatches(0);
      setPhase("playing");
      setAnnouncement("Card grid ready. Pick two cards to find a matching pair.");
      window.scrollTo({ top: 0, behavior: "auto" });
    } catch (err) {
      setError(errorMessage(err));
      setPhase("setup");
    }
  };

  const saveResult = async (finalMoves: number, finalElapsed: number, activeSession: Session) => {
    setSaving(true);
    setSaveError(null);
    try {
      const response = await api<SaveScoreResponse>("/scores", {
        method: "POST",
        body: {
          sessionId: activeSession.id,
          moves: finalMoves,
          actions,
          mismatches,
          perfect: mismatches === 0,
        },
      });
      setResult(response);
      reloadDaily();
      refresh().catch(() => undefined);
      if (response.achievements?.length) toast.reward("Achievement unlocked", response.achievements.join(", "));
      if (response.xpGain) playSound("reward", { soundEnabled: preferences.soundEnabled, sfxEnabled: preferences.sfxEnabled, volume: preferences.masterVolume });
    } catch (err) {
      setSaveError(errorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const handleFlip = (index: number) => {
    if (phase !== "playing" || busyRef.current) return;
    const clicked = deck[index];
    if (!clicked || clicked.matched || clicked.flipped) return;

    setActions((current) => [...current, index]);

    if (firstIndex === null) {
      const nextDeck = deck.map((card, cardIndex) =>
        cardIndex === index ? { ...card, flipped: true } : card,
      );
      setDeck(nextDeck);
      setFirstIndex(index);
      setAnnouncement(`Card ${index + 1} revealed: ${clicked.symbol}. Pick a second card.`);
      playSound("flip", { soundEnabled: preferences.soundEnabled, sfxEnabled: preferences.sfxEnabled, volume: preferences.masterVolume });
      return;
    }

    if (index === firstIndex) return;
    const firstCard = deck[firstIndex];
    if (!firstCard) return;

    const finalMoves = moves + 1;
    const revealedDeck = deck.map((card, cardIndex) =>
      cardIndex === index || cardIndex === firstIndex ? { ...card, flipped: true } : card,
    );

    if (firstCard.pairId === clicked.pairId) {
      const matchedDeck = revealedDeck.map((card, cardIndex) =>
        cardIndex === index || cardIndex === firstIndex ? { ...card, matched: true } : card,
      );
      setDeck(matchedDeck);
      setMoves(finalMoves);
      setFirstIndex(null);
      const newMatched = matchedPairs + 1;
      setMatchedPairs(newMatched);
      playSound("match", { soundEnabled: preferences.soundEnabled, sfxEnabled: preferences.sfxEnabled, volume: preferences.masterVolume });

      if (newMatched === pairs) {
        const finalElapsed = startedAt === null ? 0 : Date.now() - startedAt;
        setElapsed(finalElapsed);
        setPhase("won");
        setAnnouncement(`All pairs found in ${finalMoves} moves and ${formatDuration(finalElapsed)}.`);
        busyRef.current = true;
        if (!sawWinRef.current) {
          sawWinRef.current = true;
          setShowWin(true);
          setConfetti(true);
          playSound("victory", { soundEnabled: preferences.soundEnabled, sfxEnabled: preferences.sfxEnabled, volume: preferences.masterVolume });
          if (session) void saveResult(finalMoves, finalElapsed, session);
        }
      } else {
        setAnnouncement(`Match! ${clicked.symbol} pair found. ${pairs - newMatched} pairs left.`);
      }
      return;
    }

    busyRef.current = true;
    setDeck(revealedDeck);
    setMoves(finalMoves);
    setLocked(true);
    setMismatches((value) => value + 1);
    setAnnouncement(`Not a match; both cards will turn back over.`);
    playSound("mismatch", { soundEnabled: preferences.soundEnabled, sfxEnabled: preferences.sfxEnabled, volume: preferences.masterVolume });

    timeoutRef.current = window.setTimeout(() => {
      setDeck((current) =>
        current.map((card, cardIndex) =>
          cardIndex === index || cardIndex === firstIndex ? { ...card, flipped: false } : card,
        ),
      );
      setFirstIndex(null);
      setLocked(false);
      busyRef.current = false;
      timeoutRef.current = null;
      setAnnouncement("Cards turned back. Try another pair.");
    }, 950);
  };

  const resetToSetup = () => {
    setPhase("setup");
    setShowWin(false);
    setConfetti(false);
    setSession(null);
    setDeck([]);
    setFirstIndex(null);
    setMoves(0);
    setMatchedPairs(0);
    setLocked(false);
    setStartedAt(null);
    setElapsed(0);
    setResult(null);
    setSaveError(null);
    busyRef.current = false;
    setActions([]);
    setMismatches(0);
  };

  const currentScore = result?.score.score ?? memoryScore(moves, elapsed, pairs);
  const modeLabel = variant === "daily" ? "Daily challenge" : variant === "campaign" ? "Campaign level" : "Practice run";

  return (
    <div className="page memory-page">
      <Confetti active={confetti} />
      <PageHeader
        eyebrow="Memory Match"
        title={phase === "setup" ? "Find every pair." : modeLabel}
        subtitle={
          phase === "setup"
            ? "Choose a mode and start matching."
            : daily && variant === "daily"
              ? `Shared daily seed for ${formatDailyLabel(daily.dateKey)} · Asia/Kolkata`
              : variant === "campaign"
                ? `Campaign level ${levelId}`
                : "Practice seed · counts toward your personal bests"
        }
        actions={
          phase !== "setup" ? (
            <button type="button" className="btn btn-ghost btn-small" onClick={() => setConfirmRestart(true)}>
              <RotateCcw size={16} aria-hidden="true" /> Restart
            </button>
          ) : (
            <Link to="/play" className="btn btn-ghost btn-small">
              <ArrowLeft size={16} aria-hidden="true" /> Game room
            </Link>
          )
        }
      />

      {error && <ErrorNotice message={error} onRetry={() => startGame(variant)} />}

      {phase === "setup" && (
        <section className="memory-setup glass">
          <div className="memory-setup-copy">
            <p className="eyebrow">
              <Sparkles size={14} aria-hidden="true" /> Choose a mode
            </p>
            <h2>Today's deck, or a fresh shuffle?</h2>
            <div className="mode-toggle" role="group" aria-label="Game mode">
              {[
                ["daily", "Daily", "The shared seed of the day"],
                ["classic", "Classic", "A fresh, easygoing shuffle"],
                ["practice", "Practice", "No clock, no pressure"],
                ["timed", "Timed", "Find every pair in 120s"],
                ["moves", "Move limit", "Just 30 moves to work with"],
                ["perfect", "Perfect", "Zero mismatches allowed"],
                ["campaign", "Campaign", "Follow the tiny level map"],
              ].map(([value, label, description]) => (
                <button
                  key={value}
                  type="button"
                  className={`mode-option${variant === value ? " is-selected" : ""}`}
                  onClick={() => setVariant(value)}
                  aria-pressed={variant === value}
                >
                  <strong>{label}</strong>
                  <span>{description}</span>
                </button>
              ))}
            </div>
            <div className="setup-actions" style={{ marginTop: 16 }}>
              <button type="button" className="btn btn-primary btn-large" onClick={() => startGame(variant)}>
                <Play size={18} aria-hidden="true" /> Start
              </button>
            </div>
          </div>
          <div className="memory-setup-art" aria-hidden="true">
            <div className="memory-demo-grid">
              <span className="memory-demo-card is-up">🍓</span>
              <span className="memory-demo-card">✦</span>
              <span className="memory-demo-card is-up">🍓</span>
              <span className="memory-demo-card">✦</span>
              <span className="memory-demo-card">✦</span>
              <span className="memory-demo-card is-up">🌷</span>
              <span className="memory-demo-card">✦</span>
              <span className="memory-demo-card is-up">🌷</span>
            </div>
            <span className="setup-float setup-float-a">3D flips</span>
            <span className="setup-float setup-float-b">8 sweet pairs</span>
          </div>
        </section>
      )}

      {phase === "loading" && (
        <div className="game-loading glass">
          <Spinner label="Dealing the cards" />
          <p>Shuffling your deck…</p>
        </div>
      )}

      {(phase === "playing" || phase === "won") && (
        <section className="memory-game" aria-label="Memory Match game">
          <div className="game-hud glass">
            <div className="hud-mode">
              <span className={`mode-chip ${variant === "daily" ? "is-daily" : ""}`}>{variant}</span>
              <div>
                <span>Pairs found</span>
                <strong>{matchedPairs}/{pairs}</strong>
              </div>
            </div>
            <div className="hud-stats">
              <div>
                <span><Move size={14} aria-hidden="true" /> Moves</span>
                <strong>{moves}{moveLimit ? `/${moveLimit}` : ""}</strong>
              </div>
              <div>
                <span><Clock3 size={14} aria-hidden="true" /> Time</span>
                <strong>{formatDuration(elapsed)}{timeLimit ? `/${formatDuration(timeLimit)}` : ""}</strong>
              </div>
              <div>
                <span><Sparkles size={14} aria-hidden="true" /> Points</span>
                <strong>{formatNumber(currentScore)}</strong>
              </div>
            </div>
          </div>

          <p className={`game-status${locked ? " is-locked" : ""}`} aria-live="polite">
            {announcement}
          </p>

          <div className={`memory-grid${locked ? " is-locked" : ""}`} style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))` }}>
            {deck.map((card, index) => {
              const revealed = card.flipped || card.matched;
              return (
                <button
                  key={card.id}
                  type="button"
                  className={`memory-card${revealed ? " is-flipped" : ""}${card.matched ? " is-matched" : ""}`}
                  onClick={() => handleFlip(index)}
                  aria-label={revealed ? `${card.symbol} card${card.matched ? ", matched" : ", face up"}` : `Hidden card ${index + 1}`}
                  aria-pressed={revealed}
                  disabled={phase === "won" || card.matched}
                >
                  <span className="memory-card-inner">
                    <span className="memory-face memory-back" aria-hidden="true">
                      <span className="card-spark">✦</span>
                    </span>
                    <span className="memory-face memory-front" aria-hidden="true">
                      <span className="card-symbol">{card.symbol}</span>
                    </span>
                  </span>
                </button>
              );
            })}
          </div>

          <div className="game-footnote">
            <span>Keyboard: Tab between cards, Enter or Space to flip.</span>
            {locked && <span className="peek-note">Waiting for the mismatch to resolve…</span>}
          </div>
        </section>
      )}

      <Modal
        open={showWin && phase === "won"}
        title="Every pair found!"
        onClose={() => setShowWin(false)}
        footer={
          <>
            <button type="button" className="btn btn-primary" onClick={() => startGame(variant)}>
              <RotateCcw size={16} aria-hidden="true" /> Play again
            </button>
            {result?.replayId && (
              <Link to={`/replay/${result.replayId}`} className="btn btn-ghost">
                <Play size={16} aria-hidden="true" /> Watch replay
              </Link>
            )}
            <Link to="/leaderboards?game=memory&period=daily" className="btn btn-ghost">
              <Trophy size={16} aria-hidden="true" /> Leaderboard
            </Link>
          </>
        }
      >
        <div className="result-hero" aria-hidden="true">🎉</div>
        <p className="result-lede">
          {saving ? "Saving your run to SQLite…" : result ? "Saved. Your name is on the board if this is your best today." : saveError ? "Your result is not saved yet." : "A clean sweep."}
        </p>
        <div className="result-stats">
          <div><span>Moves</span><strong>{moves}</strong></div>
          <div><span>Time</span><strong>{formatDuration(elapsed)}</strong></div>
          <div><span>Points</span><strong>{formatNumber(currentScore)}</strong></div>
          <div><span>Stars</span><strong>{result?.stars ?? 0}/3</strong></div>
        </div>
        {result && (
          <p className="save-state is-success">
            <CheckCircle2 size={16} aria-hidden="true" /> +{result.xpGain} XP · +{result.coinGain ?? 0} coins · Level {result.user.level}
            {result.achievements?.length ? ` · ${result.achievements.join(", ")}` : ""}
          </p>
        )}
        {saveError && <div className="form-alert" role="alert">{saveError}</div>}
      </Modal>

      <Modal
        open={confirmRestart}
        title="Start a fresh deck?"
        onClose={() => setConfirmRestart(false)}
        size="sm"
        footer={
          <>
            <button type="button" className="btn btn-ghost" onClick={() => setConfirmRestart(false)}>Keep playing</button>
            <button type="button" className="btn btn-primary" onClick={() => startGame(variant)}>Restart</button>
          </>
        }
      >
        <p>Your current run will be abandoned and will not be saved. This cannot be undone.</p>
      </Modal>
    </div>
  );
}

