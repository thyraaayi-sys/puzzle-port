import { useState } from "react";
import { Link } from "react-router-dom";
import { Gamepad2, Lock, Star, Trophy } from "lucide-react";
import { PageHeader, LoadingBlock, EmptyState } from "../components/ui";
import { useAuth } from "../lib/auth";
import { useToast } from "../components/Toast";
import { api, errorMessage } from "../lib/api";
import type { ProgressionResponse } from "../lib/types";

export default function CampaignPage() {
  const { user } = useAuth();
  const toast = useToast();
  const [game, setGame] = useState<"memory" | "2048">("memory");
  const [data, setData] = useState<ProgressionResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      setData(await api<ProgressionResponse>("/progression"));
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="page"><LoadingBlock label="Loading campaign…" /></div>;
  if (error || !data) return <div className="page"><PageHeader title="Campaign" subtitle={error ?? "Unavailable"} /></div>;

  const levels = game === "memory" ? data.campaign.memory : data.campaign["2048"];

  return (
    <div className="page campaign-page">
      <PageHeader eyebrow="Campaign" title="Level maps" subtitle="Unlock worlds, earn stars, and claim rewards." />

      <div className="tabs" role="tablist" aria-label="Campaign game">
        <button type="button" className={`tab-btn${game === "memory" ? " is-active" : ""}`} onClick={() => setGame("memory")}>Memory Match</button>
        <button type="button" className={`tab-btn${game === "2048" ? " is-active" : ""}`} onClick={() => setGame("2048")}>2048</button>
      </div>

      <div className="campaign-worlds">
        {Array.from(new Set(levels.map((level) => level.world))).map((world) => {
          const worldLevels = levels.filter((level) => level.world === world);
          return (
            <section key={world} className="glass campaign-world">
              <div className="panel-head">
                <div>
                  <p className="eyebrow">World {world}</p>
                  <h2>{worldLevels[0]?.worldName}</h2>
                </div>
                <Trophy size={18} aria-hidden="true" />
              </div>
              <div className="campaign-grid">
                {worldLevels.map((level) => {
                  const stars = level.progress?.bestStars ?? 0;
                  return (
                    <article key={level.id} className={`campaign-level${level.unlocked ? "" : " is-locked"}${stars > 0 ? " is-complete" : ""}`}>
                      <div className="campaign-level-top">
                        <span className="campaign-level-number">{level.levelNumber}</span>
                        {level.unlocked ? <Star size={14} aria-hidden="true" /> : <Lock size={14} aria-hidden="true" />}
                      </div>
                      <h3>{level.name}</h3>
                      <p>{level.game === "memory" ? `${(level.config as { pairs: number }).pairs} pairs` : `Target ${(level.config as { targetTile: number }).targetTile}`}</p>
                      <div className="star-row" aria-label={`${stars} of 3 stars`}>
                        {[1, 2, 3].map((star) => (
                          <span key={star} className={star <= stars ? "star is-on" : "star"}>★</span>
                        ))}
                      </div>
                      {level.unlocked && user ? (
                        <Link
                          to={`/play/${level.game === "memory" ? "memory" : "2048"}?mode=campaign&level=${level.id}`}
                          className="btn btn-primary btn-small"
                        >
                          <Gamepad2 size={14} /> Play
                        </Link>
                      ) : (
                        <span className="status-pill">Locked</span>
                      )}
                    </article>
                  );
                })}
              </div>
            </section>
          );
        })}
      </div>

      {!user && <EmptyState title="Sign in to play" description="Campaign progress is saved to your account." />}
    </div>
  );
}

