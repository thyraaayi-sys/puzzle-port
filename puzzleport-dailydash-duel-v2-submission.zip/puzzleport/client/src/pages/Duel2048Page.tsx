import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, RotateCcw, Trophy } from "lucide-react";
import { PageHeader } from "../components/ui";
import { emptyBoard, createGame, applyMove, maxTile, type Board, type Direction } from "../../../server/src/games/game2048";

const TURN_SECONDS = 45;

export default function Duel2048Page() {
  const [seed] = useState(() => crypto.randomUUID());
  const [phase, setPhase] = useState<"p1" | "p2" | "done">("p1");
  const [board, setBoard] = useState<Board>(() => createGame(crypto.randomUUID()).board);
  const [score, setScore] = useState(0);
  const [moves, setMoves] = useState(0);
  const [timeLeft, setTimeLeft] = useState(TURN_SECONDS);
  const [scores, setScores] = useState<[number, number]>([0, 0]);
  const [moveCounts, setMoveCounts] = useState<[number, number]>([0, 0]);
  const rngRef = useRef(createGame(seed).rng);
  const gameRef = useRef({ board: emptyBoard(), score: 0, moves: 0 });
  const startedRef = useRef(Date.now());

  const startTurn = (player: 1 | 2) => {
    const initial = createGame(seed);
    rngRef.current = initial.rng;
    gameRef.current = { board: initial.board, score: 0, moves: 0 };
    setBoard(initial.board);
    setScore(0);
    setMoves(0);
    setTimeLeft(TURN_SECONDS);
    startedRef.current = Date.now();
    setPhase(player === 1 ? "p1" : "p2");
  };

  useEffect(() => {
    startTurn(1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (phase === "done") return;
    const interval = window.setInterval(() => {
      setTimeLeft((value) => {
        if (value <= 1) {
          window.clearInterval(interval);
          const player = phase === "p1" ? 1 : 2;
          setScores((current) => {
            const next: [number, number] = [...current];
            next[player - 1] = Math.max(next[player - 1], gameRef.current.score);
            return next;
          });
          setMoveCounts((current) => {
            const next: [number, number] = [...current];
            next[player - 1] = gameRef.current.moves;
            return next;
          });
          if (phase === "p1") startTurn(2);
          else setPhase("done");
          return 0;
        }
        return value - 1;
      });
    }, 1000);
    return () => window.clearInterval(interval);
  }, [phase]);

  useEffect(() => {
    const handleKey = (event: KeyboardEvent) => {
      if (phase === "done") return;
      const key = event.key.toLowerCase();
      const direction: Direction | null =
        key === "arrowleft" || key === "a" ? "left" :
        key === "arrowright" || key === "d" ? "right" :
        key === "arrowup" || key === "w" ? "up" :
        key === "arrowdown" || key === "s" ? "down" : null;
      if (!direction) return;
      event.preventDefault();
      const outcome = applyMove(gameRef.current.board, direction, rngRef.current);
      if (!outcome.moved) return;
      gameRef.current.board = outcome.board;
      gameRef.current.score += outcome.gained;
      gameRef.current.moves += 1;
      setBoard(outcome.board);
      setScore(gameRef.current.score);
      setMoves(gameRef.current.moves);
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [phase]);

  const winner = scores[0] === scores[1] ? (moveCounts[0] <= moveCounts[1] ? 1 : 2) : scores[0] > scores[1] ? 1 : 2;

  return (
    <div className="page duel-2048-page">
      <PageHeader eyebrow="Local duel" title="2048 duel" subtitle="Each player gets 45 seconds on the same starting board." />
      <div className="duel-scoreboard glass">
        <div className={`duel-player${phase === "p1" ? " is-active" : ""}`}>
          <strong>Player 1</strong>
          <span>{scores[0]} pts · {moveCounts[0]} moves</span>
        </div>
        <div className="duel-divider">VS</div>
        <div className={`duel-player${phase === "p2" ? " is-active" : ""}`}>
          <strong>Player 2</strong>
          <span>{scores[1]} pts · {moveCounts[1]} moves</span>
        </div>
      </div>
      <p className="duel-turn">{phase === "done" ? "Match complete" : `Player ${phase === "p1" ? 1 : 2} playing · ${timeLeft}s left`}</p>
      {phase !== "done" && (
        <>
          <div className="board-2048">
            {board.map((row, rowIndex) => row.map((value, colIndex) => (
              <div key={`${rowIndex}-${colIndex}`} className={`tile tile-${value === 0 ? "empty" : value}`}>{value === 0 ? "" : value}</div>
            )))}
          </div>
          <p className="board-hint">Score: {score} · Moves: {moves} · Max tile {maxTile(board)}</p>
        </>
      )}
      {phase === "done" && (
        <div className="glass duel-result">
          <Trophy size={24} aria-hidden="true" />
          <h2>Player {winner} wins!</h2>
          <p>{scores[0]} to {scores[1]}</p>
          <button type="button" className="btn btn-primary" onClick={() => startTurn(1)}><RotateCcw size={16} /> Rematch</button>
        </div>
      )}
      <div className="page-actions" style={{ marginTop: 20 }}>
        <Link to="/duel" className="btn btn-ghost"><ArrowLeft size={16} /> Back</Link>
      </div>
    </div>
  );
}

