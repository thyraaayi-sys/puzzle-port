import { useEffect, useState, type CSSProperties } from "react";
import { Link } from "react-router-dom";
import {
  ArrowRight,
  CheckCircle2,
  ChevronRight,
  Crown,
  Flame,
  Gamepad2,
  Keyboard,
  Medal,
  ShieldCheck,
  Sparkles,
  Trophy,
  Zap,
} from "lucide-react";
import { Countdown } from "../components/Countdown";
import { Avatar, EmptyState, Mascot, StatTile, XPBar } from "../components/ui";
import { useAuth } from "../lib/auth";
import { useDaily } from "../hooks/useDaily";
import { api, errorMessage } from "../lib/api";
import {
  formatDailyLabel,
  formatDuration,
  formatNumber,
  GAME_META,
  levelInfo,
  metricFor,
} from "../lib/format";
import type {
  DailyGame,
  GameKey,
  LeaderboardResponse,
  ProgressionResponse,
  StatsResponse,
  User,
} from "../lib/types";

const mini2048 = [2, 4, 0, 2, 8, 16, 4, 0, 0, 8, 32, 2, 0, 0, 4, 8];

function greetingForIst(): string {
  const hour = Number(
    new Intl.DateTimeFormat("en-GB", {
      hour: "2-digit",
      hour12: false,
      timeZone: "Asia/Kolkata",
    }).format(new Date()),
  );
  if (hour < 12) return "Good morning";
  if (hour < 17) return "Good afternoon";
  return "Good evening";
}

function gamePath(game: GameKey, mode: "daily" | "classic") {
  return `/play/${game === "memory" ? "memory" : "2048"}?mode=${mode}`;
}

function signupPath(target: string) {
  return `/login?next=${encodeURIComponent(target)}`;
}

function DailyChallengeCard({ data, user }: { data: DailyGame; user: User | null }) {
  const meta = GAME_META[data.game];
  const target = gamePath(data.game, "daily");
  const href = user ? target : signupPath(target);

  return (
    <article className={`daily-card daily-${meta.accent} glass`}>
      <div className="daily-card-top">
        <div className="daily-icon" aria-hidden="true">
          {meta.emoji}
        </div>
        <div>
          <p className="daily-kicker">{meta.label}</p>
          <h3>{data.completed ? "Daily complete" : "Today's daily"}</h3>
        </div>
        <span className={`status-pill ${data.completed ? "is-done" : ""}`}>
          {data.completed ? (
            <>
              <CheckCircle2 size={14} aria-hidden="true" /> Done
            </>
          ) : (
            <>
              <Flame size={14} aria-hidden="true" /> Ready
            </>
          )}
        </span>
      </div>

      <p className="daily-tagline">{meta.tagline}</p>

      <div className="daily-meta-grid">
        <div>
          <span>Layout</span>
          <strong>{data.game === "memory" ? "4×4 · 8 pairs" : "4×4 · seeded"}</strong>
        </div>
        <div>
          <span>Personal best</span>
          <strong>
            {data.best
              ? data.game === "memory"
                ? `${data.best.moves} moves`
                : `${formatNumber(data.best.score)} pts`
              : "No run yet"}
          </strong>
        </div>
      </div>

      <div className="daily-card-footer">
        <span className="daily-date">
          {formatDailyLabel(data.dateKey)} · {data.completed ? "plays still count for your best" : "same seed for everyone"}
        </span>
        <Link to={href} className="btn btn-primary btn-small">
          {user ? (data.completed ? "Improve score" : "Play daily") : "Sign in to play"}
          <ArrowRight size={15} aria-hidden="true" />
        </Link>
      </div>
    </article>
  );
}

function MiniBoard({
  game,
  response,
  loading,
}: {
  game: GameKey;
  response: LeaderboardResponse | null;
  loading: boolean;
}) {
  const meta = GAME_META[game];
  return (
    <div className="mini-board glass">
      <div className="mini-board-head">
        <div>
          <p className="eyebrow">Today&apos;s podium</p>
          <h3>{meta.label}</h3>
        </div>
        <Link to={`/leaderboards?game=${game}&period=daily`} className="text-link">
          Full board <ChevronRight size={14} aria-hidden="true" />
        </Link>
      </div>
      {loading ? (
        <div className="mini-board-skeleton" aria-label="Loading leaderboard">
          <span />
          <span />
          <span />
        </div>
      ) : response && response.entries.length > 0 ? (
        <ol className="mini-ranks">
          {response.entries.slice(0, 3).map((entry) => (
            <li key={entry.username}>
              <span className={`mini-rank rank-${entry.rank}`}>
                {entry.rank === 1 ? <Crown size={15} aria-hidden="true" /> : entry.rank}
              </span>
              <Avatar avatar={entry.avatar} size="sm" />
              <span className="mini-player">
                <strong>{entry.displayName}</strong>
                <small>
                  {metricFor(game, entry)} · {formatDuration(entry.durationMs)}
                </small>
              </span>
            </li>
          ))}
        </ol>
      ) : (
        <EmptyState
          emoji="🏅"
          title="The podium is waiting"
          description="No validated daily runs yet. Be the first real name on the board."
          action={
            <Link to="/play" className="btn btn-ghost btn-small">
              Play a game
            </Link>
          }
        />
      )}
    </div>
  );
}

function GuestHero() {
  return (
    <section className="guest-hero">
      <div className="guest-hero-copy">
        <p className="eyebrow">
          <Sparkles size={14} aria-hidden="true" /> A cozy daily puzzle parlour
        </p>
        <h1>
          Two tiny games.
          <br />
          <span className="gradient-text">One fresh daily duel.</span>
        </h1>
        <p className="hero-lede">
          A shared Memory Match deck and a seeded 2048 board, refreshed at midnight in India.
          Play for the joy of it, then leave your name on a leaderboard made of real runs.
        </p>
        <div className="hero-actions">
          <Link to="/signup" className="btn btn-primary btn-large">
            Start playing free <ArrowRight size={18} aria-hidden="true" />
          </Link>
          <Link to="/leaderboards" className="btn btn-glass btn-large">
            <Trophy size={17} aria-hidden="true" /> See the leaderboard
          </Link>
        </div>
        <div className="hero-trust">
          <span>
            <ShieldCheck size={15} aria-hidden="true" /> Passwords hashed
          </span>
          <span>
            <Zap size={15} aria-hidden="true" /> Instant play
          </span>
          <span>
            <Keyboard size={15} aria-hidden="true" /> Keyboard friendly
          </span>
        </div>
      </div>

      <div className="hero-collage" aria-hidden="true">
        <div className="collage-memory">
          <div className="collage-memory-head">
            <span>Memory Match</span>
            <span className="mini-pill">Daily</span>
          </div>
          <div className="collage-memory-grid">
            <span className="collage-mcard is-up">🍓</span>
            <span className="collage-mcard">✦</span>
            <span className="collage-mcard is-up">🍓</span>
            <span className="collage-mcard">✦</span>
            <span className="collage-mcard">✦</span>
            <span className="collage-mcard is-up">🌷</span>
            <span className="collage-mcard">✦</span>
            <span className="collage-mcard is-up">🌷</span>
          </div>
        </div>
        <div className="collage-2048">
          <div className="collage-2048-head">
            <span>2048</span>
            <span className="mini-score">1,280</span>
          </div>
          <div className="mini-2048-grid">
            {mini2048.map((value, index) => (
              <span key={index} className={`mini-tile tile-${value}`}>
                {value || ""}
              </span>
            ))}
          </div>
        </div>
        <div className="float-chip float-chip-one">
          <Flame size={15} aria-hidden="true" /> New seed at midnight IST
        </div>
        <div className="float-chip float-chip-two">
          <Medal size={15} aria-hidden="true" /> Real scores only
        </div>
        <div className="hero-mascot">
          <Mascot size={74} />
          <span>
            <strong>Pip&apos;s tiny tip</strong>
            Start with the daily — it fits in one coffee break.
          </span>
        </div>
      </div>
    </section>
  );
}

function PlayerHero({ user, dailyDone }: { user: User; dailyDone: number }) {
  const firstName = user.displayName.split(" ")[0];
  const info = levelInfo(user.xp);
  return (
    <section className="dashboard-hero glass">
      <div className="dashboard-avatar">
        <Avatar avatar={user.avatar} level={user.level} size="xl" />
        <span className="dashboard-pip" aria-hidden="true">
          <Mascot size={46} />
        </span>
      </div>
      <div className="dashboard-copy">
        <p className="eyebrow">{greetingForIst()}, {firstName}</p>
        <h1>Your daily dash is ready.</h1>
        <p className="hero-lede">
          {dailyDone === 2
            ? "Both of today's challenges are complete. Improve a score or browse the podium."
            : dailyDone === 1
              ? "One daily challenge down, one still waiting. Nice momentum."
              : "Two fresh puzzles, one shared seed, and a leaderboard waiting for your name."}
        </p>
        <XPBar xp={user.xp} showLabel />
        <p className="xp-footnote">
          {formatNumber(user.xp)} XP total · {info.remaining} XP to level {info.level + 1}
        </p>
      </div>
      <div className="dashboard-side">
        <div className="daily-progress">
          <span className="progress-ring" style={{ "--progress": `${(dailyDone / 2) * 360}deg` } as CSSProperties}>
            <strong>
              {dailyDone}
              <small>/2</small>
            </strong>
          </span>
          <div>
            <span className="daily-progress-label">Daily challenges</span>
            <strong>{dailyDone === 2 ? "All done" : "In progress"}</strong>
          </div>
        </div>
        <Link to="/play" className="btn btn-primary btn-wide">
          <Gamepad2 size={17} aria-hidden="true" /> Open the game room
        </Link>
        <Link to="/profile" className="btn btn-ghost btn-wide">
          View profile <ChevronRight size={16} aria-hidden="true" />
        </Link>
      </div>
    </section>
  );
}

export default function HomePage() {
  const { user } = useAuth();
  const { data: daily, loading: dailyLoading, error: dailyError, reload } = useDaily();
  const [stats, setStats] = useState<StatsResponse | null>(null);
  const [statsLoading, setStatsLoading] = useState(false);
  const [boards, setBoards] = useState<Partial<Record<GameKey, LeaderboardResponse>>>({});
  const [boardsLoading, setBoardsLoading] = useState(true);
  const [boardsError, setBoardsError] = useState<string | null>(null);
  const [progression, setProgression] = useState<ProgressionResponse | null>(null);

  useEffect(() => {
    if (!user) {
      setStats(null);
      return;
    }
    let active = true;
    setStatsLoading(true);
    api<StatsResponse>("/stats/me")
      .then((response) => {
        if (active) setStats(response);
      })
      .catch(() => {
        if (active) setStats(null);
      })
      .finally(() => {
        if (active) setStatsLoading(false);
      });
    return () => {
      active = false;
    };
  }, [user?.id]);

  useEffect(() => {
    let active = true;
    setBoardsLoading(true);
    setBoardsError(null);
    Promise.all([
      api<LeaderboardResponse>("/leaderboards?game=memory&period=daily&limit=3"),
      api<LeaderboardResponse>("/leaderboards?game=2048&period=daily&limit=3"),
    ])
      .then(([memory, game2048]) => {
        if (active) setBoards({ memory, "2048": game2048 });
      })
      .catch((error) => {
        if (active) setBoardsError(errorMessage(error));
      })
      .finally(() => {
        if (active) setBoardsLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (!user) {
      setProgression(null);
      return;
    }
    let active = true;
    api<ProgressionResponse>("/progression")
      .then((response) => {
        if (active) setProgression(response);
      })
      .catch(() => {
        if (active) setProgression(null);
      });
    return () => {
      active = false;
    };
  }, [user?.id]);

  const dailyGames = daily?.games ?? [];
  const dailyDone = dailyGames.filter((game) => game.completed).length;
  const memoryBest = stats?.best.memory;
  const game2048Best = stats?.best["2048"];

  return (
    <div className="page home-page">
      {user ? <PlayerHero user={user} dailyDone={dailyDone} /> : <GuestHero />}

      {progression?.seasonalEvents.filter((event) => event.active).map((event) => (
        <section key={event.id} className="glass seasonal-banner">
          <span className="seasonal-emoji" aria-hidden="true">{event.emoji}</span>
          <div>
            <p className="eyebrow">Seasonal event</p>
            <h2>{event.name}</h2>
            <p>{event.banner}</p>
          </div>
          <Link to="/collection" className="btn btn-primary btn-small">View cosmetics</Link>
        </section>
      ))}

      <section className="daily-section" id="daily" aria-labelledby="daily-heading">
        <div className="section-heading">
          <div>
            <p className="eyebrow">
              <Flame size={14} aria-hidden="true" /> Daily ritual
            </p>
            <h2 id="daily-heading">Today&apos;s challenges</h2>
            <p>
              {daily ? formatDailyLabel(daily.dateKey) : "Loading today's date"} · a fresh seed at
              midnight Asia/Kolkata.
            </p>
          </div>
          {daily && <Countdown endsAt={daily.endsAt} onExpire={reload} className="countdown-pill" />}
        </div>

        {dailyLoading ? (
          <div className="daily-grid">
            <div className="daily-card skeleton-card" />
            <div className="daily-card skeleton-card" />
          </div>
        ) : dailyError ? (
          <div className="form-alert" role="alert">
            {dailyError}{" "}
            <button type="button" className="text-link" onClick={reload}>
              Retry
            </button>
          </div>
        ) : (
          <div className="daily-grid">
            {dailyGames.map((game) => (
              <DailyChallengeCard key={game.game} data={game} user={user} />
            ))}
          </div>
        )}
      </section>

      {user && (
        <section className="stats-section" aria-labelledby="stats-heading">
          <div className="section-heading compact">
            <div>
              <p className="eyebrow">Your little trophy shelf</p>
              <h2 id="stats-heading">At a glance</h2>
            </div>
            <Link to="/profile" className="text-link">
              Full profile <ChevronRight size={14} aria-hidden="true" />
            </Link>
          </div>
          {statsLoading ? (
            <div className="stats-grid">
              <div className="stat-tile skeleton-card" />
              <div className="stat-tile skeleton-card" />
              <div className="stat-tile skeleton-card" />
              <div className="stat-tile skeleton-card" />
            </div>
          ) : (
            <div className="stats-grid">
              <StatTile
                emoji="🎮"
                label="Games completed"
                value={formatNumber(stats?.totals.games ?? 0)}
                hint="Every one saved in SQLite"
              />
              <StatTile
                emoji="🃏"
                label="Memory best"
                value={memoryBest?.bestMoves != null ? `${memoryBest.bestMoves} moves` : "—"}
                hint={
                  memoryBest?.bestTimeMs != null
                    ? `${formatDuration(memoryBest.bestTimeMs)} best time`
                    : "Play a daily to set it"
                }
              />
              <StatTile
                emoji="🔢"
                label="2048 best"
                value={game2048Best?.bestScore != null ? formatNumber(game2048Best.bestScore) : "—"}
                hint={
                  game2048Best?.bestMoves != null
                    ? `${formatNumber(game2048Best.bestMoves)} fewest moves`
                    : "Merge your first board"
                }
              />
              <StatTile
                emoji="✨"
                label="Level"
                value={`Lv ${user.level}`}
                hint={`${formatNumber(user.xp)} XP total`}
              />
            </div>
          )}
        </section>
      )}

      {progression && (
        <section className="quest-preview glass" aria-labelledby="quests-preview">
          <div className="section-heading compact">
            <div>
              <p className="eyebrow">Quests</p>
              <h2 id="quests-preview">Today's quests</h2>
            </div>
            <Link to="/achievements" className="text-link">All quests <ChevronRight size={14} aria-hidden="true" /></Link>
          </div>
          <div className="grid-auto">
            {progression.quests.daily.map((quest) => (
              <article key={quest.slug} className="quest-card glass">
                <span className="quest-emoji" aria-hidden="true">{quest.emoji}</span>
                <div className="quest-copy">
                  <h3>{quest.title}</h3>
                  <div className="xp-track" style={{ marginTop: 6 }}>
                    <div className="xp-fill" style={{ width: `${Math.min(100, (quest.progress / quest.target) * 100)}%` }} />
                  </div>
                  <small>{quest.progress}/{quest.target}</small>
                </div>
              </article>
            ))}
          </div>
        </section>
      )}

      <section className="home-split" aria-labelledby="podium-heading">
        <div className="section-heading compact span-all">
          <div>
            <p className="eyebrow">
              <Trophy size={14} aria-hidden="true" /> Real players only
            </p>
            <h2 id="podium-heading">Today&apos;s podiums</h2>
          </div>
          <Link to="/leaderboards" className="text-link">
            All leaderboards <ChevronRight size={14} aria-hidden="true" />
          </Link>
        </div>
        {boardsError && (
          <div className="form-alert span-all" role="alert">
            {boardsError}
          </div>
        )}
        <MiniBoard game="memory" response={boards.memory ?? null} loading={boardsLoading} />
        <MiniBoard game="2048" response={boards["2048"] ?? null} loading={boardsLoading} />
      </section>

      {!user && (
        <section className="feature-section" aria-labelledby="features-heading">
          <div className="section-heading">
            <div>
              <p className="eyebrow">Why it feels different</p>
              <h2 id="features-heading">A tiny port with real substance</h2>
            </div>
          </div>
          <div className="feature-grid">
            <article className="feature-card glass">
              <span className="feature-icon feature-mint" aria-hidden="true">
                🌅
              </span>
              <h3>One shared daily</h3>
              <p>
                Everyone gets the same seeded Memory deck and 2048 start. The next challenge
                appears at midnight in Asia/Kolkata.
              </p>
            </article>
            <article className="feature-card glass">
              <span className="feature-icon feature-sky" aria-hidden="true">
                🗄️
              </span>
              <h3>Scores that stick</h3>
              <p>
                Accounts, sessions, and results persist in SQLite. Leaderboards use saved rows,
                never sample names or invented scores.
              </p>
            </article>
            <article className="feature-card glass">
              <span className="feature-icon feature-peach" aria-hidden="true">
                ♿
              </span>
              <h3>Play your way</h3>
              <p>
                Full keyboard controls, visible focus, screen-reader labels, touch swipes, and
                reduced-motion support are built into the board.
              </p>
            </article>
          </div>
        </section>
      )}
    </div>
  );
}
