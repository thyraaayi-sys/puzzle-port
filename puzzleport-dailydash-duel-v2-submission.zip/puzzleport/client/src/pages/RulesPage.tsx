import { Link } from "react-router-dom";
import { ArrowRight, BookOpen, ShieldCheck, Sparkles } from "lucide-react";

export default function RulesPage() {
  return (
    <div className="page rules-page">
      <header className="page-header">
        <div>
          <p className="eyebrow">
            <BookOpen size={14} aria-hidden="true" /> The little rulebook
          </p>
          <h1>How the daily duel works.</h1>
          <p className="page-subtitle">
            Everything you need to play fairly, understand the boards, and know exactly what this
            build does — and does not — do.
          </p>
        </div>
        <Link to="/play" className="btn btn-primary">
          Open the game room <ArrowRight size={16} aria-hidden="true" />
        </Link>
      </header>

      <div className="rules-layout">
        <nav className="rules-toc glass" aria-label="Rulebook sections">
          <p className="eyebrow">On this page</p>
          <a href="#daily">Daily rhythm</a>
          <a href="#memory">Memory Match</a>
          <a href="#2048">2048</a>
          <a href="#scoring">Scoring & ties</a>
          <a href="#fair-play">Fair play</a>
          <a href="#accounts">Accounts & privacy</a>
          <a href="#accessibility">Accessibility</a>
          <a href="#scope">Emergency build scope</a>
        </nav>

        <div className="rules-content">
          <section id="daily" className="rule-section glass">
            <span className="rule-number">01</span>
            <h2>Daily rhythm</h2>
            <p>
              A new challenge is generated for each game using an HMAC seed derived from the
              server&apos;s daily secret and the current date in <strong>Asia/Kolkata</strong>. The
              date key and seed are materialized in SQLite, so every player receives the same
              deterministic layout for that day.
            </p>
            <p>
              The daily window starts at <strong>00:00 IST</strong> and ends at{" "}
              <strong>00:00 IST</strong> the next day. A countdown is shown throughout the app.
              Tomorrow&apos;s seed cannot be derived from today&apos;s public challenge data.
            </p>
            <p className="rule-note">
              Public responses expose the per-day seed because the browser must build the puzzle.
              They never expose <code>JWT_SECRET</code>, <code>DAILY_SEED_SECRET</code>, password
              hashes, or other server secrets.
            </p>
          </section>

          <section id="memory" className="rule-section glass">
            <span className="rule-number">02</span>
            <h2>Memory Match</h2>
            <p>
              The board is a 4×4 grid with eight matching pairs. Flip one card, then a second. A
              match stays face up; a mismatch stays visible briefly, then both cards turn back. You
              cannot flip a third card while a mismatch is resolving.
            </p>
            <p>
              One &ldquo;move&rdquo; is one pair attempt. The timer starts when the deck is dealt
              and stops when the eighth pair is found. A perfect game is eight moves.
            </p>
            <p className="rule-note">
              Daily decks are shared. Replays are allowed, but only your best daily run occupies
              your leaderboard spot. Practice decks use a fresh random seed.
            </p>
          </section>

          <section id="2048" className="rule-section glass">
            <span className="rule-number">03</span>
            <h2>2048</h2>
            <p>
              Slide the 4×4 board with the arrow keys, W A S D, a touch swipe, or the on-screen
              D-pad. Equal tiles merge into their sum. Each tile can merge only once per move, so
              four equal tiles become two merged tiles — never one giant merge.
            </p>
            <p>
              A new 2 (90%) or 4 (10%) appears after every valid move. The run ends when the board
              is full and no adjacent equals remain. Reaching 2048 is a milestone, not the end: you
              may keep going or finish and save the current score.
            </p>
            <p className="rule-note">
              Only valid moves advance the board. Pressing a direction that changes nothing does
              not spawn a tile.
            </p>
          </section>

          <section id="scoring" className="rule-section glass">
            <span className="rule-number">04</span>
            <h2>Scoring & ties</h2>
            <div className="rule-table" role="table" aria-label="Ranking rules">
              <div className="rule-table-head" role="row">
                <span role="columnheader">Game</span>
                <span role="columnheader">Daily / all-time order</span>
              </div>
              <div role="row">
                <span role="cell">2048</span>
                <span role="cell">Highest score, then fewest moves, then fastest time.</span>
              </div>
              <div role="row">
                <span role="cell">Memory Match</span>
                <span role="cell">Fewest moves, then fastest time.</span>
              </div>
            </div>
            <p>
              Memory Match still stores a server-computed point value for profile totals, but moves
              and time decide its leaderboard. 2048 points are the merged tile values accumulated
              during the run.
            </p>
            <p>
              Each leaderboard keeps one row per player: your best eligible run. Daily boards only
              include daily-mode runs for today&apos;s IST date. All-time boards consider daily and
              practice runs.
            </p>
          </section>

          <section id="fair-play" className="rule-section glass">
            <span className="rule-number">05</span>
            <h2>Fair play & validation</h2>
            <p>
              Scores are tied to a server-created game session owned by your account. The API
              derives your identity from the signed JWT, never from a client-supplied user ID.
              Request bodies are validated strictly, unknown fields are rejected, and completed
              sessions cannot be saved twice.
            </p>
            <p>
              Duration is measured from the server&apos;s session timestamp, not a client-supplied
              timer. Memory Match points are recomputed on the server from moves and duration.
              Inputs are range-checked, and authentication endpoints are rate-limited.
            </p>
            <p className="rule-note warn">
              <ShieldCheck size={16} aria-hidden="true" /> This emergency build uses{" "}
              <strong>basic validation, not full replay-based anti-cheat</strong>. The server does
              not yet replay every move from a hidden deck. A determined client could still forge
              some values. Full authoritative replay, one-attempt daily policy, anomaly detection,
              and moderation tooling are documented as future work in the README.
            </p>
          </section>

          <section id="accounts" className="rule-section glass">
            <span className="rule-number">06</span>
            <h2>Accounts & privacy</h2>
            <p>
              Accounts are stored in SQLite with a bcrypt password hash (cost 12). Plaintext
              passwords are never stored. Authentication uses a signed JWT with a server-only
              secret, and protected routes verify the token on every request.
            </p>
            <p>
              Public leaderboards expose username, display name, avatar, level, and game metrics.
              They do not expose email addresses, password hashes, or session IDs. Email
              verification, password reset, account deletion, and OAuth providers are not
              implemented in this build.
            </p>
            <p className="rule-note">
              The browser keeps its session token in <code>localStorage</code>. This is convenient
              for a local MVP but should move to a hardened cookie/session design before a
              large-scale public launch.
            </p>
          </section>

          <section id="accessibility" className="rule-section glass">
            <span className="rule-number">07</span>
            <h2>Accessibility</h2>
            <p>
              Every game is fully playable with a keyboard. Focus is always visible, touch targets
              are at least 44px, dialogs trap focus and close with Escape, and game status changes
              are announced in polite live regions. The visual board also has a screen-reader
              description.
            </p>
            <p>
              All nonessential animation respects <code>prefers-reduced-motion</code>. Color is
              never the only signal for a card state or tile value: symbols, numbers, labels, and
              text accompany it.
            </p>
          </section>

          <section id="scope" className="rule-section glass">
            <span className="rule-number">08</span>
            <h2>Emergency build scope</h2>
            <p>
              This submission intentionally uses a compact stack: React, Vite, Express, Zod,
              better-sqlite3, bcryptjs, and JWT. It does not include Supabase, Prisma, PostgreSQL,
              Docker, Socket.IO, Redis, online matchmaking, or a monorepo. Those belong to the
              longer-term architecture and are explicitly out of scope for this deadline build.
            </p>
            <p className="rule-note">
              <Sparkles size={16} aria-hidden="true" /> What is real: persistent accounts, hashed
              passwords, signed sessions, both playable games, seeded dailies, saved scores,
              leaderboards, profiles, and history. What is deferred: email verification, password
              reset, replay anti-cheat, achievements persistence, live sockets, and account
              deletion.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
