process.env.NODE_ENV = "test";
process.env.JWT_SECRET = "test-jwt-secret-that-is-definitely-long-enough-1234567890";
process.env.DAILY_SEED_SECRET = "test-daily-seed-secret-that-is-long-enough-0987654321";
process.env.DATABASE_PATH = ":memory:";
