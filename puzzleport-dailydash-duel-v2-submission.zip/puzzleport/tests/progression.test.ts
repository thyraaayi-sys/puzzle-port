import { describe, expect, it } from "vitest";
import { makeApp, registerUser, createSession } from "./helpers";
import { themeSymbols } from "../server/src/catalog/memoryThemes";

describe("progression and economy", () => {
  it("grants XP, coins, and achievements for a perfect Memory run", async () => {
    const { app } = makeApp();
    const { token } = await registerUser(app);
    const session = await createSession(app, token, "memory", "daily");
    const symbols = themeSymbols("animals", 8);
    const deck = (await import("../server/src/games/memory")).createMemoryDeck(session.seed, symbols, 8);
    const byPair: Record<number, number[]> = {};
    deck.forEach((card, index) => (byPair[card.pairId] ??= []).push(index));
    const actions: number[] = [];
    for (const pair of Object.values(byPair)) actions.push(pair[0], pair[1]);

    const response = await (await import("supertest")).default(app)
      .post("/api/v1/scores")
      .set("Authorization", `Bearer ${token}`)
      .send({ sessionId: session.id, moves: 8, actions })
      .expect(201);

    expect(response.body.xpGain).toBeGreaterThan(0);
    expect(response.body.coinGain).toBeGreaterThan(0);
    expect(response.body.stars).toBe(0);
    expect(response.body.achievements).toContain("first-victory");
    expect(response.body.alreadySaved).toBe(false);

    const duplicate = await (await import("supertest")).default(app)
      .post("/api/v1/scores")
      .set("Authorization", `Bearer ${token}`)
      .send({ sessionId: session.id, moves: 8, actions })
      .expect(200);
    expect(duplicate.body.alreadySaved).toBe(true);
    expect(duplicate.body.xpGain).toBe(0);
  });

  it("prevents duplicate purchases and negative balances", async () => {
    const { app } = makeApp();
    const { token } = await registerUser(app);
    const request = (await import("supertest")).default(app);

    await request.post("/api/v1/shop/purchase").set("Authorization", `Bearer ${token}`).send({ itemType: "card_back", itemId: "clouds" }).expect(400);

    const progression = await request.get("/api/v1/progression").set("Authorization", `Bearer ${token}`).expect(200);
    expect(progression.body.inventory.card_back).toContain("sparkle");
  });

  it("rejects equipping unowned cosmetics", async () => {
    const { app } = makeApp();
    const { token } = await registerUser(app);
    const request = (await import("supertest")).default(app);
    await request.post("/api/v1/inventory/equip").set("Authorization", `Bearer ${token}`).send({ slot: "border", itemId: "neon" }).expect(400);
  });
});

