import { describe, expect, it } from "vitest";
import { Game2048Engine, validate2048Actions } from "../server/src/games/game2048";
import { validateMemoryActions, createMemoryDeck } from "../server/src/games/memory";

describe("replay determinism", () => {
  it("reconstructs the same 2048 board from recorded actions", () => {
    const seed = "replay-seed";
    const engine = new Game2048Engine(seed, 4);
    const actions = ["left", "up", "right", "down", "left"] as const;
    for (const action of actions) engine.apply(action);
    const replayed = Game2048Engine.fromActions(seed, 4, [...actions]);
    expect(replayed.board).toEqual(engine.board);
    expect(replayed.score).toBe(engine.score);
    expect(replayed.moves).toBe(engine.moves);
    const validation = validate2048Actions(seed, 4, [...actions], engine.score, engine.moves);
    expect(validation.ok).toBe(true);
  });

  it("validates Memory actions against the deterministic deck", () => {
    const seed = "memory-replay-seed";
    const symbols = ["🍓", "🫐", "🍋", "🍑", "🍡", "🧁", "🌷", "⭐"];
    const deck = createMemoryDeck(seed, symbols, 8);
    const byPair: Record<number, number[]> = {};
    deck.forEach((card, index) => (byPair[card.pairId] ??= []).push(index));
    const actions: number[] = [];
    for (const pair of Object.values(byPair)) {
      actions.push(pair[0], pair[1]);
    }
    const result = validateMemoryActions(seed, symbols, 8, actions, 1000);
    expect(result.ok).toBe(true);
    expect(result.completed).toBe(true);
    expect(result.moves).toBe(8);
    expect(result.mismatches).toBe(0);
  });
});

