import { describe, it, expect, beforeEach, afterEach } from "vitest";
import supertest from "supertest";
import { initDb } from "../server/src/db";
import { createApp } from "../server/src/app";

process.env.NODE_ENV = "test";
process.env.PORT = "4099";
process.env.JWT_SECRET = "test-secret-key-for-testing-purposes-1234567890abcdef";
process.env.DAILY_SEED_SECRET = "test-daily-seed-for-testing-purposes-1234567890abcdef";
process.env.DATABASE_PATH = ":memory:";

let db: ReturnType<typeof initDb>;
let app: ReturnType<typeof createApp>;
let request: ReturnType<typeof supertest>;
let token: string;
let userId: number;

beforeEach(async () => {
  db = initDb(":memory:");
  app = createApp(db);
  request = supertest(app);

  // Register and log in a user
  await request.post("/api/v1/auth/register").send({
    displayName: "Test Player",
    username: "testplayer",
    email: "test@example.com",
    password: "password123",
    avatar: "🦊",
  });
  const login = await request
    .post("/api/v1/auth/login")
    .send({ identifier: "test@example.com", password: "password123" });
  token = login.body.token;
  userId = login.body.user.id;
});

afterEach(() => {
  try { db.close(); } catch { /* ignore */ }
});

describe("Score saving and retrieval", () => {
  it("creates a session and saves a 2048 score", async () => {
    const session = await request
      .post("/api/v1/sessions")
      .set("Authorization", `Bearer ${token}`)
      .send({ game: "2048", mode: "classic" });
    expect(session.status).toBe(201);
    expect(session.body.session.id).toBeDefined();
    expect(session.body.session.game).toBe("2048");

    const score = await request
      .post("/api/v1/scores")
      .set("Authorization", `Bearer ${token}`)
      .send({ sessionId: session.body.session.id, score: 1024, moves: 15 });
    expect(score.status).toBe(201);
    expect(score.body.score.score).toBe(1024);
    expect(score.body.score.moves).toBe(15);
    expect(score.body.xpGain).toBeGreaterThan(0);
    expect(score.body.user.xp).toBeGreaterThan(0);
  });

  it("saves a Memory Match score (server recomputes points from moves+time)", async () => {
    const session = await request
      .post("/api/v1/sessions")
      .set("Authorization", `Bearer ${token}`)
      .send({ game: "memory", mode: "classic" });
    expect(session.status).toBe(201);

    const score = await request
      .post("/api/v1/scores")
      .set("Authorization", `Bearer ${token}`)
      .send({ sessionId: session.body.session.id, score: 900, moves: 10 });
    expect(score.status).toBe(201);
    // Server recomputes memory points from moves + duration, not the input score.
    expect(score.body.score.score).toBeGreaterThan(0);
    expect(score.body.score.moves).toBe(10);
  });

  it("rejects score save with invalid session", async () => {
    const score = await request
      .post("/api/v1/scores")
      .set("Authorization", `Bearer ${token}`)
      .send({ sessionId: "00000000-0000-0000-0000-000000000000", score: 100, moves: 5 });
    expect(score.status).toBe(404);
    expect(score.body.error.code).toBe("SESSION_NOT_FOUND");
  });

  it("rejects score save without authentication", async () => {
    const score = await request
      .post("/api/v1/scores")
      .send({ sessionId: "00000000-0000-0000-0000-000000000000", score: 100, moves: 5 });
    expect(score.status).toBe(401);
  });

  it("rejects score save with invalid score (negative)", async () => {
    const session = await request
      .post("/api/v1/sessions")
      .set("Authorization", `Bearer ${token}`)
      .send({ game: "2048", mode: "classic" });
    const score = await request
      .post("/api/v1/scores")
      .set("Authorization", `Bearer ${token}`)
      .send({ sessionId: session.body.session.id, score: -5, moves: 5 });
    expect(score.status).toBe(400);
  });

  it("rejects saving the same session twice", async () => {
    const session = await request
      .post("/api/v1/sessions")
      .set("Authorization", `Bearer ${token}`)
      .send({ game: "2048", mode: "classic" });
    await request
      .post("/api/v1/scores")
      .set("Authorization", `Bearer ${token}`)
      .send({ sessionId: session.body.session.id, score: 100, moves: 5 });
    const again = await request
      .post("/api/v1/scores")
      .set("Authorization", `Bearer ${token}`)
      .send({ sessionId: session.body.session.id, score: 9999, moves: 1 });
    expect(again.status).toBe(200);
    expect(again.body.alreadySaved).toBe(true);
    expect(again.body.score.score).toBe(100);
  });

  it("retrieves scores via stats/me", async () => {
    const session = await request
      .post("/api/v1/sessions")
      .set("Authorization", `Bearer ${token}`)
      .send({ game: "2048", mode: "classic" });
    await request
      .post("/api/v1/scores")
      .set("Authorization", `Bearer ${token}`)
      .send({ sessionId: session.body.session.id, score: 2048, moves: 20 });

    const stats = await request
      .get("/api/v1/stats/me")
      .set("Authorization", `Bearer ${token}`);
    expect(stats.status).toBe(200);
    expect(stats.body.totals.games).toBeGreaterThanOrEqual(1);
    expect(stats.body.best["2048"].bestScore).toBe(2048);
  });

  it("retrieves score history", async () => {
    const session = await request
      .post("/api/v1/sessions")
      .set("Authorization", `Bearer ${token}`)
      .send({ game: "memory", mode: "daily" });
    await request
      .post("/api/v1/scores")
      .set("Authorization", `Bearer ${token}`)
      .send({ sessionId: session.body.session.id, score: 800, moves: 12 });

    const history = await request
      .get("/api/v1/history")
      .set("Authorization", `Bearer ${token}`);
    expect(history.status).toBe(200);
    expect(history.body.history.length).toBeGreaterThanOrEqual(1);
    expect(history.body.history[0].game).toBe("memory");
  });

  it("leaderboard returns entries after saving scores", async () => {
    const session = await request
      .post("/api/v1/sessions")
      .set("Authorization", `Bearer ${token}`)
      .send({ game: "2048", mode: "daily" });
    await request
      .post("/api/v1/scores")
      .set("Authorization", `Bearer ${token}`)
      .send({ sessionId: session.body.session.id, score: 5000, moves: 30 });

    const leaderboard = await request.get("/api/v1/leaderboards?game=2048&period=daily");
    expect(leaderboard.status).toBe(200);
    expect(leaderboard.body.entries.length).toBeGreaterThanOrEqual(1);
    expect(leaderboard.body.entries[0].username).toBe("testplayer");
    expect(leaderboard.body.entries[0].score).toBe(5000);
  });

  it("daily endpoint returns today's challenge", async () => {
    const daily = await request.get("/api/v1/daily");
    expect(daily.status).toBe(200);
    expect(daily.body.dateKey).toBeDefined();
    expect(daily.body.timezone).toBe("Asia/Kolkata");
    expect(daily.body.games.length).toBe(2);
    expect(daily.body.games[0].game).toBe("memory");
    expect(daily.body.games[1].game).toBe("2048");
    expect(daily.body.games[0].seed).toBeDefined();
    expect(daily.body.games[1].seed).toBeDefined();
  });

  it("daily challenge seed is the same for all players on same date", async () => {
    const a = await request.get("/api/v1/daily");
    const b = await request.get("/api/v1/daily");
    expect(a.body.games[0].seed).toBe(b.body.games[0].seed);
    expect(a.body.games[1].seed).toBe(b.body.games[1].seed);
  });
});
