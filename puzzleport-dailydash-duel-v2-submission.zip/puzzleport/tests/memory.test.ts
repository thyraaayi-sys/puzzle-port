import { describe, expect, it } from "vitest";
import {
  createMemoryDeck,
  MEMORY_SYMBOLS,
  MemoryGame,
  memoryScore,
} from "../server/src/games/memory";

function pairIndices(game: MemoryGame, pairId: number): number[] {
  return game.deck
    .map((card, index) => (card.pairId === pairId && !card.matched ? index : -1))
    .filter((index) => index >= 0);
}

describe("Memory Match deck", () => {
  it("creates 16 cards in 8 matching pairs, deterministically", () => {
    const first = createMemoryDeck("daily-memory-seed");
    const second = createMemoryDeck("daily-memory-seed");
    expect(first).toHaveLength(16);
    expect(first).toEqual(second);
    expect(new Set(first.map((card) => card.pairId)).size).toBe(8);
    for (const pairId of Array.from({ length: 8 }, (_, index) => index)) {
      expect(first.filter((card) => card.pairId === pairId)).toHaveLength(2);
    }
    expect(new Set(first.map((card) => card.symbol)).size).toBe(8);
    expect(first.every((card) => card.flipped === false && card.matched === false)).toBe(true);
    expect(first.map((card) => card.id)).toEqual(Array.from({ length: 16 }, (_, index) => index));
  });

  it("shuffles differently for different seeds", () => {
    const first = createMemoryDeck("seed-a").map((card) => card.pairId).join("");
    const second = createMemoryDeck("seed-b").map((card) => card.pairId).join("");
    expect(first).not.toBe(second);
  });
});

describe("Memory Match input locking", () => {
  it("locks the board after a mismatch until resolve, blocking a third flip", () => {
    const game = new MemoryGame("lock-seed");
    const firstIndex = 0;
    const otherPair = game.deck.findIndex(
      (card, index) => index !== firstIndex && card.pairId !== game.deck[firstIndex].pairId,
    );

    expect(game.flip(firstIndex).ok).toBe(true);
    expect(game.moves).toBe(0);
    expect(game.locked).toBe(false);

    const mismatch = game.flip(otherPair);
    expect(mismatch.ok).toBe(true);
    expect(mismatch.mismatch).toBe(true);
    expect(game.moves).toBe(1);
    expect(game.locked).toBe(true);

    const thirdIndex = game.deck.findIndex(
      (card, index) => index !== firstIndex && index !== otherPair && !card.matched,
    );
    const third = game.flip(thirdIndex);
    expect(third.ok).toBe(false);
    expect(third.reason).toMatch(/resolve/i);

    expect(game.resolve()).toBe(true);
    expect(game.locked).toBe(false);
    expect(game.deck[firstIndex].flipped).toBe(false);
    expect(game.deck[otherPair].flipped).toBe(false);
    expect(game.moves).toBe(1);

    expect(game.flip(thirdIndex).ok).toBe(true);
  });

  it("rejects flipping an already face-up card, the same card twice, or a matched card", () => {
    const game = new MemoryGame("invalid-seed");
    expect(game.flip(0).ok).toBe(true);
    expect(game.flip(0).ok).toBe(false);
    expect(game.resolve()).toBe(false);

    const pair = pairIndices(game, game.deck[0].pairId);
    expect(game.flip(pair[1]).matched).toBe(true);
    expect(game.flip(pair[0]).ok).toBe(false);
    expect(game.flip(pair[1]).ok).toBe(false);
  });
});

describe("Memory Match completion", () => {
  it("matches pairs, counts one move per pair attempt, and completes after eight pairs", () => {
    const game = new MemoryGame("complete-seed");
    for (let pairId = 0; pairId < MEMORY_SYMBOLS.length; pairId += 1) {
      const indices = pairIndices(game, pairId);
      expect(indices).toHaveLength(2);
      const first = game.flip(indices[0]);
      expect(first.ok).toBe(true);
      expect(game.locked).toBe(false);
      const second = game.flip(indices[1]);
      expect(second.ok).toBe(true);
      expect(second.matched).toBe(true);
      expect(game.matchedPairs).toBe(pairId + 1);
      expect(game.moves).toBe(pairId + 1);
    }
    expect(game.completed).toBe(true);
    expect(game.moves).toBe(8);
    expect(game.deck.every((card) => card.matched)).toBe(true);
    expect(game.locked).toBe(false);
    expect(game.flip(0).ok).toBe(false);
  });

  it("scores a perfect game higher than a slower, messier game", () => {
    expect(memoryScore(8, 20_000)).toBeGreaterThan(memoryScore(20, 20_000));
    expect(memoryScore(8, 20_000)).toBeGreaterThan(memoryScore(8, 90_000));
    expect(memoryScore(100, 10 * 60_000)).toBe(50);
  });
});
