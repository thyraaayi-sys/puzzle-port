import { describe, expect, it } from "vitest";
import { initDb } from "../server/src/db";
import {
  addDaysToKey,
  dailyConfigs,
  dailySeed,
  dailyWindow,
  getOrCreateDaily,
  IST_TIMEZONE,
  istDateKey,
} from "../server/src/games/daily";

describe("Asia/Kolkata daily key", () => {
  it("rolls over exactly at 18:30 UTC", () => {
    expect(istDateKey(new Date("2026-11-19T18:29:59.000Z"))).toBe("2026-11-19");
    expect(istDateKey(new Date("2026-11-19T18:30:00.000Z"))).toBe("2026-11-20");
    expect(istDateKey(new Date("2026-11-19T00:00:00.000Z"))).toBe("2026-11-19");
    expect(IST_TIMEZONE).toBe("Asia/Kolkata");
  });

  it("handles leap days and year boundaries", () => {
    expect(istDateKey(new Date("2028-02-28T18:30:00.000Z"))).toBe("2028-02-29");
    expect(istDateKey(new Date("2028-02-29T18:30:00.000Z"))).toBe("2028-03-01");
    expect(istDateKey(new Date("2026-12-31T18:30:00.000Z"))).toBe("2027-01-01");
    expect(addDaysToKey("2028-02-28", 1)).toBe("2028-02-29");
  });

  it("builds the correct IST day window", () => {
    expect(dailyWindow("2026-11-19")).toEqual({
      startsAt: "2026-11-18T18:30:00.000Z",
      endsAt: "2026-11-19T18:30:00.000Z",
    });
    expect(dailyWindow("2028-02-28")).toEqual({
      startsAt: "2028-02-27T18:30:00.000Z",
      endsAt: "2028-02-28T18:30:00.000Z",
    });
  });

  it("supports month and year arithmetic for date keys", () => {
    expect(addDaysToKey("2026-11-30", 1)).toBe("2026-12-01");
    expect(addDaysToKey("2026-12-31", 1)).toBe("2027-01-01");
    expect(addDaysToKey("2028-02-29", 1)).toBe("2028-03-01");
  });
});

describe("Deterministic daily seeds", () => {
  it("returns the same seed for the same game and date", () => {
    expect(dailySeed("memory", "2026-11-19")).toBe(dailySeed("memory", "2026-11-19"));
    expect(dailySeed("2048", "2026-11-19")).toBe(dailySeed("2048", "2026-11-19"));
  });

  it("returns different seeds across games and dates", () => {
    expect(dailySeed("memory", "2026-11-19")).not.toBe(dailySeed("2048", "2026-11-19"));
    expect(dailySeed("memory", "2026-11-19")).not.toBe(dailySeed("memory", "2026-11-20"));
  });

  it("uses fixed four-by-four configurations", () => {
    expect(dailyConfigs.memory).toEqual({ gridSize: 4, pairs: 8 });
    expect(dailyConfigs["2048"]).toEqual({ size: 4, startTiles: 2 });
  });
});

describe("Daily challenge materialization", () => {
  it("is idempotent for the same game/date and unique across games", () => {
    const db = initDb(":memory:");
    try {
      const first = getOrCreateDaily(db, "memory", "2026-11-19");
      const second = getOrCreateDaily(db, "memory", "2026-11-19");
      const other = getOrCreateDaily(db, "2048", "2026-11-19");
      expect(second.id).toBe(first.id);
      expect(second.seed).toBe(first.seed);
      expect(other.id).not.toBe(first.id);
      expect(JSON.parse(first.config_json)).toEqual(dailyConfigs.memory);
      const count = db.prepare("SELECT COUNT(*) AS count FROM daily_challenges").get() as {
        count: number;
      };
      expect(count.count).toBe(2);
    } finally {
      db.close();
    }
  });
});
