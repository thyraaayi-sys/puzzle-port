import type { Express } from "express";
import request from "supertest";
import { createApp } from "../server/src/app";
import { initDb, type DB } from "../server/src/db";

export function makeApp(): { app: Express; db: DB } {
  const db = initDb(":memory:");
  return { app: createApp(db), db };
}

let userCounter = 0;

export async function registerUser(
  app: Express,
  overrides: Record<string, unknown> = {},
): Promise<{
  token: string;
  user: { id: number; username: string; email: string; displayName: string };
  credentials: {
    displayName: string;
    username: string;
    email: string;
    password: string;
    avatar: string;
  };
}> {
  userCounter += 1;
  const suffix = `${Date.now().toString(36)}${userCounter}${Math.random().toString(36).slice(2, 5)}`;
  const credentials = {
    displayName: "Strawberry Fox",
    username: `fox_${suffix}`,
    email: `fox_${suffix}@example.com`,
    password: "TestPassword123!",
    avatar: "🦊",
    ...overrides,
  };
  const response = await request(app).post("/api/v1/auth/register").send(credentials).expect(201);
  return { token: response.body.token, user: response.body.user, credentials };
}

export async function createSession(
  app: Express,
  token: string,
  game: "memory" | "2048",
  mode: "daily" | "classic" = "daily",
): Promise<{ id: string; seed: string; mode: string; challengeDate: string | null }> {
  const response = await request(app)
    .post("/api/v1/sessions")
    .set("Authorization", `Bearer ${token}`)
    .send({ game, mode })
    .expect(201);
  return response.body.session;
}
