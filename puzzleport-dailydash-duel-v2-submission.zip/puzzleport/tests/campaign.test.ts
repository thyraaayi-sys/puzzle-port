import { describe, expect, it } from "vitest";
import { MEMORY_CAMPAIGN, GAME2048_CAMPAIGN, ALL_CAMPAIGN_LEVELS } from "../server/src/catalog/campaigns";

describe("campaign catalog", () => {
  it("contains at least 30 Memory and 20 2048 levels", () => {
    expect(MEMORY_CAMPAIGN).toHaveLength(30);
    expect(GAME2048_CAMPAIGN).toHaveLength(20);
    expect(ALL_CAMPAIGN_LEVELS).toHaveLength(50);
  });

  it("has unique level ids and contiguous unlock chains", () => {
    const ids = ALL_CAMPAIGN_LEVELS.map((level) => level.id);
    expect(new Set(ids).size).toBe(ids.length);
    expect(MEMORY_CAMPAIGN[0].unlockLevelId).toBeNull();
    for (let i = 1; i < MEMORY_CAMPAIGN.length; i += 1) {
      expect(MEMORY_CAMPAIGN[i].unlockLevelId).toBe(MEMORY_CAMPAIGN[i - 1].id);
    }
  });

  it("defines positive rewards and star thresholds", () => {
    for (const level of ALL_CAMPAIGN_LEVELS) {
      expect(level.xpReward).toBeGreaterThan(0);
      expect(level.coinReward).toBeGreaterThan(0);
      expect(level.stars.threeMoves).toBeGreaterThan(0);
      expect(level.stars.twoMoves).toBeGreaterThanOrEqual(level.stars.threeMoves);
    }
  });
});

