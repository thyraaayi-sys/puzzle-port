import bcrypt from "bcryptjs";
import request from "supertest";
import { afterEach, describe, expect, it } from "vitest";
import type { DB } from "../server/src/db";
import { memoryScore } from "../server/src/games/memory";
import { createSession, makeApp, registerUser } from "./helpers";

const openDatabases: DB[] = [];

function setup() {
  const context = makeApp();
  openDatabases.push(context.db);
  return context;
}

afterEach(() => {
  while (openDatabases.length > 0) openDatabases.pop()?.close();
});

describe("health and public endpoints", () => {
  it("reports health", async () => {
    const { app } = setup();
    const response = await request(app).get("/api/v1/health").expect(200);
    expect(response.body.status).toBe("ok");
    expect(response.body.service).toBe("puzzleport-api");
    expect(response.headers["cache-control"]).toBe("no-store");
    expect(response.headers.etag).toBeUndefined();
  });

  it("serves daily challenges deterministically without server secrets", async () => {
    const { app } = setup();
    const first = await request(app).get("/api/v1/daily").expect(200);
    const second = await request(app).get("/api/v1/daily").expect(200);
    expect(first.body.dateKey).toMatch(/^\d{4}-\d{2}-\d{2}$/);
    expect(first.body.timezone).toBe("Asia/Kolkata");
    expect(first.body.games).toHaveLength(2);
    expect(first.body.games.map((game: { game: string }) => game.game)).toEqual(["memory", "2048"]);
    expect(first.body.games[0].seed).toBe(second.body.games[0].seed);
    expect(first.body.games[1].seed).toBe(second.body.games[1].seed);
    expect(first.body.games[0].completed).toBe(false);
    const serialized = JSON.stringify(first.body);
    expect(serialized).not.toContain(process.env.JWT_SECRET ?? "never");
    expect(serialized).not.toContain(process.env.DAILY_SEED_SECRET ?? "never");
    expect(serialized).not.toContain("password");
  });

  it("returns a genuinely empty leaderboard before anyone plays", async () => {
    const { app } = setup();
    const response = await request(app).get("/api/v1/leaderboards?game=2048&period=daily").expect(200);
    expect(response.body.entries).toEqual([]);
    expect(response.body.me).toBeNull();
  });
});

describe("registration and password security", () => {
  it("registers an account, hashes the password, and returns a usable token", async () => {
    const { app, db } = setup();
    const { token, user, credentials } = await registerUser(app);
    expect(token).toMatch(/^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/);
    expect(user).toMatchObject({ username: credentials.username, email: credentials.email });
    expect(user).not.toHaveProperty("password");
    expect(user).not.toHaveProperty("passwordHash");

    const stored = db
      .prepare("SELECT password_hash FROM users WHERE username = ?")
      .get(credentials.username) as { password_hash: string };
    expect(stored.password_hash).not.toBe(credentials.password);
    expect(stored.password_hash.startsWith("$2")).toBe(true);
    expect(await bcrypt.compare(credentials.password, stored.password_hash)).toBe(true);

    const me = await request(app)
      .get("/api/v1/auth/me")
      .set("Authorization", `Bearer ${token}`)
      .expect(200);
    expect(me.body.user.username).toBe(credentials.username);
    expect(me.body.user.email).toBe(credentials.email);
  });

  it("rejects duplicate usernames and emails case-insensitively", async () => {
    const { app } = setup();
    const { credentials } = await registerUser(app);

    const duplicateUsername = await request(app)
      .post("/api/v1/auth/register")
      .send({
        displayName: "Another Fox",
        username: credentials.username.toUpperCase(),
        email: "different@example.com",
        password: "AnotherPassword123",
      })
      .expect(409);
    expect(duplicateUsername.body.error.code).toBe("USERNAME_TAKEN");

    const duplicateEmail = await request(app)
      .post("/api/v1/auth/register")
      .send({
        displayName: "Another Fox",
        username: "different_username",
        email: credentials.email.toUpperCase(),
        password: "AnotherPassword123",
      })
      .expect(409);
    expect(duplicateEmail.body.error.code).toBe("EMAIL_TAKEN");
  });

  it("rejects malformed and unknown fields", async () => {
    const { app } = setup();
    const missingEmail = await request(app)
      .post("/api/v1/auth/register")
      .send({ displayName: "Fox", username: "valid_name", password: "password123" })
      .expect(400);
    expect(missingEmail.body.error.code).toBe("VALIDATION_ERROR");

    const unknownField = await request(app)
      .post("/api/v1/auth/register")
      .send({
        displayName: "Fox",
        username: "valid_name",
        email: "valid@example.com",
        password: "password123",
        isAdmin: true,
      })
      .expect(400);
    expect(unknownField.body.error.code).toBe("VALIDATION_ERROR");

    const shortPassword = await request(app)
      .post("/api/v1/auth/register")
      .send({
        displayName: "Fox",
        username: "valid_name",
        email: "valid@example.com",
        password: "short",
      })
      .expect(400);
    expect(shortPassword.body.error.code).toBe("VALIDATION_ERROR");
  });
});

describe("login and protected routes", () => {
  it("logs in by email or username and rejects wrong credentials", async () => {
    const { app } = setup();
    const { credentials } = await registerUser(app);

    const byEmail = await request(app)
      .post("/api/v1/auth/login")
      .send({ identifier: credentials.email, password: credentials.password })
      .expect(200);
    expect(byEmail.body.token).toBeTypeOf("string");

    await request(app)
      .post("/api/v1/auth/login")
      .send({ identifier: credentials.username, password: credentials.password })
      .expect(200);

    await request(app)
      .post("/api/v1/auth/login")
      .send({ identifier: credentials.email, password: "wrong-password" })
      .expect(401);

    await request(app)
      .post("/api/v1/auth/login")
      .send({ identifier: "nobody@example.com", password: "wrong-password" })
      .expect(401);
  });

  it("rejects missing, malformed, and expired sessions", async () => {
    const { app } = setup();
    await request(app).get("/api/v1/auth/me").expect(401);
    await request(app).get("/api/v1/auth/me").set("Authorization", "Bearer nonsense").expect(401);
    await request(app).get("/api/v1/stats/me").expect(401);
    await request(app).get("/api/v1/leaderboards?game=memory&period=all").expect(200);
  });

  it("rate-limits repeated login attempts", async () => {
    const { app } = setup();
    let sawTooMany = false;
    for (let attempt = 0; attempt < 41; attempt += 1) {
      const response = await request(app)
        .post("/api/v1/auth/login")
        .send({ identifier: "rate-limit@example.com", password: "wrong-password" });
      if (response.status === 429) {
        sawTooMany = true;
        expect(response.body.error.code).toBe("RATE_LIMITED");
        break;
      }
    }
    expect(sawTooMany).toBe(true);
  });
});

describe("sessions, score saving, and leaderboards", () => {
  it("saves a memory score using server-computed values and reads it back", async () => {
    const { app, db } = setup();
    const { token, user } = await registerUser(app);
    const session = await createSession(app, token, "memory", "daily");
    expect(session.mode).toBe("daily");
    expect(session.challengeDate).toMatch(/^\d{4}-\d{2}-\d{2}$/);

    const saved = await request(app)
      .post("/api/v1/scores")
      .set("Authorization", `Bearer ${token}`)
      .send({ sessionId: session.id, score: 999_999, moves: 10 })
      .expect(201);

    expect(saved.body.alreadySaved).toBe(false);
    expect(saved.body.score.score).not.toBe(999_999);
    expect(saved.body.score.score).toBe(memoryScore(10, saved.body.score.durationMs));
    expect(saved.body.xpGain).toBeGreaterThan(0);
    expect(saved.body.user.level).toBeGreaterThanOrEqual(1);

    const sessionRow = db
      .prepare("SELECT status, completed_at FROM game_sessions WHERE id = ?")
      .get(session.id) as { status: string; completed_at: string | null };
    expect(sessionRow.status).toBe("completed");
    expect(sessionRow.completed_at).not.toBeNull();

    const leaderboard = await request(app)
      .get("/api/v1/leaderboards?game=memory&period=daily")
      .set("Authorization", `Bearer ${token}`)
      .expect(200);
    expect(leaderboard.body.entries).toHaveLength(1);
    expect(leaderboard.body.entries[0].username).toBe(user.username);
    expect(leaderboard.body.entries[0].moves).toBe(10);
    expect(leaderboard.body.me.rank).toBe(1);
    expect(JSON.stringify(leaderboard.body)).not.toContain(user.email);
    expect(JSON.stringify(leaderboard.body)).not.toContain("password");

    const stats = await request(app)
      .get("/api/v1/stats/me")
      .set("Authorization", `Bearer ${token}`)
      .expect(200);
    expect(stats.body.totals.games).toBe(1);
    expect(stats.body.best.memory.gamesPlayed).toBe(1);
    expect(stats.body.best.memory.bestMoves).toBe(10);
    expect(stats.body.recent).toHaveLength(1);

    const history = await request(app)
      .get("/api/v1/history")
      .set("Authorization", `Bearer ${token}`)
      .expect(200);
    expect(history.body.history).toHaveLength(1);
    expect(history.body.history[0].game).toBe("memory");

    const duplicate = await request(app)
      .post("/api/v1/scores")
      .set("Authorization", `Bearer ${token}`)
      .send({ sessionId: session.id, score: 999_999, moves: 10 })
      .expect(200);
    expect(duplicate.body.alreadySaved).toBe(true);
    expect(duplicate.body.xpGain).toBe(0);

    const afterDuplicate = await request(app)
      .get("/api/v1/leaderboards?game=memory&period=daily")
      .expect(200);
    expect(afterDuplicate.body.entries).toHaveLength(1);
  });

  it("saves a 2048 score, returns profile data, and enforces session ownership", async () => {
    const { app } = setup();
    const owner = await registerUser(app);
    const other = await registerUser(app);
    const session = await createSession(app, owner.token, "2048", "classic");

    await request(app)
      .post("/api/v1/scores")
      .set("Authorization", `Bearer ${other.token}`)
      .send({ sessionId: session.id, score: 1024, moves: 60 })
      .expect(404);

    const saved = await request(app)
      .post("/api/v1/scores")
      .set("Authorization", `Bearer ${owner.token}`)
      .send({ sessionId: session.id, score: 1024, moves: 60 })
      .expect(201);
    expect(saved.body.score.score).toBe(1024);
    expect(saved.body.score.moves).toBe(60);

    const allTime = await request(app)
      .get("/api/v1/leaderboards?game=2048&period=all")
      .expect(200);
    expect(allTime.body.entries).toHaveLength(1);
    expect(allTime.body.entries[0].score).toBe(1024);

    const otherStats = await request(app)
      .get("/api/v1/stats/me")
      .set("Authorization", `Bearer ${other.token}`)
      .expect(200);
    expect(otherStats.body.totals.games).toBe(0);
    expect(otherStats.body.best["2048"]).toBeUndefined();
  });

  it("rejects impossible memory results and unknown score fields", async () => {
    const { app } = setup();
    const { token } = await registerUser(app);
    const memorySession = await createSession(app, token, "memory", "classic");

    const impossible = await request(app)
      .post("/api/v1/scores")
      .set("Authorization", `Bearer ${token}`)
      .send({ sessionId: memorySession.id, score: 500, moves: 7 })
      .expect(422);
    expect(impossible.body.error.code).toBe("INVALID_MOVES");

    const otherSession = await createSession(app, token, "2048", "classic");
    const unknownField = await request(app)
      .post("/api/v1/scores")
      .set("Authorization", `Bearer ${token}`)
      .send({ sessionId: otherSession.id, score: 100, moves: 10, userId: 999 })
      .expect(400);
    expect(unknownField.body.error.code).toBe("VALIDATION_ERROR");

    await request(app)
      .post("/api/v1/sessions")
      .set("Authorization", `Bearer ${token}`)
      .send({ game: "chess", mode: "daily" })
      .expect(400);
  });

  it("requires authentication to create sessions or save scores", async () => {
    const { app } = setup();
    await request(app).post("/api/v1/sessions").send({ game: "memory", mode: "daily" }).expect(401);
    await request(app)
      .post("/api/v1/scores")
      .send({ sessionId: "00000000-0000-0000-0000-000000000000", score: 10, moves: 10 })
      .expect(401);
  });
});
