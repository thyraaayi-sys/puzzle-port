import { describe, it, expect, beforeEach, afterEach } from "vitest";
import supertest from "supertest";
import bcrypt from "bcryptjs";
import { initDb } from "../server/src/db";
import { createApp } from "../server/src/app";

process.env.NODE_ENV = "test";
process.env.PORT = "4099";
process.env.JWT_SECRET = "test-secret-key-for-testing-purposes-1234567890abcdef";
process.env.DAILY_SEED_SECRET = "test-daily-seed-for-testing-purposes-1234567890abcdef";
process.env.DATABASE_PATH = ":memory:";

let db: ReturnType<typeof initDb>;
let app: ReturnType<typeof createApp>;
let request: ReturnType<typeof supertest>;

beforeEach(() => {
  db = initDb(":memory:");
  app = createApp(db);
  request = supertest(app);
});

afterEach(() => {
  try { db.close(); } catch { /* ignore */ }
});

describe("Account registration", () => {
  it("registers a new user and returns a JWT token", async () => {
    const res = await request
      .post("/api/v1/auth/register")
      .send({
        displayName: "Strawberry Fox",
        username: "strawberryfox",
        email: "strawberry@example.com",
        password: "password123",
        avatar: "🍓",
      });
    expect(res.status).toBe(201);
    expect(res.body.token).toBeDefined();
    expect(res.body.user).toMatchObject({
      username: "strawberryfox",
      displayName: "Strawberry Fox",
      email: "strawberry@example.com",
      avatar: "🍓",
    });
    expect(res.body.user.id).toBe(1);
    expect(res.body.user.password_hash).toBeUndefined();
  });

  it("hashes passwords with bcrypt and never stores plaintext", async () => {
    await request
      .post("/api/v1/auth/register")
      .send({
        displayName: "Alice",
        username: "alice",
        email: "alice@example.com",
        password: "secretPassword1",
      });
    const user = db.prepare("SELECT password_hash FROM users WHERE username = ?").get("alice") as { password_hash: string };
    expect(user.password_hash).not.toBe("secretPassword1");
    expect(await bcrypt.compare("secretPassword1", user.password_hash)).toBe(true);
    expect(await bcrypt.compare("wrongpassword", user.password_hash)).toBe(false);
  });

  it("rejects missing fields with validation errors", async () => {
    const res = await request.post("/api/v1/auth/register").send({});
    expect(res.status).toBe(400);
    expect(res.body.error.code).toBe("VALIDATION_ERROR");
  });

  it("rejects passwords shorter than 8 characters", async () => {
    const res = await request
      .post("/api/v1/auth/register")
      .send({
        displayName: "Alice",
        username: "alice",
        email: "alice@example.com",
        password: "short",
      });
    expect(res.status).toBe(400);
  });

  it("rejects invalid usernames", async () => {
    const res = await request
      .post("/api/v1/auth/register")
      .send({
        displayName: "Alice",
        username: "al!", // invalid char
        email: "alice@example.com",
        password: "password123",
      });
    expect(res.status).toBe(400);
  });

  it("rejects invalid emails", async () => {
    const res = await request
      .post("/api/v1/auth/register")
      .send({
        displayName: "Alice",
        username: "alice",
        email: "not-an-email",
        password: "password123",
      });
    expect(res.status).toBe(400);
  });
});

describe("Duplicate account rejection", () => {
  beforeEach(async () => {
    await request
      .post("/api/v1/auth/register")
      .send({
        displayName: "Existing User",
        username: "existinguser",
        email: "existing@example.com",
        password: "password123",
      });
  });

  it("rejects duplicate usernames", async () => {
    const res = await request
      .post("/api/v1/auth/register")
      .send({
        displayName: "Another",
        username: "existinguser",
        email: "different@example.com",
        password: "password123",
      });
    expect(res.status).toBe(409);
    expect(res.body.error.code).toBe("USERNAME_TAKEN");
  });

  it("rejects duplicate emails (case-insensitive)", async () => {
    const res = await request
      .post("/api/v1/auth/register")
      .send({
        displayName: "Another",
        username: "differentuser",
        email: "EXISTING@EXAMPLE.COM",
        password: "password123",
      });
    expect(res.status).toBe(409);
    expect(res.body.error.code).toBe("EMAIL_TAKEN");
  });
});

describe("Login and protected routes", () => {
  const userInput = {
    displayName: "Bob",
    username: "bob",
    email: "bob@example.com",
    password: "password123",
  };

  beforeEach(async () => {
    await request.post("/api/v1/auth/register").send(userInput);
  });

  it("logs in with email", async () => {
    const res = await request
      .post("/api/v1/auth/login")
      .send({ identifier: "bob@example.com", password: "password123" });
    expect(res.status).toBe(200);
    expect(res.body.token).toBeDefined();
    expect(res.body.user.username).toBe("bob");
  });

  it("logs in with username", async () => {
    const res = await request
      .post("/api/v1/auth/login")
      .send({ identifier: "bob", password: "password123" });
    expect(res.status).toBe(200);
    expect(res.body.user.username).toBe("bob");
  });

  it("rejects wrong password", async () => {
    const res = await request
      .post("/api/v1/auth/login")
      .send({ identifier: "bob@example.com", password: "wrongpassword" });
    expect(res.status).toBe(401);
    expect(res.body.error.code).toBe("INVALID_CREDENTIALS");
  });

  it("rejects unknown user", async () => {
    const res = await request
      .post("/api/v1/auth/login")
      .send({ identifier: "nonexistent@example.com", password: "password123" });
    expect(res.status).toBe(401);
  });

  it("returns current user from verified token", async () => {
    const login = await request
      .post("/api/v1/auth/login")
      .send({ identifier: "bob@example.com", password: "password123" });
    const token = login.body.token;

    const res = await request
      .get("/api/v1/auth/me")
      .set("Authorization", `Bearer ${token}`);
    expect(res.status).toBe(200);
    expect(res.body.user.username).toBe("bob");
    expect(res.body.user.email).toBe("bob@example.com");
  });

  it("rejects protected route without token", async () => {
    const res = await request.get("/api/v1/auth/me");
    expect(res.status).toBe(401);
    expect(res.body.error.code).toBe("AUTH_REQUIRED");
  });

  it("rejects protected route with invalid token", async () => {
    const res = await request
      .get("/api/v1/auth/me")
      .set("Authorization", "Bearer not-a-real-token");
    expect(res.status).toBe(401);
    expect(res.body.error.code).toBe("TOKEN_INVALID");
  });

  it("derives identity from token, never client-provided user ID", async () => {
    const login = await request
      .post("/api/v1/auth/login")
      .send({ identifier: "bob@example.com", password: "password123" });
    const token = login.body.token;

    // POST /scores requires a session derived from the authenticated user, not a body user_id
    const session = await request
      .post("/api/v1/sessions")
      .set("Authorization", `Bearer ${token}`)
      .send({ game: "memory", mode: "classic" });
    expect(session.status).toBe(201);
    expect(session.body.session.user_id).toBeUndefined(); // server owns the user id

    const me = await request
      .get("/api/v1/auth/me")
      .set("Authorization", `Bearer ${token}`);
    expect(me.body.user.id).toBe(session.body.session.user_id === undefined ? 1 : 1);
  });

  it("logout clears the session (stateless JWT)", async () => {
    const login = await request
      .post("/api/v1/auth/login")
      .send({ identifier: "bob@example.com", password: "password123" });
    const token = login.body.token;

    const res = await request
      .post("/api/v1/auth/logout")
      .set("Authorization", `Bearer ${token}`);
    expect(res.status).toBe(204);
  });
});

describe("Auth rate limiting", () => {
  it("applies rate limiting to auth endpoints", async () => {
    const promises = Array(45).fill(null).map(() =>
      request.post("/api/v1/auth/register").send({
        displayName: "Rate",
        username: `rateuser${Math.random()}`,
        email: `rate${Math.random()}@example.com`,
        password: "password123",
      }),
    );
    const results = await Promise.all(promises);
    const limited = results.some((r) => r.status === 429);
    expect(limited).toBe(true);
  });
});
