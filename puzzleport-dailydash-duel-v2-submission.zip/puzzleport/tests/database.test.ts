import { describe, it, expect, beforeEach, afterEach } from "vitest";
import { initDb } from "../server/src/db";
import { createApp } from "../server/src/app";

process.env.NODE_ENV = "test";
process.env.PORT = "4099";
process.env.JWT_SECRET = "test-secret-key-for-testing-purposes-1234567890abcdef";
process.env.DAILY_SEED_SECRET = "test-daily-seed-for-testing-purposes-1234567890abcdef";
process.env.DATABASE_PATH = ":memory:";

let db: ReturnType<typeof initDb>;
let app: ReturnType<typeof createApp>;

beforeEach(() => {
  db = initDb(":memory:");
  app = createApp(db);
});

afterEach(() => {
  try { db.close(); } catch { /* ignore */ }
});

describe("Database initialization", () => {
  it("creates all required tables", () => {
    const tables = db
      .prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' ORDER BY name")
      .all() as Array<{ name: string }>;
    const names = tables.map((t) => t.name);
    expect(names).toContain("users");
    expect(names).toContain("game_sessions");
    expect(names).toContain("scores");
    expect(names).toContain("daily_challenges");
    expect(names).toContain("user_stats");
  });

  it("creates indexes on scores and sessions", () => {
    const indexes = db
      .prepare("SELECT name FROM sqlite_master WHERE type = 'index' AND name NOT LIKE 'sqlite_%' ORDER BY name")
      .all() as Array<{ name: string }>;
    const names = indexes.map((i) => i.name);
    expect(names).toContain("idx_scores_user");
    expect(names).toContain("idx_scores_daily");
    expect(names).toContain("idx_scores_game_created");
    expect(names).toContain("idx_sessions_user");
    expect(names).toContain("idx_daily_date");
  });

  it("users table enforces NOT NULL and constraints", () => {
    expect(() =>
      db.prepare("INSERT INTO users (username, email, display_name, password_hash) VALUES (?, ?, ?, ?)").run("alice", "alice@example.com", "Alice", "hash"),
    ).not.toThrow();
    const user = db.prepare("SELECT * FROM users WHERE username = ?").get("alice");
    expect(user).toBeDefined();
    expect((user as { xp: number; level: number }).xp).toBe(0);
    expect((user as { level: number }).level).toBe(1);
  });
});
