import { describe, expect, it } from "vitest";
import { makeApp, registerUser, createSession } from "./helpers";

describe("leaderboard separation", () => {
  it("keeps daily and all-time boards separate by mode", async () => {
    const { app } = makeApp();
    const { token } = await registerUser(app);
    const request = (await import("supertest")).default(app);

    const dailySession = await createSession(app, token, "2048", "daily");
    await request
      .post("/api/v1/scores")
      .set("Authorization", `Bearer ${token}`)
      .send({ sessionId: dailySession.id, score: 1000, moves: 10 })
      .expect(201);

    const dailyBoard = await request.get("/api/v1/leaderboards?game=2048&period=daily").expect(200);
    expect(dailyBoard.body.entries).toHaveLength(1);

    const allBoard = await request.get("/api/v1/leaderboards?game=2048&period=all").expect(200);
    expect(allBoard.body.entries).toHaveLength(1);
  });
});

