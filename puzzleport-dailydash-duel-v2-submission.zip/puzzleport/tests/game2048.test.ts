import { describe, expect, it } from "vitest";
import {
  applyMove,
  cloneBoard,
  createGame,
  emptyBoard,
  hasMoves,
  hashSeed,
  maxTile,
  moveBoard,
  mulberry32,
  slideLine,
  spawnTile,
  type Board,
  type Direction,
} from "../server/src/games/game2048";

describe("2048 line merging", () => {
  it("merges each tile at most once per move", () => {
    expect(slideLine([2, 2, 2, 2])).toEqual({ line: [4, 4, 0, 0], gained: 8, moved: true });
    expect(slideLine([4, 4, 4, 0])).toEqual({ line: [8, 4, 0, 0], gained: 8, moved: true });
    expect(slideLine([2, 2, 4, 4])).toEqual({ line: [4, 8, 0, 0], gained: 12, moved: true });
    expect(slideLine([2, 0, 2, 2])).toEqual({ line: [4, 2, 0, 0], gained: 4, moved: true });
    expect(slideLine([2, 4, 8, 16])).toEqual({ line: [2, 4, 8, 16], gained: 0, moved: false });
    expect(slideLine([0, 0, 0, 0])).toEqual({ line: [0, 0, 0, 0], gained: 0, moved: false });
  });

  it("supports horizontal and vertical moves without double-merging", () => {
    const board: Board = [
      [2, 2, 2, 2],
      [4, 0, 4, 4],
      [0, 0, 0, 0],
      [8, 8, 16, 16],
    ];
    const left = moveBoard(board, "left");
    expect(left.board[0]).toEqual([4, 4, 0, 0]);
    expect(left.board[1]).toEqual([8, 4, 0, 0]);
    expect(left.board[3]).toEqual([16, 32, 0, 0]);
    expect(left.gained).toBe(64);

    const right = moveBoard(board, "right");
    expect(right.board[0]).toEqual([0, 0, 4, 4]);
    expect(right.board[1]).toEqual([0, 0, 4, 8]);
    expect(right.board[3]).toEqual([0, 0, 16, 32]);

    const vertical: Board = [
      [2, 0, 0, 0],
      [2, 0, 0, 0],
      [4, 0, 0, 0],
      [4, 0, 0, 0],
    ];
    expect(moveBoard(vertical, "up").board[0]).toEqual([4, 0, 0, 0]);
    expect(moveBoard(vertical, "up").board[1]).toEqual([8, 0, 0, 0]);
    // Moving down: [4,4,2,2] reads bottom-to-top, merges to [8,4,0,0], 8 lands at bottom.
    expect(moveBoard(vertical, "down").board[3]).toEqual([8, 0, 0, 0]);
    expect(moveBoard(vertical, "down").board[2]).toEqual([4, 0, 0, 0]);
  });

  it("does not mutate the input board", () => {
    const board: Board = [
      [2, 2, 0, 0],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
    ];
    const before = cloneBoard(board);
    moveBoard(board, "left");
    expect(board).toEqual(before);
  });
});

describe("2048 spawn and game state", () => {
  it("is deterministic for the same seed", () => {
    const first = createGame("daily-seed-42");
    const second = createGame("daily-seed-42");
    expect(first.board).toEqual(second.board);
    expect(first.score).toBe(0);
    expect(first.moves).toBe(0);

    const firstMove = applyMove(first.board, "left", first.rng);
    const secondMove = applyMove(second.board, "left", second.rng);
    expect(firstMove).toEqual(secondMove);
  });

  it("spawns only into empty cells", () => {
    const rng = mulberry32(hashSeed("spawn-test"));
    for (let i = 0; i < 30; i += 1) {
      const board = emptyBoard();
      board[0][0] = 2;
      const next = spawnTile(board, rng);
      expect(next[0][0]).toBe(2);
      const filled = next.flat().filter((value) => value !== 0);
      expect(filled.length).toBe(board.flat().filter((value) => value !== 0).length + 1);
    }
  });

  it("does not spawn a tile after an invalid move", () => {
    const board: Board = [
      [2, 4, 8, 16],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
    ];
    const rng = mulberry32(123);
    const result = applyMove(board, "up", rng);
    expect(result.moved).toBe(false);
    expect(result.gained).toBe(0);
    expect(result.board).toBe(board);
  });

  it("detects full boards and available moves", () => {
    const stuck: Board = [
      [2, 4, 2, 4],
      [4, 2, 4, 2],
      [2, 4, 2, 4],
      [4, 2, 4, 2],
    ];
    expect(hasMoves(stuck)).toBe(false);
    expect(applyMove(stuck, "left", mulberry32(1)).gameOver).toBe(true);

    const almostStuck = cloneBoard(stuck);
    almostStuck[3][3] = 0;
    expect(hasMoves(almostStuck)).toBe(true);

    const verticalMatch = cloneBoard(stuck);
    verticalMatch[3][3] = 4;
    expect(hasMoves(verticalMatch)).toBe(true);
  });

  it("tracks the maximum tile and accumulates merge score", () => {
    let rng = mulberry32(999);
    let board: Board = [
      [2, 2, 0, 0],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
    ];
    const result = applyMove(board, "left", rng);
    expect(result.gained).toBe(4);
    expect(maxTile(result.board)).toBeGreaterThanOrEqual(4);
    board = result.board;
    rng = mulberry32(1);
    const next = applyMove(
      [
        [1024, 1024, 0, 0],
        [0, 0, 0, 0],
        [0, 0, 0, 0],
        [0, 0, 0, 0],
      ],
      "left",
      rng,
    );
    expect(next.gained).toBe(2048);
    expect(maxTile(next.board)).toBeGreaterThanOrEqual(2048);
    expect(board.flat().length).toBe(16);
  });

  it("replays the same action sequence identically", () => {
    const directions: Direction[] = ["left", "down", "right", "up", "left", "down"];
    const run = () => {
      const game = createGame("replay-seed");
      let board = game.board;
      let score = 0;
      for (const direction of directions) {
        const result = applyMove(board, direction, game.rng);
        board = result.board;
        score += result.gained;
      }
      return { board, score };
    };
    expect(run()).toEqual(run());
  });
});
