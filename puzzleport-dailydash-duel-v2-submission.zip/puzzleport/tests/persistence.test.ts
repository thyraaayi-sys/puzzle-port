import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import request from "supertest";
import { describe, expect, it } from "vitest";
import { createApp } from "../server/src/app";
import { initDb } from "../server/src/db";
import { createSession, registerUser } from "./helpers";

describe("API persistence across server restarts", () => {
  it("keeps accounts, sessions, and leaderboard scores in the SQLite file", async () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "puzzleport-api-persist-"));
    const filename = path.join(dir, "puzzleport.db");
    try {
      const firstDb = initDb(filename);
      const firstApp = createApp(firstDb);
      const { token, credentials } = await registerUser(firstApp);
      const session = await createSession(firstApp, token, "memory", "daily");
      await request(firstApp)
        .post("/api/v1/scores")
        .set("Authorization", `Bearer ${token}`)
        .send({ sessionId: session.id, score: 1000, moves: 9 })
        .expect(201);
      firstDb.close();

      const secondDb = initDb(filename);
      const secondApp = createApp(secondDb);
      const login = await request(secondApp)
        .post("/api/v1/auth/login")
        .send({ identifier: credentials.email, password: credentials.password })
        .expect(200);

      const stats = await request(secondApp)
        .get("/api/v1/stats/me")
        .set("Authorization", `Bearer ${login.body.token}`)
        .expect(200);
      expect(stats.body.totals.games).toBe(1);
      expect(stats.body.best.memory.bestMoves).toBe(9);

      const board = await request(secondApp)
        .get("/api/v1/leaderboards?game=memory&period=daily")
        .expect(200);
      expect(board.body.entries).toHaveLength(1);
      expect(board.body.entries[0].username).toBe(credentials.username);
      expect(board.body.entries[0].moves).toBe(9);
      secondDb.close();
    } finally {
      fs.rmSync(dir, { recursive: true, force: true });
    }
  });
});
