import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { afterEach, describe, expect, it } from "vitest";
import { initDb, type DB } from "../server/src/db";

const openDatabases: DB[] = [];

afterEach(() => {
  while (openDatabases.length > 0) openDatabases.pop()?.close();
});

describe("SQLite initialization", () => {
  it("creates all required tables and indexes", () => {
    const db = initDb(":memory:");
    openDatabases.push(db);
    const tables = (
      db.prepare("SELECT name FROM sqlite_master WHERE type = 'table' ORDER BY name").all() as Array<{
        name: string;
      }>
    ).map((row) => row.name);
    expect(tables).toEqual(
      expect.arrayContaining(["users", "daily_challenges", "game_sessions", "scores", "user_stats"]),
    );

    const indexes = (
      db.prepare("SELECT name FROM sqlite_master WHERE type = 'index'").all() as Array<{ name: string }>
    ).map((row) => row.name);
    expect(indexes).toEqual(
      expect.arrayContaining([
        "idx_scores_game_created",
        "idx_scores_daily",
        "idx_scores_user",
        "idx_sessions_user",
        "idx_daily_date",
      ]),
    );
  });

  it("enforces unique usernames and emails case-insensitively", () => {
    const db = initDb(":memory:");
    openDatabases.push(db);
    const insert = db.prepare(
      "INSERT INTO users (username, email, display_name, password_hash) VALUES (?, ?, ?, ?)",
    );
    insert.run("strawberry", "one@example.com", "Strawberry", "hash");
    expect(() => insert.run("STRAWBERRY", "two@example.com", "Copy", "hash")).toThrow(/UNIQUE/);
    expect(() => insert.run("peach", "ONE@example.com", "Copy", "hash")).toThrow(/UNIQUE/);
  });

  it("enforces the score foreign keys", () => {
    const db = initDb(":memory:");
    openDatabases.push(db);
    expect(() =>
      db
        .prepare(
          `INSERT INTO scores (user_id, game, mode, score, moves, duration_ms, session_id)
           VALUES (999, 'memory', 'classic', 100, 10, 5000, 'missing-session')`,
        )
        .run(),
    ).toThrow(/FOREIGN KEY/);
  });

  it("persists accounts and scores after closing and reopening the file", () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "puzzleport-db-"));
    const filename = path.join(dir, "persist.db");
    try {
      const first = initDb(filename);
      const user = first
        .prepare(
          "INSERT INTO users (username, email, display_name, password_hash) VALUES (?, ?, ?, ?)",
        )
        .run("persistfox", "persist@example.com", "Persist Fox", "hash");
      first
        .prepare(
          `INSERT INTO game_sessions (id, user_id, game, mode, seed, started_at)
           VALUES (?, ?, '2048', 'classic', 'seed', ?)`,
        )
        .run("session-1", Number(user.lastInsertRowid), new Date().toISOString());
      first
        .prepare(
          `INSERT INTO scores (user_id, game, mode, score, moves, duration_ms, session_id)
           VALUES (?, '2048', 'classic', 512, 42, 90000, 'session-1')`,
        )
        .run(Number(user.lastInsertRowid));
      first.close();

      const second = initDb(filename);
      const savedUser = second.prepare("SELECT username, email FROM users WHERE id = ?").get(Number(user.lastInsertRowid));
      const savedScore = second.prepare("SELECT score, moves FROM scores WHERE session_id = 'session-1'").get();
      second.close();
      expect(savedUser).toEqual({ username: "persistfox", email: "persist@example.com" });
      expect(savedScore).toEqual({ score: 512, moves: 42 });
    } finally {
      fs.rmSync(dir, { recursive: true, force: true });
    }
  });
});
