import { describe, it, expect } from "vitest";
import {
  applyMove,
  createGame,
  slideLine,
  hasMoves,
  maxTile,
  emptyBoard,
  hashSeed,
  mulberry32,
  type Board,
  type Direction,
} from "../server/src/games/game2048";
import {
  createMemoryDeck,
  MemoryGame,
  memoryScore,
  MEMORY_SYMBOLS,
} from "../server/src/games/memory";

describe("2048 slideLine", () => {
  it("merges adjacent equal values once", () => {
    const result = slideLine([2, 2, 4, 4]);
    expect(result.line).toEqual([4, 8, 0, 0]);
    expect(result.gained).toBe(12);
  });

  it("does not double-merge in a single move", () => {
    const result = slideLine([2, 2, 2, 2]);
    expect(result.line).toEqual([4, 4, 0, 0]);
    expect(result.gained).toBe(8);
  });

  it("slides zeros to the end", () => {
    const result = slideLine([0, 2, 0, 2]);
    expect(result.line).toEqual([4, 0, 0, 0]);
  });

  it("does nothing when nothing can merge", () => {
    const result = slideLine([2, 4, 8, 16]);
    expect(result.line).toEqual([2, 4, 8, 16]);
    expect(result.moved).toBe(false);
  });
});

describe("2048 applyMove", () => {
  it("moves left and merges correctly", () => {
    const board: Board = [
      [2, 2, 4, 0],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
    ];
    const rng = () => 0.5;
    const result = applyMove(board, "left", rng);
    expect(result.moved).toBe(true);
    expect(result.board[0]).toEqual([4, 4, 0, 0]);
    expect(result.gained).toBe(4);
  });

  it("moves right correctly", () => {
    const board: Board = [
      [2, 2, 0, 0],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
    ];
    const rng = () => 0.5;
    const result = applyMove(board, "right", rng);
    expect(result.board[0]).toEqual([0, 0, 0, 4]);
  });

  it("moves up correctly", () => {
    const board: Board = [
      [2, 0, 0, 0],
      [2, 0, 0, 0],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
    ];
    const rng = () => 0.5;
    const result = applyMove(board, "up", rng);
    expect(result.board[0][0]).toBe(4);
    expect(result.board[1][0]).toBe(0);
  });

  it("moves down correctly", () => {
    const board: Board = [
      [0, 0, 0, 0],
      [0, 0, 0, 0],
      [2, 0, 0, 0],
      [2, 0, 0, 0],
    ];
    const rng = () => 0.5;
    const result = applyMove(board, "down", rng);
    expect(result.board[3][0]).toBe(4);
    expect(result.board[2][0]).toBe(0);
  });

  it("returns gameOver when board is full with no moves", () => {
    const board: Board = [
      [2, 4, 8, 16],
      [16, 8, 4, 2],
      [2, 4, 8, 16],
      [16, 8, 4, 2],
    ];
    const rng = () => 0.5;
    const result = applyMove(board, "left", rng);
    expect(result.moved).toBe(false);
    expect(result.gameOver).toBe(true);
  });

  it("returns moved=true and gameOver=false when a move is valid", () => {
    const board: Board = [
      [2, 2, 0, 0],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
    ];
    const rng = () => 0.5;
    const result = applyMove(board, "left", rng);
    expect(result.moved).toBe(true);
    expect(result.gameOver).toBe(false);
  });

  it("spawns a tile after every valid move", () => {
    const board: Board = emptyBoard();
    const rng = () => 0.5; // always spawn 2
    const { board: next } = createGame("seed", 4);
    const result = applyMove(next, "left", rng);
    const count = result.board.flat().filter((v) => v !== 0).length;
    expect(count).toBeGreaterThanOrEqual(2);
  });

  it("detects max tile", () => {
    const board: Board = [[2, 0, 0, 0], [0, 1024, 0, 0], [0, 0, 0, 0], [0, 0, 0, 2048]];
    expect(maxTile(board)).toBe(2048);
  });
});

describe("2048 createGame", () => {
  it("starts with two tiles", () => {
    const { board } = createGame("seed1");
    const count = board.flat().filter((v) => v !== 0).length;
    expect(count).toBe(2);
    expect(board[0][0] + board[1][1] > 0 || board.flat().filter((v) => v !== 0).length).toBe(2);
  });

  it("produces deterministic boards from the same seed", () => {
    const a = createGame("same-seed");
    const b = createGame("same-seed");
    expect(a.board).toEqual(b.board);
  });

  it("produces different boards from different seeds", () => {
    const a = createGame("seed-a");
    const b = createGame("seed-b");
    let different = false;
    outer: for (let r = 0; r < 4; r++) {
      for (let c = 0; c < 4; c++) {
        if (a.board[r][c] !== b.board[r][c]) { different = true; break outer; }
      }
    }
    expect(different).toBe(true);
  });

  it("hashSeed returns a number", () => {
    expect(typeof hashSeed("abc")).toBe("number");
    expect(hashSeed("")).toBe(hashSeed(""));
  });
});

describe("mulberry32 PRNG", () => {
  it("produces deterministic sequence from same seed", () => {
    const a = mulberry32(12345);
    const b = mulberry32(12345);
    for (let i = 0; i < 10; i++) {
      expect(a()).toBe(b());
    }
  });

  it("produces values between 0 and 1", () => {
    const rng = mulberry32(1);
    for (let i = 0; i < 100; i++) {
      const v = rng();
      expect(v).toBeGreaterThanOrEqual(0);
      expect(v).toBeLessThan(1);
    }
  });
});

describe("Memory deck creation", () => {
  it("creates 16 cards with 8 pairs", () => {
    const deck = createMemoryDeck("seed");
    expect(deck.length).toBe(16);
    const pairIds = new Set(deck.map((c) => c.pairId));
    expect(pairIds.size).toBe(8);
  });

  it("each symbol appears exactly twice", () => {
    const deck = createMemoryDeck("seed");
    const counts: Record<string, number> = {};
    for (const card of deck) {
      counts[card.symbol] = (counts[card.symbol] ?? 0) + 1;
    }
    for (const symbol of MEMORY_SYMBOLS) {
      expect(counts[symbol]).toBe(2);
    }
  });

  it("produces deterministic decks from the same seed", () => {
    const a = createMemoryDeck("same-seed");
    const b = createMemoryDeck("same-seed");
    expect(a.map((c) => c.symbol)).toEqual(b.map((c) => c.symbol));
  });

  it("produces different decks from different seeds", () => {
    const a = createMemoryDeck("seed-a").map((c) => c.symbol);
    const b = createMemoryDeck("seed-b").map((c) => c.symbol);
    expect(a).not.toEqual(b);
  });
});

describe("MemoryGame matching and locking", () => {
  it("flips first card successfully", () => {
    const game = new MemoryGame("seed");
    const result = game.flip(0);
    expect(result.ok).toBe(true);
    expect(game.firstIndex).toBe(0);
    expect(game.deck[0].flipped).toBe(true);
    expect(game.moves).toBe(0);
  });

  it("prevents flipping more than two cards during mismatch evaluation", () => {
    const game = new MemoryGame("seed");
    // Find two non-matching cards
    game.flip(0);
    const first = game.deck[0];
    let secondIndex = 1;
    while (game.deck[secondIndex].pairId === first.pairId) secondIndex++;
    game.flip(secondIndex);
    expect(game.locked).toBe(true);
    // While locked, a third flip should be rejected
    const third = game.flip(2);
    expect(third.ok).toBe(false);
    expect(third.reason).toBe("Waiting for cards to resolve");
  });

  it("marks matching cards as matched", () => {
    const game = new MemoryGame("seed");
    game.flip(0);
    const firstPairId = game.deck[0].pairId;
    let matchIndex = 1;
    while (game.deck[matchIndex].pairId !== firstPairId) matchIndex++;
    const result = game.flip(matchIndex);
    expect(result.matched).toBe(true);
    expect(game.matchedPairs).toBe(1);
    expect(game.deck[0].matched).toBe(true);
    expect(game.deck[matchIndex].matched).toBe(true);
    expect(game.locked).toBe(false);
  });

  it("locks on mismatch and unlocks after resolve", () => {
    const game = new MemoryGame("seed");
    game.flip(0);
    let mismatchIndex = 1;
    while (game.deck[mismatchIndex].pairId === game.deck[0].pairId) mismatchIndex++;
    game.flip(mismatchIndex);
    expect(game.locked).toBe(true);
    const resolved = game.resolve();
    expect(resolved).toBe(true);
    expect(game.locked).toBe(false);
    expect(game.deck[0].flipped).toBe(false);
    expect(game.deck[mismatchIndex].flipped).toBe(false);
  });

  it("completes when all 8 pairs are matched", () => {
    const game = new MemoryGame("seed");
    for (let pairId = 0; pairId < 8; pairId++) {
      const first = game.deck.findIndex((c) => c.pairId === pairId && !c.matched && !c.flipped);
      game.flip(first);
      const second = game.deck.findIndex((c, idx) => c.pairId === pairId && !c.matched && idx !== first);
      game.flip(second);
    }
    expect(game.completed).toBe(true);
    expect(game.matchedPairs).toBe(8);
  });

  it("rejects flips after game is complete", () => {
    const game = new MemoryGame("seed");
    for (let pairId = 0; pairId < 8; pairId++) {
      const first = game.deck.findIndex((c) => c.pairId === pairId && !c.matched && !c.flipped);
      game.flip(first);
      const second = game.deck.findIndex((c, idx) => c.pairId === pairId && !c.matched && idx !== first);
      game.flip(second);
    }
    const result = game.flip(0);
    expect(result.ok).toBe(false);
    expect(result.reason).toBe("Game complete");
  });
});

describe("memoryScore", () => {
  it("scores a perfect 8-move game highly", () => {
    const score = memoryScore(8, 30000);
    expect(score).toBeGreaterThan(50);
  });

  it("has a minimum floor of 50", () => {
    const score = memoryScore(200, 3600000);
    expect(score).toBe(50);
  });

  it("reduces score with more moves and time", () => {
    const fast = memoryScore(8, 10000);
    const slow = memoryScore(8, 60000);
    expect(fast).toBeGreaterThan(slow);
  });
});
